# Target: ARM64 Android, standalone executable (runs under root on device).
APP_ABI      := arm64-v8a
# android-29 gives us EGL, GLES3, ANativeWindow, dlfcn, system_properties.
APP_PLATFORM := android-29
# Static-link the C++ STL so the binary has no external libstdc++ dependency.
APP_STL      := c++_static
# -Wno-error: downgrade all -Werror back to warnings (oxorany + ImGui::TextColored
#   with non-literal format strings trigger -Wformat-security; the original build
#   was compiled with warnings, not errors).
# -Wno-format-security: silence the non-literal-format-string warning entirely.
# UPDATE 2026/07/31 v18: РЕЛИЗ — логирование ВЫРЕЗАНО на этапе компиляции.
# Пользователь: убрать лаги от записи лога (2MB файл + запись каждый кадр).
# Без OX_ENABLE_LOG все макросы OXLOG* разворачиваются в no-op (do{(void)sizeof(...);}while(0)),
# строки форматов исчезают из бинарника, файла на sdcard нет вообще, писать
# нечего → нет per-frame fflush/WriteFile/__android_log_write → нет лагов.
# Для диагностики обратно: добавить -DOX_ENABLE_LOG -DOX_VERBOSE_LOG.
# ДИАГНОСТИЧЕСКАЯ СБОРКА (по запросу erafox): логи ВКЛючены обратно.
#   OX_ENABLE_LOG  — пишет /sdcard/Download/EclipsOxide/eclips_oxide_<ts>.log
#   OX_VERBOSE_LOG — максимум деталей (chain/scan/HP/POS/W2S, первые 300 кадров)
#   Может слегка лагать (запись каждый кадр) — ок для диагностики, потом уберём.
APP_CPPFLAGS := -std=c++17 -fno-rtti -fexceptions -Wno-error -Wno-format-security -Wno-format -DOX_ENABLE_LOG -DOX_VERBOSE_LOG
APP_CFLAGS   := -ffunction-sections -fdata-sections -Wno-error -Wno-format-security -Wno-format -DOX_ENABLE_LOG -DOX_VERBOSE_LOG
# Release build. Символы стрипаем (лог-строки остаются — это литералы в .rodata).
APP_OPTIM    := release
APP_STRIP_MODE := --strip-all
