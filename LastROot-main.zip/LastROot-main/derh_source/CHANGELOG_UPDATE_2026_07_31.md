# DERH — обновление под сборку Oxide 2026/07/31 (arm64) + подробный лог

## Файлы, использованные для сверки

Из архивов erafox:

| Файл | Размер | MD5 |
|---|---|---|
| `libil2cpp.so` (arm64-v8a) | 212 MB | `14666f83c1e3ef41d98fb8f319244125` |
| `global-metadata.dat` | 27 MB | `d3edbbb5055ec351cc2644dc9d3fb430` |
| `dump.cs` (arm64 Il2CppDumper output) | 73 MB | `53ae80abc14cf6d01785bc20a69d9f33` |
| `il2cpp.h` | 191 MB | `eb69642cf9fdbe17cea3fb797aaaf17f` |
| `script.json` | 273 MB | `c4578c6a49d3bd716d45a93d752b7665` |

**Важно про arch:** libil2cpp.so — **arm64-v8a**, `e_machine=0xB7`. Первый архив с dump.cs (папка "x86_64") на самом деле содержал x86_64-slice output — RVA методов там **несовместимы** с arm64 libil2cpp. Метаданные (TDI, byval, name-offsets) cross-platform и **совпадают** между обеими arch — их я корректно вычислил и в прошлый раз.

## Что обновлено

### Метаданные (в `include/oxide_offsets.h`)

Значения выведены `Nov/typeinfo_offline.py` с параметрами:
```
--types-va 0xC260EB8 --types-count 105268
--meta-td-off 0x1533A04 --meta-td-count 29697 --meta-td-rec 82
--meta-str 0xE5FD4
```

Все 9 классов → **VERIFY OK** (types[byval].klassIndex == TDI, kind=0x12 CLASS, byref=0, pinned=0):

| Класс | TDI (new) | byval idx (new) | Namespace |
|---|---|---|---|
| PlayerManager | **8502** | 61253 | Oxide |
| BuildingPiece | **8790** | 39883 | Oxide.Building |
| PlayerVitals | **8163** | 61317 | Oxide |
| RaycastManager | **8255** | 62492 | Oxide |
| MouseLook | **8142** | 59006 | Oxide |
| Camera | **13965** | 39900 | UnityEngine |
| EntityVitals | **8152** | 50917 | Oxide |
| GenericVitals | **8154** | 52740 | Oxide |
| NetworkClient | **24057** | 59548 | Mirror |

Плюс `IL2CPP_TYPES_RVA = 0xC260EB8`, `OX_TYPEDEF_COUNT = 29697`.

### Name offsets (в `src/main.cpp`, для name-scan fallback)

```cpp
OX_META_NAME_OFF_PLAYERMANAGER = 0x17e504
OX_META_NAME_OFF_BUILDINGPIECE = 0x11713e
OX_META_NAME_OFF_PLAYERVITALS  = 0x1770dc
```

Найдены через `grep -abo "ИМЯ\x00" global-metadata.dat`.

### Подробный лог — по просьбе erafox

**Компиляция теперь включает `-DOX_ENABLE_LOG -DOX_VERBOSE_LOG` по умолчанию.**
Правки в `Application.mk`:

```make
APP_CPPFLAGS := ... -DOX_ENABLE_LOG -DOX_VERBOSE_LOG
APP_CFLAGS   := ... -DOX_ENABLE_LOG -DOX_VERBOSE_LOG
```

Правки в `src/oxlog.cpp`:
* `oxlog::verbose = true` по умолчанию (при `OX_VERBOSE_LOG`).
* `FULL_LOG_FRAMES = 300` (было 30) — первые ~10 секунд геймплея пишутся с полными hex-дампами и chain-диагностикой.

**Путь лога:**
```
/sdcard/Download/EclipsOxide/eclips_oxide_YYYYMMDD_HHMMSS.log
```
Fallback (если Download не пишется) — см. `oxlog.cpp:CANDIDATE_DIRS`, каскад до `/data/local/tmp`.

**Что пишется в лог в первую очередь (добавлено в `main()`):**

* Build info: date/time сборки, ожидаемые MD5 (для сверки что либа не подменилась).
* METADATA OFFSETS: все обновлённые (STR, TD_OFF, TD_COUNT, XOR key).
* TDI/BYVAL: все 9 значений (чтобы удалённо проверить, что резолвер бьёт в правильные слоты).
* IL2CPP_TYPES_RVA + count.
* NAME OFFSETS (для fallback).
* FAST-SEED status: если старые слоты в новой либе дадут null — в логе будет "chain: MetadataCache pointers ещё не установлены" и переход на name-scan.
* Пути лога (директория, файл, logcat-тэг).

**Как читать лог на устройстве:**

```bash
# файловый (полный):
adb pull /sdcard/Download/EclipsOxide/eclips_oxide_20260731_170000.log .

# livecat (то же самое, но realtime):
adb logcat -s EclipsOxide

# stdout от бинарника (если запускаешь через adb shell su -c ./eclipsoxide):
adb shell "cd /sdcard/Download && su -c '/data/local/tmp/eclipsoxide 2>&1 | tee stdout.log'"
```

## Fast-seed не обновлён (см. предыдущий CHANGELOG)

Значения `OX_META_MC_RVA`, `OX_META_BASE_PTR_RVA`, `OX_META_HEADER_PTR_RVA`, `OX_META_STRIDE_RVA`, `OX_S_TYPEINFO_TABLE_RVA` остались от 2026-07-25 и в новой libil2cpp указывают в мусор. **Резолвер автоматически fallback'нется на name-scan** (то же самое, только на несколько сотен миллисекунд медленнее). В новом подробном логе это будет видно первой строкой после `[chain]`:

```
[chain] MetadataCache pointers ещё не установлены (meta=0x0 hdr=0x0 stride=0)
[fallback] name-scan: PlayerManager klass=0x... TDI=8502
[fallback] name-scan: BuildingPiece klass=0x... TDI=8790
```

## Сборка

```bash
tar -xzf DERH_update_2026-07-31_v2.tar.gz
cd derh_source

# Font.h из base64+gzip (github не хранит файлы >4MB):
cd include/ImGui/font
base64 -d Font.h.gz.b64 | gunzip > Font.h
md5sum Font.h   # 7c667be5b679273f9f4a0424c75d7261
rm Font.h.gz.b64
cd ../../..

# Собрать (лог включён по умолчанию):
ndk-build -j8 \
  NDK_PROJECT_PATH=$(pwd) \
  APP_BUILD_SCRIPT=$(pwd)/Android.mk \
  NDK_APPLICATION_MK=$(pwd)/Application.mk
```

Результат — `libs/arm64-v8a/eclipsoxide` (~3.7 MB, standalone PIE, запускать под `su`).

**Для сборки без лога** (продакшн, чист от sdcard-артефактов): убрать `-DOX_ENABLE_LOG -DOX_VERBOSE_LOG` из `Application.mk`.

## Верификация после первого запуска

Ожидаемое начало лога:
```
[oxlog] лог пишется в: /sdcard/Download/EclipsOxide/eclips_oxide_20260731_HHMMSS.log

==== STARTUP ====
Eclips Oxide запущен, uid=0, pid=NNNNN

========== ECLIPS OXIDE BUILD INFO ==========
build:              Jul 31 2026 17:00:00
target package:     com.catsbit.oxidesurvivalisland
target module:      libil2cpp.so
expected md5:       libil2cpp 14666f83c1e3ef41d98fb8f319244125
...
========== TDI (обновлено под 2026-07-31) ==========
PLAYERMANAGER   TDI=8502
BUILDINGPIECE   TDI=8790
...
```

Если MD5 в реальной сборке не совпадёт с логом — значит либа снова обновилась и нужен ещё раунд обновления TDI (через `Nov/typeinfo_offline.py`).

## Что делать, если после обновления что-то не работает

Прислать мне первые ~500 строк лога `/sdcard/Download/EclipsOxide/eclips_oxide_*.log` — по нему видно на каком этапе резолв упал.

Диагностика по симптому в логе:

| В логе | Причина | Что чинить |
|---|---|---|
| `chain: MetadataCache pointers ещё не установлены` | Fast-seed stale (это ожидаемо) | Ничего, name-scan подхватит |
| `name-scan: X не найден` | Метадаты поехали ещё раз | Пересчитать TDI/NAME_OFF |
| `matrix=0 viewOff=-2` | Камера-матрицы не находятся | Пересчитать сигнатуру в `ox_findCameraMatrices` |
| `anchors=0/N`, `stage=2` | KCC не резолвится | `KCC.player` offset (0x78) съехал |
| `isLocal=-1` весь матч | `NB_NET_IDENTITY` (0x40) или `NetworkIdentity.isLocalPlayer` (0x4A) съехали | Сверить в новом `il2cpp.h` |
