# DERH-Loader — сборка APK (внешний чит eclipsoxide в APK-обёртке)

Это исходники НАШЕГО внешнего APK. Внутри — eclipsoxide (внешний чит: свой
оверлей ESP/меню + чтение /proc/mem, работает поверх Vulkan-игры) завёрнутый в
Android-лаунчер: ставишь APK → START → Magisk root → запускает игру и eclipsoxide.

Свежий бинарь чита уже лежит в `app/src/main/assets/eclipsoxide` (arm64, с реальным
скелетом из lag-comp костей, вотчдогом закрытия и подробными логами).

## Вариант 1 — Android Studio / Gradle (канонический)
```
открой папку derh_loader/ в Android Studio  →  Build → Build APK(s)
# или из консоли, если настроен Android SDK:
cd derh_loader
gradle wrapper            # один раз
./gradlew assembleDebug   # → app/build/outputs/apk/debug/app-debug.apk
```
Проект: `app/build.gradle` (namespace com.eclips.external, minSdk 29, arm64),
`MainActivity.kt` (START → su → assets/start_external.sh), `AndroidManifest.xml`.

## Вариант 2 — ручная сборка без Gradle (как собирался отданный APK)
Отданный `DERH-Loader.apk` собран напрямую через SDK build-tools (aapt2 → javac →
d8 → zipalign → apksigner), с Java-версией Activity (kotlinc не нужен). Скрипт и
Java-исходник — в `manual_build/`:
```
cd derh_loader/manual_build
# правь пути JDK/SDK вверху build_apk.sh под своё окружение, затем:
sh build_apk.sh           # → DERH-Loader.apk (debug-подпись)
```
Оба варианта дают функционально одинаковый APK. eclipsoxide берётся из
`app/src/main/assets/eclipsoxide`.

## Как пользоваться собранным APK
Поставить APK (разрешить «неизвестные источники») → открыть → START → дать root
(Magisk для com.eclips.external). Лаунчер: setenforce 0 → am start игры (OxideActivity)
→ eclipsoxide в фоне (свой оверлей). Логи чита: `/sdcard/Download/EclipsOxide/`.
