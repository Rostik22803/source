package com.eclips.external

import android.app.Activity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.ScrollView
import android.widget.TextView
import java.io.BufferedReader
import java.io.File
import java.io.FileOutputStream
import java.io.InputStreamReader

/**
 * DERH Loader — обёртка над внешним eclipsoxide.
 *
 * Поток:
 *   1. При старте распаковываем из assets в filesDir: start_external.sh, eclipsoxide.
 *   2. START → Runtime.exec("su") (Magisk спросит root) → выполняем start_external.sh.
 *      Скрипт (root): setenforce 0, запускает игру (am start), запускает eclipsoxide
 *      в фоне (он сам ждёт игру, рисует свой оверлей ESP/меню).
 *   3. stdout/stderr su стримим в лог на экране.
 *
 * eclipsoxide кладёт Gradle в assets на сборке (task copyExternalBinary, см. build.gradle).
 */
class MainActivity : Activity() {

    companion object {
        private const val TAG = "DERHLoader"
        private val ASSET_FILES = listOf("start_external.sh", "eclipsoxide")
    }

    private lateinit var logView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        logView = TextView(this).apply {
            text = "DERH Loader\n"
            setPadding(24, 24, 24, 24)
            textSize = 12f
        }
        val scroll = ScrollView(this).apply { addView(logView) }

        val startBtn = Button(this).apply {
            text = "START"
            setOnClickListener { onStartClicked() }
        }

        val root = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            addView(startBtn)
            addView(scroll)
        }
        setContentView(root)

        try {
            extractAssets()
            log("Assets extracted to ${filesDir.absolutePath}")
            log("Жми START, разреши root (Magisk).")
        } catch (e: Exception) {
            log("Asset extraction failed: ${e.message}")
            Log.e(TAG, "extractAssets", e)
        }
    }

    private fun onStartClicked() {
        log("START — requesting root...")
        Thread { runFlow() }.start()
    }

    /** Копирует ASSET_FILES из APK-assets в filesDir (перезаписывает), +x. */
    private fun extractAssets() {
        for (name in ASSET_FILES) {
            val out = File(filesDir, name)
            assets.open(name).use { input ->
                FileOutputStream(out).use { output -> input.copyTo(output) }
            }
            out.setReadable(true, false)
            out.setExecutable(true, false)
        }
    }

    /** su → start_external.sh (передаём APP_FILES = filesDir). */
    private fun runFlow() {
        val files = filesDir.absolutePath
        val startSh = File(filesDir, "start_external.sh").absolutePath
        try {
            val proc = Runtime.getRuntime().exec("su")
            val stdin = proc.outputStream
            val cmd = "export APP_FILES='$files'\n" +
                      "sh '$startSh'\n" +
                      "exit\n"
            stdin.write(cmd.toByteArray())
            stdin.flush()
            stdin.close()

            streamToLog(BufferedReader(InputStreamReader(proc.inputStream)))
            streamToLog(BufferedReader(InputStreamReader(proc.errorStream)))

            val code = proc.waitFor()
            log("su exited with code $code")
            if (code != 0) log("Root denied? Разреши root для com.eclips.external в Magisk.")
            else log("Готово. Сверни лаунчер — оверлей DERH поверх игры.")
        } catch (e: Exception) {
            log("exec(su) failed: ${e.message} — устройство без root?")
            Log.e(TAG, "runFlow", e)
        }
    }

    private fun streamToLog(reader: BufferedReader) {
        try {
            var line: String?
            while (reader.readLine().also { line = it } != null) log(line ?: "")
        } catch (_: Exception) { }
    }

    private fun log(msg: String) {
        Log.i(TAG, msg)
        runOnUiThread { logView.append(msg + "\n") }
    }
}
