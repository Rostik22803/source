#!/system/bin/sh
# ============================================================================
#  DERH Loader — start_external.sh
#  Под ROOT (Runtime.exec("su") из MainActivity). Запускает игру и внешний
#  eclipsoxide (свой оверлей + чтение /proc/mem). eclipsoxide сам ждёт игру.
#
#  APP_FILES передаёт MainActivity (filesDir с распакованными ассетами).
# ============================================================================
TMP=/data/local/tmp
PKG=com.catsbit.oxidesurvivalisland
ACTIVITY=$PKG/com.unity3d.player.UnityPlayerActivity
BIN=$TMP/eclipsoxide
SELF_DIR=$(dirname "$0")
APP_FILES="${APP_FILES:-}"

DL=/sdcard/Download
[ -d /storage/emulated/0/Download ] && DL=/storage/emulated/0/Download
mkdir -p "$DL" 2>/dev/null || DL=$TMP
LOG="$DL/derh_loader.log"
: > "$LOG" 2>/dev/null
log(){ echo "[derh] $*"; echo "[derh] $*" >> "$LOG" 2>/dev/null; }

log "==== start_external.sh (self=$SELF_DIR APP_FILES=${APP_FILES:-<none>}) ===="

# --- root? ---
if [ "$(id -u)" != "0" ]; then
  log "НЕ root. Разреши root приложению (Magisk) и жми START снова."
  exit 3
fi

# --- найти eclipsoxide (APP_FILES -> папка скрипта -> /data/local/tmp) ---
SRC=""
for d in "$APP_FILES" "$SELF_DIR" "$TMP"; do
  [ -n "$d" ] && [ -f "$d/eclipsoxide" ] && { SRC="$d"; break; }
done
if [ -z "$SRC" ]; then
  log "eclipsoxide НЕ НАЙДЕН (положи в /data/local/tmp или собери APK правильно)"; exit 1
fi
[ "$SRC" = "$TMP" ] || cp -f "$SRC/eclipsoxide" "$BIN"
chmod 755 "$BIN"
setenforce 0 2>/dev/null
log "eclipsoxide готов: $BIN ; SELinux -> $(getenforce 2>/dev/null)"

# --- запустить игру ---
log "launching $PKG ..."
am start -n "$ACTIVITY" 2>/dev/null \
  || am start -n "$PKG/.MainActivity" 2>/dev/null \
  || monkey -p "$PKG" -c android.intent.category.LAUNCHER 1 >/dev/null 2>&1

# --- запустить eclipsoxide в фоне (он сам дождётся игры, рисует свой оверлей) ---
log "starting eclipsoxide (overlay) ..."
nohup "$BIN" > "$DL/derh_run.log" 2>&1 &
CHILD=$!
sleep 1
if kill -0 "$CHILD" 2>/dev/null; then
  log "eclipsoxide запущен (pid=$CHILD). Оверлей появится когда игра прогрузится."
  log "лог чита: $DL/derh_run.log"
else
  log "eclipsoxide НЕ поднялся — смотри $DL/derh_run.log"
fi
exit 0
