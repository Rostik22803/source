# DERH Loader — APK-обёртка для внешнего eclipsoxide

Ставишь APK → открываешь → жмёшь **START** → Magisk просит root → разрешаешь →
лаунчер запускает игру и `eclipsoxide` (внешний чит: свой оверлей ESP/меню +
чтение `/proc/mem`). eclipsoxide сам ждёт игру и рисует поверх — Vulkan/GLES без разницы.

## Как это работает
- `MainActivity` распаковывает из assets `start_external.sh` + `eclipsoxide` в filesDir, `+x`.
- START → `su` → `start_external.sh` (root): `setenforce 0` → `am start` игры →
  `eclipsoxide` в фоне (`nohup ... &`).
- Логи: `/sdcard/Download/derh_loader.log` (лаунчер) и `derh_run.log` (сам чит).

## Сборка APK (нужен Android Studio / Android SDK — в песочнице агента их нет)
```
# eclipsoxide уже лежит в app/src/main/assets/eclipsoxide (arm64).
# Если пересобрал чит — обнови его: cp derh_source/libs/arm64-v8a/eclipsoxide app/src/main/assets/
cd derh_loader
gradle wrapper            # или открой папку в Android Studio
./gradlew assembleDebug   # → app/build/outputs/apk/debug/app-debug.apk
```
Установить APK, открыть, дать root, START.

## Требования
- Root (Magisk). При первом START Magisk спросит доступ — разреши для `com.eclips.external`.
- Устройство arm64, игра `com.catsbit.oxidesurvivalisland` установлена.
- Точное имя Activity игры при желании поправь в `assets/start_external.sh` (`ACTIVITY=`).

## Без APK (быстрый тест)
Не хочешь собирать APK — есть `derh_external_bundle.tar.gz` (eclipsoxide + run_external.sh):
`su -c 'sh /data/local/tmp/run_external.sh'`.
