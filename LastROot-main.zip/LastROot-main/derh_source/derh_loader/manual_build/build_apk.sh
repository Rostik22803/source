#!/usr/bin/env bash
# ============================================================================
#  DERH-Loader — ручная сборка APK без Gradle (aapt2 → javac → d8 → zipalign →
#  apksigner). Ровно этим собран отданный DERH-Loader.apk.
#  ПРАВЬ пути под своё окружение:
# ============================================================================
set -e
JDK=${JDK:-/tmp/jdk17}
SDK=${SDK:-/tmp/android-sdk}
BT=$SDK/build-tools/34.0.0
AJ=$SDK/platforms/android-34/android.jar
export JAVA_HOME=$JDK PATH=$JDK/bin:$PATH

HERE=$(cd "$(dirname "$0")" && pwd)          # .../derh_loader/manual_build
LOADER=$(cd "$HERE/.." && pwd)               # .../derh_loader
OUT=$HERE/out; rm -rf "$OUT"; mkdir -p "$OUT"

MANIFEST=$LOADER/app/src/main/AndroidManifest.xml
RES=$LOADER/app/src/main/res
ASSETS=$LOADER/app/src/main/assets            # содержит eclipsoxide + start_external.sh

echo "== aapt2 compile/link (res + manifest + assets) =="
$BT/aapt2 compile --dir "$RES" -o "$OUT/res.zip"
$BT/aapt2 link -o "$OUT/base.apk" -I "$AJ" --manifest "$MANIFEST" -A "$ASSETS" \
  --java "$OUT/gen" --min-sdk-version 29 --target-sdk-version 34 \
  --version-code 1 --version-name 1.0 "$OUT/res.zip"

echo "== javac + d8 (Java Activity — kotlinc не нужен) =="
mkdir -p "$OUT/classes"
javac -source 17 -target 17 -encoding UTF-8 -cp "$AJ" -d "$OUT/classes" \
  "$OUT"/gen/com/eclips/external/R.java \
  "$HERE"/src/com/eclips/external/MainActivity.java
( cd "$OUT/classes" && "$JDK/bin/jar" cf ../app.jar . )
$BT/d8 --release --min-api 29 --lib "$AJ" --output "$OUT/dex" "$OUT/app.jar"

echo "== вложить classes.dex, выровнять, подписать =="
cp -f "$OUT/base.apk" "$OUT/unsigned.apk"
python3 - "$OUT" <<'PY'
import zipfile,sys,os
o=sys.argv[1]
z=zipfile.ZipFile(os.path.join(o,"unsigned.apk"),"a",zipfile.ZIP_DEFLATED)
z.write(os.path.join(o,"dex","classes.dex"),"classes.dex"); z.close()
PY
$BT/zipalign -p -f 4 "$OUT/unsigned.apk" "$OUT/aligned.apk"
[ -f "$HERE/debug.ks" ] || keytool -genkeypair -keystore "$HERE/debug.ks" -alias derh \
  -storepass android -keypass android -dname "CN=DERH,O=eclips,C=RU" -keyalg RSA -keysize 2048 -validity 10000
$BT/apksigner sign --ks "$HERE/debug.ks" --ks-pass pass:android --key-pass pass:android \
  --out "$HERE/DERH-Loader.apk" "$OUT/aligned.apk"
$BT/apksigner verify "$HERE/DERH-Loader.apk" && echo "OK -> $HERE/DERH-Loader.apk"
