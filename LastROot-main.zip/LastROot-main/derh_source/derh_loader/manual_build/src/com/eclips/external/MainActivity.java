package com.eclips.external;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;

/**
 * DERH Loader — APK-обёртка над внешним eclipsoxide.
 * START -> su (Magisk root) -> start_external.sh: setenforce 0, am start игры,
 * eclipsoxide в фоне (свой оверлей ESP/меню, чтение /proc/mem).
 */
public class MainActivity extends Activity {
    private static final String TAG = "DERHLoader";
    private static final String[] ASSET_FILES = { "start_external.sh", "eclipsoxide" };
    private TextView logView;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        logView = new TextView(this);
        logView.setText("DERH Loader\n");
        logView.setPadding(24, 24, 24, 24);
        logView.setTextSize(12f);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(logView);

        Button startBtn = new Button(this);
        startBtn.setText("START");
        startBtn.setOnClickListener(v -> onStartClicked());

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.addView(startBtn);
        root.addView(scroll);
        setContentView(root);

        try {
            extractAssets();
            log("Assets extracted to " + getFilesDir().getAbsolutePath());
            log("Жми START, разреши root (Magisk).");
        } catch (Exception e) {
            log("Asset extraction failed: " + e.getMessage());
            Log.e(TAG, "extractAssets", e);
        }
    }

    private void onStartClicked() {
        log("START — requesting root...");
        new Thread(this::runFlow).start();
    }

    private void extractAssets() throws Exception {
        for (String name : ASSET_FILES) {
            File out = new File(getFilesDir(), name);
            InputStream in = getAssets().open(name);
            OutputStream os = new FileOutputStream(out);
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
            os.close();
            in.close();
            out.setReadable(true, false);
            out.setExecutable(true, false);
        }
    }

    private void runFlow() {
        String files = getFilesDir().getAbsolutePath();
        String startSh = new File(getFilesDir(), "start_external.sh").getAbsolutePath();
        try {
            Process proc = Runtime.getRuntime().exec("su");
            OutputStream stdin = proc.getOutputStream();
            String cmd = "export APP_FILES='" + files + "'\nsh '" + startSh + "'\nexit\n";
            stdin.write(cmd.getBytes());
            stdin.flush();
            stdin.close();
            streamToLog(new BufferedReader(new InputStreamReader(proc.getInputStream())));
            streamToLog(new BufferedReader(new InputStreamReader(proc.getErrorStream())));
            int code = proc.waitFor();
            log("su exited with code " + code);
            if (code != 0) log("Root denied? Разреши root для com.eclips.external в Magisk.");
            else log("Готово. Сверни лаунчер — оверлей DERH поверх игры.");
        } catch (Exception e) {
            log("exec(su) failed: " + e.getMessage() + " — устройство без root?");
            Log.e(TAG, "runFlow", e);
        }
    }

    private void streamToLog(BufferedReader r) {
        try {
            String line;
            while ((line = r.readLine()) != null) log(line);
        } catch (Exception ignored) { }
    }

    private void log(String msg) {
        Log.i(TAG, msg);
        runOnUiThread(() -> logView.append(msg + "\n"));
    }
}
