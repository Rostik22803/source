// NDK r27+ hardcodes -Werror=format-security at the end of the clang command
// line, after all user flags. oxorany() returns const char* (not a literal), so
// ImGui::TextColored(..., oxorany("...")) trips -Wformat-security. The original
// build was done with an older NDK that didn't force this. Pragma has priority
// over command-line -Werror, so we silence it here.
#pragma clang diagnostic ignored "-Wformat-security"
#pragma clang diagnostic ignored "-Wformat-nonliteral"
#pragma clang diagnostic ignored "-Wformat"

#include "main.h"
#include "LuaIntegration.h"
#include "memory.h"
#include "utils.h"
#include "oxide_offsets.h"
#include "oxlog.h"
#include "oxorany/oxorany.hpp"

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <dirent.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/syscall.h>
#include <sys/mman.h>
#include <sys/uio.h>
#include <malloc.h>
#include <math.h>
#include <thread>
#include <iostream>
#include <algorithm>
#include <sys/stat.h>
#include <errno.h>
#include <netdb.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <iostream>
#include <locale>
#include <string>
#include <time.h>
#include <codecvt>
#include <dlfcn.h>
#include "Vector2.h"
#include "../include/Vector3.h"
#include "Quaternion.h"
#include <sstream>
#include <mutex>
#include <vector>
#include <atomic>
#include <chrono>

bool main_thread_flag = true;

// ============================================================================
//  Startup pipeline (async).
//  Startup diagnostics + TypeInfo auto-resolve сканируют десятки/сотни МБ памяти
//  процесса игры и раньше вызывались синхронно в main() ДО входа в цикл рендера.
//  На защищённом билде Oxide это могло длиться минуты — meню за это время
//  вообще не открывалось (erafox видел зависший лог сразу после
//  "TypeInfo fallback из хедера: PM=... BP=... PV=...").
//  Новая схема: initGUI_draw() → touch → whileLoop СРАЗУ, а диагностика/резолв
//  идут в фоновом std::thread. UpdatePlayerCache/ox_getStatics пропускают
//  проход, пока фон не закончил, — меню отрисовывается с первого кадра, а
//  в углу видно строку статуса.
// ============================================================================
static std::atomic<bool> g_startupThreadStarted{false};
static std::atomic<bool> g_startupDone{false};
static std::atomic<bool> g_startupInProgress{false};
static std::mutex        g_startupStatusMutex;
static std::string       g_startupStatus = "\xd0\xbe\xd0\xb6\xd0\xb8\xd0\xb4\xd0\xb0\xd0\xbd\xd0\xb8\xd0\xb5"; // "ожидание"

static void ox_setStartupStatus(const std::string &s) {
    std::lock_guard<std::mutex> l(g_startupStatusMutex);
    g_startupStatus = s;
}
std::string ox_getStartupStatus() {
    std::lock_guard<std::mutex> l(g_startupStatusMutex);
    return g_startupStatus;
}

// Deadline для тяжёлых сканов памяти. Возвращает true если пора закруглиться.
// Проверяется вручную внутри цикла-сканера, чтобы не подвешивать UI.
static std::atomic<uint64_t> g_scanDeadlineMs{0};
static bool ox_scanTimedOut() {
    uint64_t d = g_scanDeadlineMs.load(std::memory_order_relaxed);
    if (!d) return false;
    uint64_t now = (uint64_t)std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::steady_clock::now().time_since_epoch()).count();
    return now >= d;
}
static void ox_setScanDeadline(uint64_t seconds) {
    uint64_t now = (uint64_t)std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::steady_clock::now().time_since_epoch()).count();
    g_scanDeadlineMs.store(now + seconds * 1000, std::memory_order_relaxed);
}
static void ox_clearScanDeadline() { g_scanDeadlineMs.store(0, std::memory_order_relaxed); }

int abs_ScreenX = 0;
int abs_ScreenY = 0;
int game_pid = -1;
uint64_t il2cpp_base = 0;

// ============================================================================
//  Startup-scan governance.
//
//  OX_TRUST_HEADER_TYPEINFO (default 1):
//    Верим значениям PLAYERMANAGER_TYPEINFO / BUILDINGPIECE_TYPEINFO /
//    PLAYERVITALS_TYPEINFO из oxide_offsets.h. При старте пробуем seed из
//    хедера (одна дереф + проверка имени класса) — если сходится, klass'ы
//    заполнены за миллисекунды, весь скан-путь пропускается: нет sweep-а
//    менеджеров, нет 45×20с retry, нет 200 MB/с memmem-прогрева. Если seed
//    не сходится (RVA протух, версия сменилась) — падаем на прежний
//    scan-based резолв через ox_autoResolveTypeInfos.
//
//  OX_DEEP_DIAG (default 0):
//    Полный sweep всех известных TypeInfo в конце startup-диагностики.
//    Нужен только когда обновляется libil2cpp.so и надо вытащить свежие
//    RVA для oxide_offsets.h — обычному пользователю это лаг без пользы.
// ============================================================================
#ifndef OX_TRUST_HEADER_TYPEINFO
#define OX_TRUST_HEADER_TYPEINFO 1
#endif
#ifndef OX_DEEP_DIAG
#define OX_DEEP_DIAG 0
#endif

// Типовые RVA из последнего dump.cs — fallback. Runtime resolver может заменить
// их на найденные в запущенной версии игры без пересборки после обновления.
static uint64_t g_playerManagerTypeInfoRVA = ox::PLAYERMANAGER_TYPEINFO;
static uint64_t g_buildingPieceTypeInfoRVA = ox::BUILDINGPIECE_TYPEINFO;
static bool g_typeInfoAutoResolved = false;
// Внешний чит НЕ может звать il2cpp_class_from_name (она в процессе игры).
// Поэтому кэшируем САМ указатель Il2CppClass, найденный сканом памяти по имени.
// Этого достаточно: klass + CLASS_STATIC_FIELDS -> static_fields напрямую,
// TypeInfo RVA (который на metadata v39 нестабилен) больше не нужен.
static uint64_t g_playerManagerKlass = 0;
static uint64_t g_buildingPieceKlass = 0;
// Mirror.NetworkClient (TDI 23916) — статический класс с реестром spawned.
// Нужен как резервный источник построек для LOS: saveList у клиента пустой.
static uint64_t g_networkClientKlass = 0;

// структура для кэширования данных игрока
struct PlayerCacheData {
    uint64_t address;
    Vector3 position;
    ImVec2 w2sTop;
    ImVec2 w2sBottom;
    int health;
    int armor;
    int teamId;
    float distance;
    std::string name;
    std::string weapon;
    std::string teamName;
    bool isVisibleTop;
    bool isVisibleBottom;
    // Якоря модели (KCC.head + Motor.LastInterpolatedPosition). Заполняются
    // когда espModelAnchor смог прочитать цепочку; тогда бокс/скелет/LOS
    // строятся по фактическим габаритам, а не по серверному тику + оффсет.
    bool    usedModelAnchor = false;
    Vector3 anchorFeet{0,0,0};
    Vector3 anchorHead{0,0,0};
    bool    anchorCrouching = false;  // цель сидит (капсула просела)
    Vector3 motorVelocity{0,0,0};     // скорость из Motor.BaseVelocity
    // Флаги состояния цели (PlayerManager.playerFlags + отдельные bool'ы).
    bool flagSleeping   = false;   // спит — обычно не атакуют
    bool flagSpectating = false;   // в режиме наблюдателя
    bool flagPrime      = false;   // прайм-аккаунт
    // LOS по BuildingPiece.saveList: true если путь от камеры до точки игрока
    // не перекрыт стеной. Пересчитывается каждый кадр в ESP-секции (дёшево на
    // кэше построек). aimbot при aimCheckWalls пропускает цели с losBlocked=true.
    bool losBlocked;
    uint64_t viewPtr;
    uint64_t bipedMap;
    bool hasSkeletonData;
    Vector3 velocity;
    Vector3 sampledPosition;
    double sampleTime;
    
    // ── Скелет: мировые позиции костей (заполняются ox_readSkeleton) ──────
    // Источник — PlayerModelInfo (head / body / rightWeaponHolder /
    // leftWeaponHolder) + Ragdoll.m_Pelvis. Остальные суставы достраиваются
    // интерполяцией между реальными точками, чтобы не читать по 15 трансформов
    // на игрока каждый кадр (дорого и лишний трафик к процессу игры).
    Vector3 headPos;      // голова (реальная кость)
    Vector3 neckPos;      // шея (интерполяция head<->chest)
    Vector3 spine1Pos;    // грудь
    Vector3 spine2Pos;    // таз (реальная кость: Ragdoll.m_Pelvis либо body)
    Vector3 rshoulderPos; // правое плечо
    Vector3 lshoulderPos; // левое плечо
    Vector3 ruparmPos;    // правый локоть
    Vector3 luparmPos;    // левый локоть
    Vector3 rlowarmPos;   // правая кисть (реальная кость: rightWeaponHolder)
    Vector3 llowarmPos;   // левая кисть  (реальная кость: leftWeaponHolder)
    Vector3 rhipPos, lhipPos;     // бёдра
    Vector3 rkneePos, lkneePos;   // колени
    Vector3 rfootPos, lfootPos;   // стопы
};

// глобальные переменные для кэширования
std::mutex player_data_mutex;
std::vector<PlayerCacheData> cached_players;
bool cache_needs_update = true;
int last_cache_frame = 0;
// Тяжёлый скан памяти (поиск игроков, HP, список) — раз в N кадров.
// Позиция КАЖДОГО игрока + камера пересчитываются КАЖДЫЙ кадр в отрисовке
// (ox_readPos по address), поэтому боксы держатся идеально на бегу и при
// повороте камеры без отставания — тяжёлый скан на это больше не влияет.
const int CACHE_UPDATE_INTERVAL = 3;
// Адрес локального игрока (для покадрового пересчёта камеры вне тяжёлого скана).
uint64_t g_localPlayer = 0;
std::string g_localTeamName;

int getProcessID(const char *packageName)
{
	DIR *dir = opendir("/proc");
	if (!dir) return -1;
	struct dirent *entry;
	while ((entry = readdir(dir)) != NULL)
	{
		int id = atoi(entry->d_name);
		if (id > 0)
		{
			char filename[64];
			snprintf(filename, sizeof(filename), "/proc/%d/cmdline", id);
			FILE *fp = fopen(filename, "r");
			if (fp)
			{
				char cmdline[256] = {0};
				size_t n = fread(cmdline, 1, sizeof(cmdline) - 1, fp);
				fclose(fp);
				if (n > 0 && strcmp(packageName, cmdline) == 0)
				{
					closedir(dir);
					return id;
				}
			}
		}
	}
	closedir(dir);
	return -1;
}

// Проверяет, есть ли в /proc/<pid>/maps строка с подстроко�� module.
static bool pidHasModule(int pid, const char *module) {
	char path[64]; sprintf(path, "/proc/%d/maps", pid);
	FILE* f = fopen(path, "rt");
	if (!f) return false;
	char line[1024];
	bool found = false;
	while (fgets(line, sizeof(line), f)) {
		if (strstr(line, module)) { found = true; break; }
	}
	fclose(f);
	return found;
}

// cmdline процесса начинается с packageName? (обрезает \0-разделённые аргументы).
static bool pidCmdlineMatches(int pid, const char *packageName) {
	char path[64]; sprintf(path, "/proc/%d/cmdline", pid);
	FILE* f = fopen(path, "r");
	if (!f) return false;
	char cmd[128] = {0};
	size_t n = fread(cmd, 1, sizeof(cmd) - 1, f);
	fclose(f);
	if (n == 0) return false;
	cmd[n] = 0;
	// главный процесс: cmdline РОВНО == packageName (сервисы имеют суффикс ":name")
	return strcmp(cmd, packageName) == 0;
}

// Находит ГЛАВНЫЙ процесс игры: среди всех с совпадающим cmdline выбирает тот,
// у которого реально замаплен module (рендер-процесс), иначе — любой совпавший.
// preferModule=nullptr → вернуть первый совпавший (как раньше).
int getGameProcessID(const char *packageName, const char *preferModule) {
	DIR *dir = opendir("/proc");
	if (!dir) return -1;
	struct dirent *entry;
	int firstMatch = -1;
	int best = -1;
	while ((entry = readdir(dir)) != NULL) {
		int id = atoi(entry->d_name);
		if (id <= 0) continue;
		if (!pidCmdlineMatches(id, packageName)) continue;
		if (firstMatch < 0) firstMatch = id;
		if (preferModule && pidHasModule(id, preferModule)) { best = id; break; }
	}
	closedir(dir);
	if (best > 0) return best;
	return firstMatch;
}

uint64_t get_module_base(const char *module_name, int mod) {
	uint64_t returned = 0;
	char path[32];
	sprintf(path, "/proc/%d/maps\0", game_pid);
	char line[1024];
	FILE* maps = fopen(path, "rt");
	if (!maps) return 0;
	while(fgets(line, 1024, maps)) {
		if(strstr(line, module_name) && strstr(line, (mod == 1 ? "r--p" : "r-xp"))) {
			uint64_t start,end;
			sscanf(line, "%lx-%lx",&start,&end);
			returned = start;
			break;
		}
  }
  fclose(maps);
  return returned;
}

// Возвращает АДРЕС САМОГО НИЗКОГО маппинга модуля (простой fallback).
uint64_t get_module_lowest(const char *module_name) {
	uint64_t lowest = 0;
	char path[64];
	sprintf(path, "/proc/%d/maps", game_pid);
	FILE* maps = fopen(path, "rt");
	if (!maps) return 0;
	char line[1024];
	while (fgets(line, sizeof(line), maps)) {
		if (!strstr(line, module_name)) continue;
		uint64_t start = 0, end = 0;
		if (sscanf(line, "%lx-%lx", &start, &end) == 2 && start) {
			if (!lowest || start < lowest) lowest = start;
		}
	}
	fclose(maps);
	return lowest;
}

// ИСТИННАЯ база ELF для RVA. В maps модуль может иметь несколько несвязанных
// кластеров (стороннее mmap файла + реальная загрузка линкером). Реальный —
// тот, где есть исполняемый r-xp сегмент. Берём его файловый offset, вычисляем
// candidate = xp_start - xp_offset, и выбираем offset-0 маппинг того же кластера
// (ближайший к candidate). Так отсекаем «левый» read-only mmap того же файла.
uint64_t get_module_base_real(const char *module_name) {
	char path[64];
	sprintf(path, "/proc/%d/maps", game_pid);
	FILE* maps = fopen(path, "rt");
	if (!maps) return 0;
	char line[1024];

	uint64_t xpStart = 0, xpOff = 0;
	// первый проход: найти исполняемый сегмент модуля
	while (fgets(line, sizeof(line), maps)) {
		if (!strstr(line, module_name)) continue;
		if (!strstr(line, "r-xp")) continue;
		uint64_t s = 0, e = 0, off = 0;
		if (sscanf(line, "%lx-%lx %*s %lx", &s, &e, &off) >= 2) { xpStart = s; xpOff = off; break; }
	}

	if (!xpStart) { // нет исполняемого — падаем на низший
		fclose(maps);
		return get_module_lowest(module_name);
	}

	uint64_t candidate = xpStart - xpOff; // ожидаемая база кластера
	rewind(maps);

	// второй проход: offset-0 маппинг, ближайший к candidate
	uint64_t best = 0, bestDiff = ~0ULL;
	while (fgets(line, sizeof(line), maps)) {
		if (!strstr(line, module_name)) continue;
		uint64_t s = 0, e = 0, off = 0;
		if (sscanf(line, "%lx-%lx %*s %lx", &s, &e, &off) < 2) continue;
		if (off != 0) continue;
		uint64_t diff = (s > candidate) ? (s - candidate) : (candidate - s);
		if (diff < bestDiff) { bestDiff = diff; best = s; }
	}
	fclose(maps);

	// если offset-0 не нашёлся или далеко (>16MB) — используем candidate.
	if (!best || bestDiff > 0x1000000ULL) return candidate;
	return best;
}

// Диагностика: выводит все строки maps, содержащие подстроку.
static void dump_maps_matching(const char *needle, int maxLines) {
	char path[64];
	sprintf(path, "/proc/%d/maps", game_pid);
	FILE* maps = fopen(path, "rt");
	if (!maps) { OXLOGW("maps не открылся для '%s'", needle); return; }
	char line[1024];
	int n = 0;
	while (fgets(line, sizeof(line), maps) && n < maxLines) {
		if (strstr(line, needle)) {
			size_t l = strlen(line);
			if (l && line[l-1] == '\n') line[l-1] = 0;
			OXLOGT("  maps: %s", line);
			n++;
		}
	}
	if (n == 0) OXLOGW("  в maps нет строк с '%s'", needle);
	fclose(maps);
}

// Диапазон маппингов модуля [low, high) и число сегментов.
static void get_module_span(const char *module_name, uint64_t &low, uint64_t &high, int &segs) {
	low = 0; high = 0; segs = 0;
	char path[64]; sprintf(path, "/proc/%d/maps", game_pid);
	FILE* maps = fopen(path, "rt");
	if (!maps) return;
	char line[1024];
	while (fgets(line, sizeof(line), maps)) {
		if (!strstr(line, module_name)) continue;
		uint64_t s = 0, e = 0;
		if (sscanf(line, "%lx-%lx", &s, &e) == 2 && s) {
			if (!low || s < low) low = s;
			if (e > high) high = e;
			segs++;
		}
	}
	fclose(maps);
}

// Форвар��-объявления (определены ниже, в секции чтения списка игроков).
static inline bool ox_isPtr(uint64_t p);
static void ox_className(uint64_t klass, char *out, int outlen);

// Инфо об одном модуле: диапазон, размер, ELF-хедер. Возвращает базу (low).
static uint64_t ox_dumpModule(const char *name) {
	uint64_t low, high; int segs;
	get_module_span(name, low, high, segs);
	uint64_t size = (high > low) ? (high - low) : 0;
	if (!low) { OXLOGW("Модуль '%s' НЕ найден в maps", name); return 0; }
	OXLOGI("%s: base=0x%llx end=0x%llx size=%llu MB (0x%llx) segs=%d",
	       name, (unsigned long long)low, (unsigned long long)high,
	       (unsigned long long)(size >> 20), (unsigned long long)size, segs);
	uint8_t elf[16] = {0};
	if (vm_readv(low, elf, sizeof(elf)))
		OXLOGI("  ELF magic: %02x %02x %02x %02x %s", elf[0], elf[1], elf[2], elf[3],
		       (elf[0]==0x7f && elf[1]=='E' && elf[2]=='L' && elf[3]=='F') ? "OK ELF" : "НЕ ELF!");
	else
		OXLOGW("  ELF-хедер не читается на 0x%llx", (unsigned long long)low);
	dump_maps_matching(name, 12);
	return low;
}

// Разовая диагностика ОБЕИ�� схем доступа за один запуск.
static void ox_moduleInfo() {
	oxlog::section("MODULE INFO — все .so игры");
	dump_maps_matching(".so", 60); // общий обзор: увидеть реальные имена либ

	// ---------- Схема A: il2cpp (реальная база по r-xp кластеру) ----------
	oxlog::section("SCHEME A: il2cpp (libil2cpp.so)");
	ox_dumpModule(ox::MODULE); // общий обзор всех маппингов
	uint64_t baseA = get_module_base_real(ox::MODULE);
	OXLOGI("Истинная база (r-xp кластер) = 0x%llx", (unsigned long long)baseA);
	if (baseA) {
        uint64_t rva = g_playerManagerTypeInfoRVA;
		uint64_t at = baseA + rva;
		uint64_t klass = rpm<uint64_t>(at);
		OXLOGI("[base+RVA(0x%llx)]=0x%llx -> klass=0x%llx",
		       (unsigned long long)rva, (unsigned long long)at, (unsigned long long)klass);
		uint8_t buf[0x40];
		if (vm_readv(at, buf, sizeof(buf)))
			oxlog::hexdump("вокруг base+RVA", at, buf, sizeof(buf));
		if (ox_isPtr(klass)) {
			char cn[96]; ox_className(klass, cn, sizeof(cn));
			OXLOGI("  klass name='%s' %s", cn,
			       (cn[0]) ? "" : "(пусто — RVA неверный для этой версии)");
			// дамп самого klass — увидеть name/namespace/static_fields
			if (vm_readv(klass, buf, sizeof(buf)))
				oxlog::hexdump("Il2CppClass head", klass, buf, sizeof(buf));
		} else {
			OXLOGW("  klass не похож на указатель — RVA либо база неверны");
		}
	}
}

// Ленивый резолв базы libil2cpp.so. Возвращает true если база готова.
static bool ox_ensureBase(bool full) {
	if (il2cpp_base) {
		// Периодически проверяем, что процесс жив и модуль на месте (раз в ~120 кадров).
		static int liveCheck = 0;
		if (++liveCheck >= 120) {
			liveCheck = 0;
			if (!pidHasModule(game_pid, ox::MODULE)) {
				OXLOGW("[base] pid=%d потерял %s — сброс, пере-резолв", game_pid, ox::MODULE);
				il2cpp_base = 0;
				// падаем ниже на пере-резолв PID/базы
			}
		}
		if (il2cpp_base) {
			static bool infoOnce = false;
			if (!infoOnce && full) { infoOnce = true; ox_moduleInfo(); }
			return true;
		}
	}

	// Проверяем, жив ли текущий PID и есть ли у него нужный модуль.
	// Если maps не читается ИЛИ модуля нет — пере-резолвим PID, выбирая ГЛАВНЫЙ
	// проце������с игры (тот, где реально замаплен libil2cpp.so). Игра могла
	// перезапуститься (новый PID) или мы поймали сервисный процесс.
	bool needRePid = (game_pid <= 0) || !pidHasModule(game_pid, ox::MODULE);
	if (needRePid) {
		int np = getGameProcessID(ox::PACKAGE, ox::MODULE);
		if (np > 0 && np != game_pid) {
			OXLOGI("[pid] переключа��сь на процесс с %s: %d -> %d",
			       ox::MODULE, game_pid, np);
			game_pid = np;
		} else if (np <= 0) {
			if (full) OXLOGW("[pid] процесс игры с %s пока не найден (game_pid=%d)",
			                 ox::MODULE, game_pid);
		}
	}

	uint64_t low = get_module_base_real(ox::MODULE);
	if (low) {
		il2cpp_base = low;
		OXLOGI("[base] %s найден: 0x%llx (pid=%d, r-xp кластер)", ox::MODULE,
		       (unsigned long long)il2cpp_base, game_pid);
		return true;
	}

	if (full) {
		OXLOGW("[base] %s ещё не в maps (pid=%d). Диагностика:", ox::MODULE, game_pid);
		dump_maps_matching("il2cpp", 12);
		dump_maps_matching(".so", 4);
	}
	return false;
}

bool aimm;
bool aimvisible = true;
int aimcurbone = 0;
float aimFovPixels = 220.0f;
float aimSmooth = 6.0f;
float aimMaxDistance = 350.0f;
bool aimDrawFov = true;
bool aimPrediction = true;
float aimProjectileSpeed = 250.0f;
float aimLatencyMs = 50.0f;
float aimMaxLeadTime = 0.35f;
// UPDATE 2026/07/31 v20: продвинутое упреждение.
// aimProjectileGravity — падение пули (м/с²). 0 = hitscan (нет дуги). Для
// баллистики (лук/дробовик с дропом) выставить ~9.81..20. Аим поднимает точку
// на величину дропа за время полёта.
float aimProjectileGravity = 0.0f;
// Итеративное схождение упреждения: цель успевает сместиться пока летит пуля,
// а это меняет дистанцию и время полёта. Пара итераций сходится к точке встречи.
int   aimPredictIters = 3;
// bug #4 (crouch): у внешнего чита НЕТ надёжного per-player флага «присел»
// (crouch-state живёт в обфусцированных ECM-компонентах, не reachable от
// PlayerManager, а animator-bool требует вызова метода В процессе). Поэтому
// авто-детект невозможен. Вместо ложного авто-детекта — ручной тумблер:
// когда враги приседают, включаешь его и aim-точка опускается на crouch-дельту.
bool  aimCrouchSafe = false;   // опускать aim-точку (враги присели)
float aimCrouchDrop = 0.45f;   // на сколько метров опустить (стоя ~1.8, сидя ~1.35)

// LOS-чек (аим через стены): если ON — аимбот не наводится на цель, перекрытую
// building piece'ом по ходу луча. ESP при этом рисует цель СИНИМ (невидим) и
// ЗЕЛЁНЫМ (видим) — отдельно от команды/инга.
bool aimCheckWalls = false;  // снят из меню: см. espColorByVisibility
bool aimIgnoreTeammates = false;  // см. espHideTeammates — источник команды пуст
// Валл-чек убран из меню: BuildingPiece.saveList наполняется только на СЕРВЕРЕ
// (OnStartServer), у клиента он пустой by design. Резерв через
// NetworkClient.spawned находит единицы объектов (matched=1..2 из ~50) —
// этого мало для честной проверки стен, поэтому окраска по видимости
// выключена, а не показывает ложную картину.
bool espColorByVisibility = false;
// --- Новый пакет фич (всё на чтении) ---
// Unity Matrix4x4 в памяти лежит column-major: m00 m10 m20 m30 m01 m11 ...
struct OxMat4 { float m[16]; };
// Сила подсветки стекла. Управляет ореолом вокруг панели, цветной дымкой
// внутри неё и яркостью кромок разом — один ползунок на весь материал.
float glowIntensity = 1.0f;
bool espModelAnchor = true; // ESP по трансформам модели вместо серверного тика
// Матричный W2S: берём worldToCameraMatrix/projectionMatrix прямо из нативной
// камеры вместо реконструкции базиса из углов. Смещения ищутся по подписи один
// раз за сессию; если не нашлись — тихо работаем по старому пути.
bool espMatrixW2S  = true;
static OxMat4 g_camVP;          // VP этого кадра
static OxMat4 g_camView;        // сырая view-матрица (для позиции камеры)
static bool   g_camVPValid = false;
static Vector3 g_camPosFromMatrix{0,0,0};
static bool    g_camPosValid = false;

float espBoxYOffset = -1.84f;
// espBoxYOffset (-1.84) калибровался под УГЛОВУЮ проекцию, которая сама вносила
// вертикальный сдвиг. Матричная проекция геометрически верна, поэтому тот же
// оффсет становится чистым смещением бокса на 1.84 м ВНИЗ — ровно симптом
// «игрок выше чем ESP». При активной матрице привязку берём нулевую:
// lastTickPosition — это позиция НОГ, значит низ бокса = pos, верх = pos+1.85.
static inline float ox_boxYOffset() {
    return g_camVPValid ? 0.0f : espBoxYOffset;
}

bool espDistColor  = false; // цвет бокса по дистанции: близко=красный, далеко=синий
bool espArmor      = false; // показывать броню рядом с HP
bool espFlags      = false; // метки Sleeping / Spectating / Prime
bool espHpNumber   = true;  // HP цифрой всегда (а не только когда !=100)
bool radarEnabled  = false; // радар-миникарта 360°
float radarRange   = 150.f; // радиус охвата радара в метрах
float radarSize    = 190.f; // диаметр виджета в пикселях
float radarPos[2]  = {40.f, 320.f}; // позиция левого верхнего угла
float radarAlpha   = 0.55f; // прозрачность подложки

// bug #5: аимбот работает ТОЛЬКО когда игрок целится (ADS/scope). ADS-состояние
// определяем по падению живого FOV ниже базового (FPManager.kYl < _kSQ*ratio) —
// проверяемо offline, не требует icall'ов. По умолчанию ВКЛ (запрос пользователя).
bool aimOnlyADS = true;   // legacy-флаг; теперь производный от aimTriggerMode

// UPDATE 2026/07/31 v22: РЕЖИМ активации аима.
//   0 = Always     — как только цель в FOV
//   1 = ADS/Scope  — только в прицеле (падение живого FOV)
//   2 = On fire    — только когда стреляем (детект по состоянию оружия)
//   3 = ADS + Fire — в прицеле ИЛИ при стрельбе
int aimTriggerMode = 1;   // по умолчанию ADS (как раньше aimOnlyADS=true)

const char* aimbones[] = { "head","neck","body" };

bool check(uint64_t addr) {
	return addr != 0 && addr < 0xffffffffff;
}

std::string utf16le_to_utf8(const std::u16string &u16str) {    
    if (u16str.empty()) {
        return std::string();
    }

    const char16_t *p = u16str.data();   
    std::u16string::size_type len = u16str.length();  
    if (p[0] == 0xFEFF) {      
        p += 1;      
        len -= 1;   
    } 

    std::string u8str;   
    u8str.reserve(len * 3);    
    char16_t u16char;  
    for (std::u16string::size_type i = 0; i < len; ++i) {       
        u16char = p[i];        
        if (u16char < 0x0080) {          
            u8str.push_back((char) (u16char & 0x00FF));          
            continue;       
        }      
        if (u16char >= 0x0080 && u16char <= 0x07FF) {          
            u8str.push_back((char) (((u16char >> 6) & 0x1F) | 0xC0));        
            u8str.push_back((char) ((u16char & 0x3F) | 0x80));          
            continue;       
        }      
        if (u16char >= 0xD800 && u16char <= 0xDBFF) {           
            uint32_t highSur = u16char;          
            uint32_t lowSur = p[++i];          
            uint32_t codePoint = highSur - 0xD800;    
            codePoint <<= 10;        
            codePoint |= lowSur - 0xDC00;      
            codePoint += 0x10000;           
            u8str.push_back((char) ((codePoint >> 18) | 0xF0));     
            u8str.push_back((char) (((codePoint >> 12) & 0x3F) | 0x80));         
            u8str.push_back((char) (((codePoint >> 06) & 0x3F) | 0x80));            
            u8str.push_back((char) ((codePoint & 0x3F) | 0x80));        
            continue;       
        } { 
        u8str.push_back((char) (((u16char >> 12) & 0x0F) | 0xE0));          
        u8str.push_back((char) (((u16char >> 6) & 0x3F) | 0x80));      
        u8str.push_back((char) ((u16char & 0x3F) | 0x80));         
        continue;      
        }    
    }   
    return u8str;
}

[[maybe_unused]] int example() { return 0; }

bool espbox,esphpbar;
float espfillp = 0.f;
float espstroke = 1.0f;   // v24: тоньше (было 2.0)
bool espCornerBox = false;
float espCornerLength = 0.28f;
// Вертикальная привязка бокса. ox_readPos отдаёт PM.lastTickPosition, но у
// какого именно уровня контроллера там pivot (ноги / центр капсулы / голова)
// статически не определить. Наблюдение с устройства: бокс встаёт ВЫШЕ цели,
// значит pivot не на ногах — компенсируем сдвигом вниз. Слайдер в меню
// ESP -> BOX -> Vertical offset, чтобы подобрать вживую без пересборки.

template<typename T>
T get_prop(uint64_t player, const char* tag) {
	T property = NULL;
	uint64_t props = rpm<uint64_t>(get_photon(player) + 0x38);
	if(props) {
		int size = rpm<int>(props + 0x20);
		for(int i = 0; i < size; i++) {
			uint64_t propkey = rpm<uint64_t>(rpm<uint64_t>(props+0x18) + 0x28 + 0x18*i);
			uint64_t propval = rpm<uint64_t>(rpm<uint64_t>(props+0x18) + 0x30 + 0x18*i);
			if(propkey != 0) {
				std::string keyVal = rpm<String>(propkey).Get();
				if(strstr(keyVal.c_str(), tag)) {
					property = rpm<T>(propval + 0x10);
				}
			}
		}
	}
	return property;
}

bool espen;
bool esphpgradient;
bool espweapon;
bool esptracer;
bool espfill;
bool espgradient;
bool esphpoutline = true;
bool espdist = true;
bool esparm;

// Максимальная дальность отрисовки ESP (метры). По умолчанию огромная —
// показываем игроков хоть через всю карту. 0 = без ограничения вообще.
float espMaxDistance = 5000.0f;

// --- ESP Lines / Tracers ---
bool esplines_enabled = false;
float esplines_thickness = 1.0f;   // v24: тоньше (было 2.0)
float esplines_color[3] = {1.0f, 1.0f, 1.0f};
int   esplines_position = 0; // 0=bottom center, 1=crosshair

// --- Настройки камеры для W2S (тюнятся в меню на устройстве) ---
float camFov = 98.607f;     // ГОРИЗОНТАЛЬНЫЙ FOV (град) — откалибровано под игру
bool  camInvertPitch = false;// инвертировать вертикальную ось проекции
bool  camInvertYaw = false;  // инвертировать горизонтальную ось проекции
// FIX bug #3: базис камеры теперь ВСЕГДА из мирового кватерниона m_LookRoot
// (полный yaw+pitch). Legacy-тумблеры pitch-fallback/swap удалены — они
// приводили к двойному применению pitch («боксы уезжают вверх»).

// --- Состояние кастомного меню ---
bool  g_menuOpen  = true;    // открыто ли большое меню (счётчик врагов тумблит)
int   g_activeTab = 0;       // 0=ESP 1=Aim 2=Camera 3=Settings
int   g_accentTheme = 1;     // индекс акцент-темы GLASS UI (0..4); 1 = Violet (магента-родной)

// --- Фильтры и производительность ---
int   g_enemyCount  = 0;     // сколько игроков сейчас в кэше (для счётчика)
int   g_cacheInterval = 10;  // heavy list/HP scan; positions are refreshed separately
int   g_positionInterval = 1;  // рефреш позиций каждый кадр — минимальный drift ESP
// Скрытие тимейтов снято из меню: ни один из трёх источников состава команды
// не заполнен в этом билде (nWc.team=0, TeammateStates пуст, UI-панель тоже).
// Оставлено выключенным, чтобы не тратить чтения на заведомо пустые цепочки.
bool  espHideTeammates = false;
bool espname;
bool esphealth;
bool vischeck;
bool esphat;
bool skeleton = true;    // v26: РЕАЛЬНЫЙ анимированный скелет из lag-comp хитбоксов (eR[]) — ноги/ступни/кисти двигаются. Фолбэк — процедурный. Тумблер в меню ESP.
bool outoffov;
bool oofvis;
bool ESP3D;
bool esp3dcorners;
bool visible;
bool visibleskeleton;

float cornered;
float espround;
float esp3dcornerstroke;
float esphpsize = 3;
float width3d = 1.0f;
float oulinewidth3d = 0.5f;
float hatalpha = 0.200f;
float hatradius = 0.50f;
float hatsegments = 10.f;
float esphptextsize = 0;
bool espdraw;
bool espline;
float espboxcolor[3]={1,0,0};

ImDrawList* getDrawList() {
	return ImGui::GetBackgroundDrawList();
}

struct Vector4 {
	float x,y,z,w;
};

struct TMatrix {
    Vector4 position;
    Quaternion rotation;
    Vector4 scale;
};

static Vector3 getPosition(uint64_t transObj2) {
 uint64_t transObj = rpm<uint64_t>(transObj2 + 0x10);
 
    uint64_t matrix = rpm<uint64_t>(transObj + 0x38);
    uint64_t index = rpm<uint64_t>(transObj + 0x40);
 
    uint64_t matrix_list = rpm<uint64_t>(matrix + 0x18);
    uint64_t matrix_indices = rpm<uint64_t>(matrix + 0x20);
 
    Vector3 result = rpm<Vector3>(matrix_list + sizeof(TMatrix) * index);
    int transformIndex = rpm<int>(matrix_indices + sizeof(int) * index);
 
    while(transformIndex >= 0) {
        TMatrix tMatrix = rpm<TMatrix>(matrix_list + sizeof(TMatrix) * transformIndex);
 
        float rotX = tMatrix.rotation.x;
        float rotY = tMatrix.rotation.y;
        float rotZ = tMatrix.rotation.z;
        float rotW = tMatrix.rotation.w;
 
        float scaleX = result.x * tMatrix.scale.x;
        float scaleY = result.y * tMatrix.scale.y;
        float scaleZ = result.z * tMatrix.scale.z;
 
        result.x = tMatrix.position.x + scaleX +
                    (scaleX * ((rotY * rotY * -2.0) - (rotZ * rotZ * 2.0))) +
                    (scaleY * ((rotW * rotZ * -2.0) - (rotY * rotX * -2.0))) +
                    (scaleZ * ((rotZ * rotX * 2.0) - (rotW * rotY * -2.0)));
        result.y = tMatrix.position.y + scaleY +
                    (scaleX * ((rotX * rotY * 2.0) - (rotW * rotZ * -2.0))) +
                    (scaleY * ((rotZ * rotZ * -2.0) - (rotX * rotX * 2.0))) +
                    (scaleZ * ((rotW * rotX * -2.0) - (rotZ * rotY * -2.0)));
        result.z = tMatrix.position.z + scaleZ +
                    (scaleX * ((rotW * rotY * -2.0) - (rotX * rotZ * -2.0))) +
                    (scaleY * ((rotY * rotZ * 2.0) - (rotW * rotX * -2.0))) +
                    (scaleZ * ((rotX * rotX * -2.0) - (rotY * rotY * 2.0)));
 
        transformIndex = rpm<int>(matrix_indices + sizeof(int) * transformIndex);
    }
 
    return result;
}


// ============================================================================
//  OXIDE: чтение списка игроков через il2cpp static chain (с авто-детектом)
// ============================================================================

// Похоже ли значение на валидный heap/mmap указатель (выровнен, в диапазоне).
static inline bool ox_isPtr(uint64_t p) {
    return p >= 0x1000000000ULL && p < 0x8000000000ULL && (p & 0x3) == 0;
}

// Мягкая проверка указателя (для строк/полей БЕЗ требования выравнивания по 4).
static inline bool ox_isPtrLoose(uint64_t p) {
    return p >= 0x1000000000ULL && p < 0x8000000000ULL;
}

// Читает C-строку имени из Il2CppClass* (klass + CLASS_NAME -> const char*).
static void ox_className(uint64_t klass, char *out, int outlen) {
    out[0] = 0;
    if (!ox_isPtr(klass)) return;
    uint64_t namePtr = rpm<uint64_t>(klass + ox::CLASS_NAME);
    if (!ox_isPtrLoose(namePtr)) return; // строковый указатель может быть невыровнен
    char buf[96] = {0};
    if (!vm_readv(namePtr, buf, sizeof(buf) - 1)) return;
    int i = 0;
    for (; i < outlen - 1 && i < (int)sizeof(buf) - 1; i++) {
        char c = buf[i];
        if (c < 0x20 || (unsigned char)c > 0x7e) break; // только печатные ASCII
        out[i] = c;
    }
    out[i] = 0;
}

struct OxMapRange {
    uint64_t start;
    uint64_t end;
    char perms[5];
    char path[512];
};

// Snapshot /proc/<pid>/maps. Called only by the manual runtime resolver.
static void ox_collectMaps(std::vector<OxMapRange> &out, const char *pathFilter,
                           bool writableOnly, size_t maxBytes, bool anonOnly = false) {
    out.clear();
    char procPath[64]; snprintf(procPath, sizeof(procPath), "/proc/%d/maps", game_pid);
    FILE *maps = fopen(procPath, "rt");
    if (!maps) return;
    size_t total = 0;
    char line[1024];
    while (fgets(line, sizeof(line), maps)) {
        OxMapRange map{};
        unsigned long long start = 0, end = 0;
        char path[512] = {};
        int parsed = sscanf(line, "%llx-%llx %4s %*llx %*s %*s %511[^\n]",
                            &start, &end, map.perms, path);
        if (parsed < 3 || end <= start || map.perms[0] != 'r') continue;
        if (writableOnly && map.perms[1] != 'w') continue;
        if (pathFilter && *pathFilter && !strstr(path, pathFilter)) continue;
        if (anonOnly) {
            // Только анонимные регионы: расшифрованные метаданные/строки живут тут.
            if (path[0] != 0 && path[0] != '[') continue;
            // Пропускаем гигантские регионы (GC-куча) — имён классов там нет.
            if ((unsigned long long)(end - start) > 128ULL * 1024 * 1024) continue;
        }
        size_t size = (size_t)(end - start);
        if (size > maxBytes || total > maxBytes - size) continue;
        map.start = start;
        map.end = end;
        snprintf(map.path, sizeof(map.path), "%s", path);
        out.push_back(map);
        total += size;
    }
    fclose(maps);
}

// UPDATE 2026/07/31 v7: находит РЕАЛЬНЫЙ base адрес global-metadata.dat в памяти игры
// через /proc/<pid>/maps. Игра mmap'ит файл в свой процесс, mapping попадает в maps с
// path типа "/data/app/.../assets/bin/Data/Managed/Metadata/global-metadata.dat".
// Возвращает start_address первого такого mapping. 0 если не нашли (metadata ещё не
// подгружен либо игра сама расшифровала файл в анон-память — второе редкость для v39).
//
// Этот путь ЗАМЕНЯЕТ старую fast-seed цепочку OX_META_BASE_PTR_RVA (которая в новой
// сборке 2026-07-31 указывает не на metadata_base, а на какую-то внутреннюю таблицу
// libil2cpp — см. v5-лог: nameVa @ 0x6e9af44360 содержит ARM64-инструкции, не строку).
static uint64_t ox_findMetadataMmapBase() {
    char path[64];
    snprintf(path, sizeof(path), "/proc/%d/maps", game_pid);
    FILE *maps = fopen(path, "rt");
    if (!maps) return 0;
    char line[2048];
    uint64_t first_base = 0;
    while (fgets(line, sizeof(line), maps)) {
        // Ищем строки заканчивающиеся на "/global-metadata.dat" (mmap file mapping)
        if (!strstr(line, "global-metadata.dat")) continue;
        // Формат /proc/*/maps: "START-END perms offset dev inode  /path"
        // Берём только r-- mappings (metadata mmap'ится PROT_READ).
        unsigned long long s = 0, e = 0;
        char perms[8] = {0};
        if (sscanf(line, "%llx-%llx %7s", &s, &e, perms) < 3) continue;
        if (perms[0] != 'r') continue;
        // Хотим первый mmap (offset=0), проверяем что offset==0
        unsigned long long off = 0;
        if (sscanf(line, "%llx-%llx %*s %llx", &s, &e, &off) < 3) continue;
        if (off == 0) {
            first_base = s;
            break;
        }
        // fallback: если offset != 0 (какая-то фрагментация), берём первый попавшийся
        if (first_base == 0) first_base = s - off;
    }
    fclose(maps);
    return first_base;
}

static bool ox_asciiEquals(uint64_t address, const char *expected) {
    if (!ox_isPtrLoose(address) || !expected) return false;
    size_t length = strlen(expected);
    if (!length || length > 120) return false;
    char value[128] = {};
    return vm_readv(address, value, length + 1) &&
           memcmp(value, expected, length) == 0 && value[length] == 0;
}

// Searches mapped memory for an ASCII literal (with NUL) and returns addresses.
static void ox_findAscii(const std::vector<OxMapRange> &maps, const char *needle,
                         std::vector<uint64_t> &matches, size_t maxMatches) {
    matches.clear();
    const size_t needleLen = strlen(needle) + 1;
    if (needleLen < 2) return;
    // Больший чанк (4 MB) + memmem() glibc — SIMD-оптимизирован под ARM64,
    // на порядок быстрее ручного memcmp-по-байту в цикле (лог 2026-07-24
    // показал 8 MB/сек на прошлом slot-переборе; memmem даёт 200+ MB/сек).
    const size_t chunkSize = 4 * 1024 * 1024;
    std::vector<uint8_t> buffer(chunkSize + needleLen);
    for (const OxMapRange &map : maps) {
        size_t carry = 0;
        for (uint64_t at = map.start; at < map.end && matches.size() < maxMatches;) {
            if (ox_scanTimedOut()) return;
            size_t want = (size_t)std::min<uint64_t>(chunkSize, map.end - at);
            if (!vm_readv(at, buffer.data() + carry, want)) { carry = 0; at += want; continue; }
            size_t total = carry + want;
            // memmem — сплошной sub-string поиск glibc. Возвращает первое
            // вхождение или NULL; сдвигаем указатель на +1 и ищем следующее.
            const uint8_t *base = buffer.data();
            const uint8_t *cursor = base;
            size_t remaining = total;
            while (matches.size() < maxMatches) {
                void *hit = memmem(cursor, remaining, needle, needleLen);
                if (!hit) break;
                size_t off = (const uint8_t*)hit - base;
                matches.push_back(at - carry + off);
                cursor = (const uint8_t*)hit + 1;
                if (cursor >= base + total) break;
                remaining = total - (cursor - base);
            }
            carry = std::min(needleLen - 1, total);
            memmove(buffer.data(), buffer.data() + total - carry, carry);
            at += want;
        }
    }
}

// Finds Il2CppClass by its name/namespace: class+0x10 points to name, class+0x18
// points to namespace. Class objects are in writable managed runtime mappings.
static uint64_t ox_findClassByName(uint64_t nameAddress, const char *className,
                                   const char *nameSpace, const std::vector<OxMapRange> &rwMaps) {
    const size_t chunkSize = 1024 * 1024;
    std::vector<uint8_t> buffer(chunkSize);
    for (const OxMapRange &map : rwMaps) {
        for (uint64_t at = map.start; at < map.end;) {
            if (ox_scanTimedOut()) return 0;
            size_t want = (size_t)std::min<uint64_t>(chunkSize, map.end - at);
            if (!vm_readv(at, buffer.data(), want)) { at += want; continue; }
            for (size_t i = 0; i + sizeof(uint64_t) <= want; i += sizeof(uint64_t)) {
                uint64_t value = 0;
                memcpy(&value, buffer.data() + i, sizeof(value));
                if (value != nameAddress || at + i < ox::CLASS_NAME) continue;
                uint64_t klass = at + i - ox::CLASS_NAME;
                uint64_t namespaceAddress = rpm<uint64_t>(klass + ox::CLASS_NAMESPACE);
                bool nsOk = (nameSpace == nullptr) || ox_asciiEquals(namespaceAddress, nameSpace);
                if (nsOk && ox_asciiEquals(rpm<uint64_t>(klass + ox::CLASS_NAME), className))
                    return klass;
            }
            at += want;
        }
    }
    return 0;
}

// НАДЁЖНЫЙ поиск Il2CppClass: перебираем 8-байтовые слоты, трактуя значение как
// name-указатель. Если оно ведёт в пул строк и strcmp совпал — это klass+0x10.
// Не зависит от того, какую именно копию имени держит класс (каноничную из
// блоба метадаты), поэтому чинит прошлый "класс не найден" при найденных литералах.
//
// Кооперативный deadline: если ox_setScanDeadline(N) выставлен, скан свернётся
// после его истечения и вернёт 0 — исключает подвисание фона на десятки минут
// при сканировании многогигабайтной кучи Unity.
static uint64_t ox_scanClassByName(const char *className, const char *nameSpace,
                                   const std::vector<OxMapRange> &scanMaps,
                                   uint64_t strLo, uint64_t strHi) {
    // 4 MB чанки — меньше системных вызовов vm_readv (в 4 раза меньше сисколов);
    // прошлые 1 MB давали 8 MB/сек, 4 MB чанки в тестах ускоряют до ~30 MB/сек.
    const size_t chunkSize = 4 * 1024 * 1024;
    std::vector<uint8_t> buffer(chunkSize);
    uint64_t regionsSeen = 0, regionsScanned = 0, bytesScanned = 0;
    for (const OxMapRange &map : scanMaps) {
        regionsSeen++;
        uint64_t sz = map.end - map.start;
        if (sz > 128ULL * 1024 * 1024) {
            OXLOGT("[scan] %s: skip region 0x%llx..0x%llx (%llu MB) — GC-heap",
                   className, (unsigned long long)map.start, (unsigned long long)map.end,
                   (unsigned long long)(sz >> 20));
            continue;
        }
        regionsScanned++;
        OXLOGT("[scan] %s: region %llu/%llu 0x%llx..0x%llx (%llu KB)",
               className, (unsigned long long)regionsScanned, (unsigned long long)scanMaps.size(),
               (unsigned long long)map.start, (unsigned long long)map.end,
               (unsigned long long)(sz >> 10));
        for (uint64_t at = map.start; at < map.end;) {
            if (ox_scanTimedOut()) {
                OXLOGW("[scan] %s: TIMEOUT после %llu регионов / %llu MB",
                       className, (unsigned long long)regionsScanned,
                       (unsigned long long)(bytesScanned >> 20));
                return 0;
            }
            size_t want = (size_t)std::min<uint64_t>(chunkSize, map.end - at);
            if (!vm_readv(at, buffer.data(), want)) { at += want; continue; }
            bytesScanned += want;
            for (size_t i = 0; i + sizeof(uint64_t) <= want; i += sizeof(uint64_t)) {
                uint64_t namePtr = 0;
                memcpy(&namePtr, buffer.data() + i, sizeof(namePtr));
                if (namePtr < strLo || namePtr >= strHi) continue; // должен вести в пул строк
                if (at + i < ox::CLASS_NAME) continue;
                if (!ox_asciiEquals(namePtr, className)) continue;
                uint64_t klass = at + i - ox::CLASS_NAME;
                uint64_t nsPtr = rpm<uint64_t>(klass + ox::CLASS_NAMESPACE);
                if (nameSpace && !ox_asciiEquals(nsPtr, nameSpace)) continue;
                OXLOGI("[scan] %s.%s FOUND klass=0x%llx после %llu MB",
                       nameSpace ? nameSpace : "*", className,
                       (unsigned long long)klass, (unsigned long long)(bytesScanned >> 20));
                return klass;
            }
            at += want;
        }
    }
    OXLOGT("[scan] %s: not found после %llu MB (%llu регионов)",
           className, (unsigned long long)(bytesScanned >> 20),
           (unsigned long long)regionsScanned);
    return 0;
}

// Finds the writable libil2cpp TypeInfo slot containing klass and converts its
// runtime address to an RVA from il2cpp_base. Уважает deadline из
// ox_setScanDeadline().
static uint64_t ox_findTypeInfoRVA(uint64_t klass, const std::vector<OxMapRange> &libRwMaps) {
    const size_t chunkSize = 1024 * 1024;
    std::vector<uint8_t> buffer(chunkSize);
    for (const OxMapRange &map : libRwMaps) {
        for (uint64_t at = map.start; at < map.end;) {
            if (ox_scanTimedOut()) return 0;
            size_t want = (size_t)std::min<uint64_t>(chunkSize, map.end - at);
            if (!vm_readv(at, buffer.data(), want)) { at += want; continue; }
            for (size_t i = 0; i + sizeof(uint64_t) <= want; i += sizeof(uint64_t)) {
                uint64_t value = 0;
                memcpy(&value, buffer.data() + i, sizeof(value));
                if (value == klass && at + i >= il2cpp_base)
                    return at + i - il2cpp_base;
            }
            at += want;
        }
    }
    return 0;
}

// Forward-decl: sweep вызывает auto-resolve, а тот определён ниже.
static bool ox_autoResolveTypeInfo(const char *className, const char *nameSpace,
                                   uint64_t &outRVA, uint64_t &outKlass, bool full);

// Runtime-скан ВСЕХ известных TypeInfo (по именам + namespace), с записью
// найденного RVA в лог. Служит источником свежих RVA для oxide_offsets.h после
// обновления игры — erafox прочитает Download-лог и обновит хардкод.
static void ox_sweepAllTypeInfos(bool full) {
    struct Known { const char *ns; const char *name; };
    static const Known kKnown[] = {
        {"Oxide",           "PlayerManager"},
        {"Oxide.Building",  "BuildingPiece"},
        {"Oxide",           "PlayerVitals"},
        {"Oxide",           "GenericVitals"},
        {"Oxide",           "EntityVitals"},
        {"Oxide",           "MouseLook"},
        {"Oxide",           "RaycastManager"},
        {"Oxide.Weapons",   "WeaponRecoil"},
        {"Oxide.Weapons",   "FPHitscan"},
        {"UnityEngine",     "Camera"},
        {"UnityEngine",     "Transform"},
    };
    oxlog::section("TYPEINFO SWEEP (runtime)");
    for (const Known &k : kKnown) {
        if (ox_scanTimedOut()) { OXLOGW("[sweep] deadline, дальше не сканируем"); break; }
        uint64_t rva = 0, klass = 0;
        bool ok = ox_autoResolveTypeInfo(k.name, k.ns, rva, klass, full);
        OXLOGI("[sweep] %-24s ns=%-16s -> klass=0x%llx  TypeInfoRVA=0x%llx  %s",
               k.name, k.ns, (unsigned long long)klass, (unsigned long long)rva,
               ok ? "OK" : "MISS");
    }
    OXLOGI("[sweep] завершён. Скопируй RVA в include/oxide_offsets.h если правишь fallback.");
}

// On-demand recovery of TypeInfo RVAs after a game update. First finds the
// literal in libil2cpp mappings, then Il2CppClass in writable runtime memory,
// and finally the TypeInfo pointer slot in libil2cpp's writable data segment.
static bool ox_autoResolveTypeInfo(const char *className, const char *nameSpace,
                                   uint64_t &outRVA, uint64_t &outKlass, bool full) {
    std::vector<OxMapRange> libReadMaps, rwMaps, libRwMaps, anonMaps;
    // Имена классов в защищённом билде расшифрованы в АНОНИМНУЮ память,
    // а НЕ в file-backed libil2cpp.so — поэтому прежний поиск давал 0 литералов.
    ox_collectMaps(anonMaps, nullptr, false, 1024ULL * 1024 * 1024, /*anonOnly=*/true);
    ox_collectMaps(libReadMaps, ox::MODULE, false, 768ULL * 1024 * 1024);
    ox_collectMaps(rwMaps, nullptr, true, 1024ULL * 1024 * 1024);
    ox_collectMaps(libRwMaps, ox::MODULE, true, 256ULL * 1024 * 1024);
    if (rwMaps.empty() && anonMaps.empty()) return false;

    // Границы пула строк (анонимная расшифрованная метадата + сама libil2cpp).
    uint64_t strLo = ~0ULL, strHi = 0;
    for (const OxMapRange &m : anonMaps)    { if (m.start < strLo) strLo = m.start; if (m.end > strHi) strHi = m.end; }
    for (const OxMapRange &m : libReadMaps) { if (m.start < strLo) strLo = m.start; if (m.end > strHi) strHi = m.end; }
    // ПЕРВЫЙ, надёжный путь: скан самих Il2CppClass со сравнением содержимого имени.
    if (strHi > strLo) {
        uint64_t klass = ox_scanClassByName(className, nameSpace, rwMaps, strLo, strHi);
        if (!klass) klass = ox_scanClassByName(className, nameSpace, anonMaps, strLo, strHi);
        if (!klass) klass = ox_scanClassByName(className, nullptr, rwMaps, strLo, strHi);
        if (klass) {
            outKlass = klass;
            uint64_t rva = ox_findTypeInfoRVA(klass, libRwMaps);
            if (rva) outRVA = rva;
            if (full) OXLOGI("[AUTO] %s.%s: klass=0x%llx (scan) TypeInfoRVA=0x%llx%s",
                             nameSpace, className, (unsigned long long)klass,
                             (unsigned long long)rva, rva ? "" : " (RVA n/a - klass \u043d\u0430\u043f\u0440\u044f\u043c\u0443\u044e)");
            return true;
        }
    }

    // Литерал имени ищем сперва в анонимной памяти (расшифрованный пул строк),
    // затем в самой libil2cpp (на случай незашифрованного билда).
    std::vector<uint64_t> nameAddresses;
    ox_findAscii(anonMaps, className, nameAddresses, 16);
    if (nameAddresses.empty()) ox_findAscii(libReadMaps, className, nameAddresses, 16);
    if (full) OXLOGI("[AUTO] %s: литералов=%zu (anon-рег.=%zu, lib-рег.=%zu)",
                     className, nameAddresses.size(), anonMaps.size(), libReadMaps.size());
    for (uint64_t nameAddress : nameAddresses) {
        uint64_t klass = ox_findClassByName(nameAddress, className, nameSpace, rwMaps);
        if (!klass) klass = ox_findClassByName(nameAddress, className, nameSpace, anonMaps);
        if (!klass) klass = ox_findClassByName(nameAddress, className, nullptr, rwMaps); // без namespace
        if (!klass) continue;
        // Указателя klass уже достаточно для чтения static_fields — успех здесь.
        outKlass = klass;
        uint64_t rva = ox_findTypeInfoRVA(klass, libRwMaps); // опционально (для диагностики)
        if (rva) outRVA = rva;
        if (full) OXLOGI("[AUTO] %s.%s: klass=0x%llx TypeInfoRVA=0x%llx%s",
                         nameSpace, className, (unsigned long long)klass,
                         (unsigned long long)rva,
                         rva ? "" : " (RVA n/a — читаем klass напрямую)");
        return true;
    }
    if (full) OXLOGW("[AUTO] %s.%s: класс не найден в памяти (не в матче?)", nameSpace, className);
    return false;
}

// Offline-baked class name offsets в global-metadata.dat (из decrypted split-zip
// metadata, декодировано Nov/typeinfo_offline.py + string table @0xdc0ec).
// В рантайме: expected_name_va = metadata_base + оффсет ниже.
// UPDATE 2026/07/24: name-offsets = STR_OFF(0xDBE2C) + nameIndex. Класс-имя в
// строковой таблице (metadata_base + offset). Пересчитано под NEW metadata.
// UPDATE 2026/07/31: metadata пересобрана, strings-таблица сдвинута.
// Verified via `grep -abo "PlayerManager\x00" global-metadata.dat` — берём позицию, где сразу
// перед и после ASCII \x00 (packed nul-terminated table).
static constexpr uint64_t OX_META_NAME_OFF_PLAYERMANAGER = 0x17e504;  // "PlayerManager" (was 0x171ebc)
static constexpr uint64_t OX_META_NAME_OFF_BUILDINGPIECE = 0x11713e;  // "BuildingPiece" (was 0x10c433)
static constexpr uint64_t OX_META_NAME_OFF_PLAYERVITALS  = 0x1770dc;  // "PlayerVitals"  (was 0x16aebf)

// Резолвит Il2CppClass* через ПОИСК ССЫЛКИ на имя класса в libil2cpp writable.
// Не сканирует анон-память игры (что убивает игру через watchdog CatsBit'а).
// Bulk-read libRw одним vm_readv, локальный поиск слота содержащего known name-VA.
// Найденный слот - 0x10 = Il2CppClass* (CLASS_NAME field lives at klass+0x10).
static uint64_t ox_findKlassByNameVa(uint64_t nameVa,
                                     const std::vector<OxMapRange> &libRwMaps) {
    // UPDATE 2026/07/31 v9: БЫЛ БАГ — `if (sz > 16MB) continue` пропускал большие
    // регионы. Il2CppClass-структуры живут в class-heap, который БОЛЬШЕ 16 MB, поэтому
    // сканер их никогда не видел (v8-лог: "строка есть, но pointer не нашёл").
    // Теперь читаем чанками по 8 MB, большие регионы НЕ пропускаем.
    const size_t CHUNK = 8ULL * 1024 * 1024;
    std::vector<uint8_t> buf(CHUNK);
    for (const OxMapRange &m : libRwMaps) {
        if (m.end <= m.start) continue;
        for (uint64_t at = m.start; at < m.end; ) {
            if (ox_scanTimedOut()) return 0;
            size_t want = (size_t)std::min<uint64_t>(CHUNK, m.end - at);
            if (!vm_readv(at, buf.data(), want)) { at += want; continue; }
            for (size_t off = 0; off + 8 <= want; off += 8) {
                uint64_t v;
                memcpy(&v, buf.data() + off, 8);
                if (v == nameVa) {
                    uint64_t slot_va = at + off;
                    uint64_t klass = slot_va - ox::CLASS_NAME;  // slot = klass->name field
                    if (ox_isPtr(klass)) return klass;
                }
            }
            // Перекрытие на 8 байт чтобы не пропустить pointer на границе чанка.
            at += (want >= 8) ? (want - 8 + 8) : want;
            if (want < CHUNK) break;
        }
    }
    return 0;
}

// UPDATE 2026/07/31 v9: надёжный резолвер класса. Не полагается ни на s_TypeInfoTable,
// ни на конкретную копию metadata. Находит ВСЕ копии "className\0" во всех readable
// регионах, для каждой ищет указатель (chunked, без cap по размеру региона), верифицирует
// Il2CppClass layout: klass+0x10=name(className), klass+0x18=namespace(wantNs).
static uint64_t ox_resolveKlassRobust(const char *className, const char *wantNs) {
    // Собираем ВСЕ readable регионы игры (RO + RW), без path-фильтра, без cap.
    std::vector<OxMapRange> allMaps;
    {
        char procPath[64]; snprintf(procPath, sizeof(procPath), "/proc/%d/maps", game_pid);
        FILE *maps = fopen(procPath, "rt");
        if (!maps) return 0;
        char line[2048];
        while (fgets(line, sizeof(line), maps)) {
            OxMapRange map{};
            unsigned long long start = 0, end = 0;
            char path[512] = {};
            int parsed = sscanf(line, "%llx-%llx %4s %*llx %*s %*s %511[^\n]",
                                &start, &end, map.perms, path);
            if (parsed < 3 || end <= start || map.perms[0] != 'r') continue;
            // Пропускаем device-mapped / очень крупные GPU/dma регионы (>512MB) —
            // klass там не бывает и чтение может зависнуть.
            if ((unsigned long long)(end - start) > 512ULL * 1024 * 1024) continue;
            map.start = start; map.end = end;
            snprintf(map.path, sizeof(map.path), "%s", path);
            allMaps.push_back(map);
        }
        fclose(maps);
    }

    // 1) Найти все копии строки имени (во всех регионах — строка может быть в RO metadata).
    std::vector<uint64_t> nameVAs;
    ox_findAscii(allMaps, className, nameVAs, /*maxMatches=*/64);
    if (nameVAs.empty()) {
        OXLOGW("[robust] %s: строка не найдена ни в одном регионе (metadata не загружен?)", className);
        return 0;
    }
    // Сортируем для бинарного поиска в hot-loop.
    std::sort(nameVAs.begin(), nameVAs.end());

    // UPDATE 2026/07/31 v11: ОДИН проход по RW/anon-heap регионам вместо
    // O(copies × all_regions). v10-регрессия: 17 копий × 4828 регионов не влезали
    // в 20-сек дедлайн и класс переставал резолвиться (боксы пропали совсем).
    // Il2CppClass-структуры живут в WRITABLE anon-heap, поэтому:
    //   - строку ищем везде (RO metadata + anon),
    //   - УКАЗАТЕЛЬ на строку ищем только в RW+anon регионах (class-heap),
    //   - за один проход: для каждого 8-байт значения проверяем, входит ли оно в
    //     множество копий имени (binary_search). O(heap) вместо O(copies*heap).
    std::vector<OxMapRange> scanMaps;
    for (const OxMapRange &m : allMaps) {
        bool writable = (m.perms[1] == 'w');
        bool soData   = (strstr(m.path, ".so") != nullptr); // .data/.bss библиотек
        bool anon     = (m.path[0] == 0 || m.path[0] == '[');
        if (writable || soData || anon) scanMaps.push_back(m);
    }
    OXLOGI("[robust] %s: %zu копий строки, один проход по %zu RW/anon регионам (из %zu)",
           className, nameVAs.size(), scanMaps.size(), allMaps.size());

    // UPDATE 2026/07/31 v12: ДВУХУРОВНЕВЫЙ выбор по namespace.
    // v11-регрессия: single-pass находил ПЕРВЫЙ name-match, а им оказывался ложный
    // klass с ns='' (структура со ссылкой на копию строки в metadata mmap, не Il2CppClass).
    // v9 работал потому что перебор копий случайно приходил к настоящему классу с
    // ns='Oxide'. Теперь: exact-ns match возвращаем сразу; klass с пустым/нечитаемым
    // ns запоминаем как fallback и продолжаем искать точный. Это гарантирует
    // PlayerManager → ns='Oxide' (правильный), а классам с реально пустым ns
    // (BuildingPiece в этой сборке) fallback всё равно даёт ответ.
    const size_t CHUNK = 8ULL * 1024 * 1024;
    std::vector<uint8_t> buf(CHUNK);
    uint64_t fallbackKlass = 0;          // klass с ns='' (на случай если exact-ns нет)
    uint64_t fallbackNameVa = 0;
    const char *fallbackRegion = "[anon]";
    for (const OxMapRange &m : scanMaps) {
        for (uint64_t at = m.start; at < m.end; ) {
            if (ox_scanTimedOut()) {
                OXLOGW("[robust] %s: дедлайн скана истёк (heap большой)", className);
                break;
            }
            size_t want = (size_t)std::min<uint64_t>(CHUNK, m.end - at);
            if (!vm_readv(at, buf.data(), want)) { at += want; continue; }
            for (size_t off = 0; off + 8 <= want; off += 8) {
                uint64_t v;
                memcpy(&v, buf.data() + off, 8);
                if (v < nameVAs.front() || v > nameVAs.back()) continue;
                if (!std::binary_search(nameVAs.begin(), nameVAs.end(), v)) continue;
                uint64_t slot_va = at + off;
                uint64_t klass = slot_va - ox::CLASS_NAME;
                if (!ox_isPtr(klass)) continue;
                uint64_t np = rpm<uint64_t>(klass + ox::CLASS_NAME);
                if (!ox_asciiEquals(np, className)) continue;
                char ns[96] = {0};
                uint64_t nsPtr = rpm<uint64_t>(klass + ox::CLASS_NAMESPACE);
                if (ox_isPtrLoose(nsPtr)) vm_readv(nsPtr, ns, sizeof(ns) - 1);

                if (wantNs && wantNs[0] && ns[0] && strcmp(ns, wantNs) == 0) {
                    // Точное совпадение namespace — это ТОЧНО нужный класс.
                    OXLOGI("[robust] %s: НАЙДЕН klass=0x%llx ns='%s' nameVa=0x%llx region=%s (exact-ns)",
                           className, (unsigned long long)klass, ns,
                           (unsigned long long)v, m.path[0] ? m.path : "[anon]");
                    return klass;
                }
                if (ns[0] == 0 && !fallbackKlass) {
                    // Пустой/нечитаемый ns — запоминаем, но продолжаем искать точный.
                    fallbackKlass = klass;
                    fallbackNameVa = v;
                    fallbackRegion = m.path[0] ? "[file]" : "[anon]";
                }
                // ns читается и НЕ совпал → это чужой класс, пропускаем.
            }
            if (want < CHUNK) break;
            at += want - 8;
        }
        if (ox_scanTimedOut()) break;
    }

    if (fallbackKlass) {
        OXLOGI("[robust] %s: НАЙДЕН klass=0x%llx ns='' nameVa=0x%llx region=%s (fallback, точного ns не было)",
               className, (unsigned long long)fallbackKlass,
               (unsigned long long)fallbackNameVa, fallbackRegion);
        return fallbackKlass;
    }
    OXLOGW("[robust] %s: указатель на строку не найден в RW/anon (CatsBit шифрует Il2CppClass?)",
           className);
    return 0;
}

// Fast-seed через offline MetadataCache chain (10 read'ов total, БЕЗ сканов).
//
// Оффлайн-разбор libil2cpp.so через capstone нашёл цепочку резолва TDI → klass,
// которую собственный код игры использует (функция @0x4d777f0 в libil2cpp,
// сравнимо с MetadataCache::GetTypeInfoFromTypeDefinitionIndex):
//
//   1) metadata_base = *(base + 0xbf81008)         ; загруженный global-metadata
//   2) header_ptr    = *(base + 0xbf81010)         ; Il2CppGlobalMetadataHeader
//   3) stride        = *(base + 0xbf8101c)         ; 1/2/4 байта на индекс
//   4) types_off_raw = *(header_ptr + 0xec)        ; XOR-encrypted оффсет
//   5) types_off     = types_off_raw ^ 0xA5C3F19D  ; decrypt (per README)
//   6) mc            = *(base + 0xbf80ff8)         ; MetadataCache*
//   7) s_TypeInfoTable = *(mc + 0x38)              ; Il2CppClass**
//   Один раз на всё, кэшируется. Дальше на класс:
//   8) ext_idx = *(metadata_base + types_off + TDI*stride)   ; u8/u16/u32
//   9) klass   = *(s_TypeInfoTable + ext_idx * 8)
//   10) validate: ox_className(klass) == expected_name
//
// UPDATE 2026/07/24: слоты сместились. Найдены offline-дизасмом NEW libil2cpp
// GetTypeInfoFromTypeDefinitionIndex (@0x4DFF360) + MetadataCache::Initialize
// (@0x4DFF4F8). XOR-ключ хедера 0xA5C3F19D — НЕ изменился (тот же movz/movk в коде).
//   OLD -> NEW: MC 0xbe3bb10->0xbf80ff8, base 0xbe3bb20->0xbf81008,
//   header 0xbe3bb28->0xbf81010, stride 0xbe3bb34->0xbf8101c,
//   s_TypeInfoTable 0xbe3bb58->0xbf80ff0. Все в .bss (RW, null в файле).
//
// Watchdog CatsBit'а срабатывает на ОБЪЁМ vm_readv (сравнение старой vs новой
// версии cheat'а: старая ~400 read'ов на резолв, новая — ~200 МБ scan). Здесь
// суммарно ~13 read'ов на 2 класса — не должен видеть.
static constexpr uint64_t OX_META_MC_RVA         = 0xbf613f8;  // was 0xbf80ff8
static constexpr uint64_t OX_META_BASE_PTR_RVA   = 0xbf61408;  // was 0xbf81008
static constexpr uint64_t OX_META_HEADER_PTR_RVA = 0xbf61410;  // was 0xbf81010
static constexpr uint64_t OX_META_STRIDE_RVA     = 0xbf6141c;  // was 0xbf8101c
static constexpr uint32_t OX_META_HEADER_TYPES_FIELD = 0xec;
static constexpr uint32_t OX_META_XOR_KEY        = 0xA5C3F19D;
static constexpr uint64_t OX_MC_TYPEINFOTABLE_OFF = 0x38;

// Кэш стартап-констант (заполняется один раз, читается на каждый резолв).
static uint64_t g_metadataBase   = 0;
static uint64_t g_typesTableAddr = 0;
static uint32_t g_typeStride     = 0;
static uint64_t g_sTypeInfoTable = 0;

static bool ox_cacheMetadataChain() {
    if (!il2cpp_base) return false;
    if (g_metadataBase && g_typesTableAddr && g_typeStride && g_sTypeInfoTable) return true;

    uint64_t meta   = rpm<uint64_t>(il2cpp_base + OX_META_BASE_PTR_RVA);
    uint64_t hdr    = rpm<uint64_t>(il2cpp_base + OX_META_HEADER_PTR_RVA);
    uint32_t stride = rpm<uint32_t>(il2cpp_base + OX_META_STRIDE_RVA);
    if (!ox_isPtr(meta) || !ox_isPtr(hdr) || stride == 0 || stride > 4) {
        OXLOGW("[chain] MetadataCache pointers ещё не установлены (meta=0x%llx hdr=0x%llx stride=%u)",
               (unsigned long long)meta, (unsigned long long)hdr, stride);
        return false;
    }

    uint32_t off_raw = rpm<uint32_t>(hdr + OX_META_HEADER_TYPES_FIELD);
    uint32_t off_dec = off_raw ^ OX_META_XOR_KEY;

    uint64_t mc = rpm<uint64_t>(il2cpp_base + OX_META_MC_RVA);
    if (!ox_isPtr(mc)) {
        OXLOGW("[chain] MetadataCache pointer ещё null (mc=0x%llx)", (unsigned long long)mc);
        return false;
    }

    // === DIAGNOSTIC: пробуем ВСЕ MC offsets в диапазоне, где может лежать
    // s_TypeInfoTable. Для каждого читаем ext_idx для PM (TDI 8357, UPDATE 2026/07/24),
    // берём klass, дампим 64 байта. По логу видно какой offset реально даёт
    // Il2CppClass с валидным именем. (OX_TDI_PLAYERMANAGER объявлен ниже — тут литерал.)
    static bool s_diagLogged = false;
    if (!s_diagLogged) {
        s_diagLogged = true;
        uint64_t enc_addr_pm = meta + off_dec + 8357ULL * stride;
        uint32_t ext_idx_pm = (stride == 4 ? rpm<uint32_t>(enc_addr_pm) :
                              stride == 2 ? (uint32_t)rpm<uint16_t>(enc_addr_pm) :
                                            (uint32_t)rpm<uint8_t>(enc_addr_pm));
        OXLOGI("[chain-diag] meta=0x%llx hdr=0x%llx mc=0x%llx types_off=0x%x stride=%u ext_idx_pm(TDI=8357)=%u",
               (unsigned long long)meta, (unsigned long long)hdr,
               (unsigned long long)mc, off_dec, stride, ext_idx_pm);
        for (uint64_t mc_off : {0x18ULL, 0x20ULL, 0x28ULL, 0x30ULL, 0x38ULL, 0x40ULL, 0x48ULL, 0x50ULL, 0x58ULL, 0x60ULL}) {
            uint64_t table = rpm<uint64_t>(mc + mc_off);
            if (!ox_isPtr(table)) {
                OXLOGD("[chain-diag] MC+0x%llx = 0x%llx (не указатель)", mc_off, (unsigned long long)table);
                continue;
            }
            uint64_t klass_pm = rpm<uint64_t>(table + (uint64_t)ext_idx_pm * 8);
            char nm[64] = {0};
            if (ox_isPtr(klass_pm)) ox_className(klass_pm, nm, sizeof(nm));
            OXLOGI("[chain-diag] MC+0x%02llx=0x%llx  table[%u]=0x%llx  name='%s'",
                   mc_off, (unsigned long long)table, ext_idx_pm,
                   (unsigned long long)klass_pm, nm);
            if (ox_isPtr(klass_pm)) {
                uint8_t buf[64] = {0};
                if (vm_readv(klass_pm, buf, sizeof(buf))) {
                    char label[64];
                    snprintf(label, sizeof(label), "klass @ MC+0x%llx table[%u]", mc_off, ext_idx_pm);
                    oxlog::hexdump(label, klass_pm, buf, sizeof(buf));
                }
            }
        }
    }

    uint64_t tit = rpm<uint64_t>(mc + OX_MC_TYPEINFOTABLE_OFF);
    if (!ox_isPtr(tit)) {
        OXLOGW("[chain] s_TypeInfoTable ещё не выделен (mc=0x%llx tit=0x%llx)",
               (unsigned long long)mc, (unsigned long long)tit);
        return false;
    }

    g_metadataBase   = meta;
    g_typesTableAddr = meta + off_dec;
    g_typeStride     = stride;
    g_sTypeInfoTable = tit;
    OXLOGI("[chain] cached: meta=0x%llx types_off=0x%x stride=%u tit=0x%llx",
           (unsigned long long)meta, off_dec, stride,
           (unsigned long long)tit);
    return true;
}

static uint64_t ox_klassFromTDI(uint32_t tdi, const char *expectedName) {
    if (!ox_cacheMetadataChain()) return 0;
    uint64_t enc_addr = g_typesTableAddr + (uint64_t)tdi * g_typeStride;
    uint32_t ext_idx = 0;
    switch (g_typeStride) {
        case 1: ext_idx = rpm<uint8_t>(enc_addr);  if (ext_idx == 0xff)    return 0; break;
        case 2: ext_idx = rpm<uint16_t>(enc_addr); if (ext_idx == 0xffff)  return 0; break;
        case 4: ext_idx = rpm<uint32_t>(enc_addr); if (ext_idx == 0xffffffff) return 0; break;
        default: return 0;
    }
    uint64_t klass = rpm<uint64_t>(g_sTypeInfoTable + (uint64_t)ext_idx * 8);
    if (!ox_isPtr(klass)) return 0;
    char cn[96] = {0};
    ox_className(klass, cn, sizeof(cn));
    if (cn[0] == 0 || strcmp(cn, expectedName) != 0) {
        // Диагностика один раз на класс — дамп первых 32 байт klass чтобы
        // понять валиден ли указатель (Class::Init не прогнан VS указатель мусор).
        static std::atomic<uint64_t> s_dumpedFor{0};
        uint64_t marker = ((uint64_t)tdi << 40) | (klass & 0xffffffffffULL);
        if (s_dumpedFor.exchange(marker) != marker) {
            uint8_t buf[32] = {0};
            if (vm_readv(klass, buf, sizeof(buf))) {
                oxlog::hexdump("klass head (Class::Init pending?)", klass, buf, sizeof(buf));
            }
        }
        OXLOGD("[chain] TDI=%u ext=%u klass=0x%llx имя='%s' ожидали '%s'",
               tdi, ext_idx, (unsigned long long)klass, cn, expectedName);
        return 0;
    }
    return klass;
}

// Offline-baked byvalTypeIndex (external index в types[]) для каждого класса.
// Достаётся из decrypted global-metadata.dat: TypeDef record @ (0x1523780 + TDI*82) + 8.
// UPDATE 2026/07/24: пересчитано под NEW metadata. Проверено offline: 60998/46457/61062.
static constexpr int32_t OX_BYVAL_IDX_PLAYERMANAGER = 60998;  // was 60939
static constexpr int32_t OX_BYVAL_IDX_BUILDINGPIECE = 46457;  // was 46390
static constexpr int32_t OX_BYVAL_IDX_PLAYERVITALS  = 61062;  // was 61003

// Метадата диапазон для проверки: находится ли pointer в метадате (Il2CppTypeDefinition*)
// или в куче (Il2CppClass* пост-Class::Init). Метадата ~26 МБ, начинается с magic.
static bool ox_isInMetadata(uint64_t addr, uint64_t metaBase, size_t metaSize = 32ULL << 20) {
    return addr >= metaBase && addr < metaBase + metaSize;
}

// Bulk-search heap region for slot equal to nameVa (klass's name field).
// Klass в куче рядом с MC struct — Il2CppClass structs аллоцируются тем же
// аллокатором. Одна vm_readv-считка большого куска памяти игры, локальный поиск.
// Если найдено → klass = slot - CLASS_NAME (0x10).
static uint64_t ox_findKlassInHeap(uint64_t nameVa, uint64_t regionStart, size_t regionSize) {
    if (regionSize > 32ULL * 1024 * 1024) return 0;  // cap 32 MB per bulk read
    std::vector<uint8_t> buf(regionSize);
    if (!vm_readv(regionStart, buf.data(), regionSize)) return 0;
    for (size_t off = 0; off + 8 <= regionSize; off += 8) {
        uint64_t v;
        memcpy(&v, buf.data() + off, 8);
        if (v == nameVa) {
            uint64_t slot = regionStart + off;
            uint64_t klass = slot - ox::CLASS_NAME;
            // Sanity: klass должен быть в той же куче
            if (klass >= regionStart && klass < regionStart + regionSize) return klass;
        }
    }
    return 0;
}

// РЕЗОЛВ ЧЕРЕЗ s_TypeInfoTable — offline-найденный через ARM64 disasm.
//
// Offline-дизасм libil2cpp.so нашёл `MetadataCache::Initialize` +
// `GetTypeInfoFromTypeDefinitionIndex`. Оттуда — cached lazy accessor:
//   NEW 0x4DFF370: ldr x21, [x8, #0xff0]       ; x21 = *(0xBF80FF0) = s_TypeInfoTable
//   NEW 0x4DFF374: ldr x20, [x21, w0, sxtw #3] ; klass = s_TypeInfoTable[TDI]
//   (OLD было 0x4D77404 ldr x22,[x8,#0xb58] -> 0xBE3BB58; store в Init @0x4DFF63C)
//
// s_TypeInfoTable — Il2CppClass** массив (TYPEDEF_COUNT записей), индексируется по TDI.
// UPDATE 2026/07/24: slot @ RVA 0xBF80FF0 (было 0xBE3BB58) — .bss (writable),
// NULL в файле, malloc'ится MetadataCache::Initialize через Calloc.
//
// Lazy: s_TypeInfoTable[TDI] == NULL пока класс не заресолвен игрой (metadata usage
// init при входе в матч). После первого захода — s_TypeInfoTable[8357] = klass.
// ВАЖНО (фикс 2026/07/25): 0xBF80FF0 — это s_MethodInfoDefinitionTable
// (226854 слотов, индекс = method index), НЕ таблица классов. Обе функции —
// GetMethodInfoFromMethodDefinitionIndex @0x4dff360 и Class::FromTypeDefinition
// @0x4e0030c — имеют одинаковую форму (XOR-ключ + sdiv + cache-write), поэтому
// pattern-скан сел на неправильную.
//
// Доказательство из MetadataCache::Initialize @0x4dff4f8:
//   0x4dff5f8: ldr w8,[header,#0xe8]; eor KEY   -> 29486  (typeDefinitionsCount)
//   0x4dff618: str x0, [0xBF81040]              -> s_TypeInfoDefinitionTable
//   0x4dff61c: ldr w8,[header,#0xd0]; eor KEY   -> 226854 (methodsCount)
//   0x4dff63c: str x0, [0xBF80FF0]              -> s_MethodInfoDefinitionTable
//
// Class::FromTypeDefinition @0x4e0030c читает именно 0xBF81040:
//   0x4e00334: ldr x22, [x8, #0x40]           ; x22 = *(0xBF81040)
//   0x4e00338: ldr x20, [x22, w0, sxtw #3]    ; klass = table[TDI]
//   0x4e00604: str x20, [x22, w19, sxtw #3]   ; cache-write
//
// Старый билд: 0xBE3BB58. Все metadata-глобалы сдвинулись на +0x1454E8,
// 0xBE3BB58 + 0x1454E8 = 0xBF81040. Мнемоника на будущее:
//   s_TypeInfoDefinitionTable = <ctx global> + 0x48  (0xBF80FF8 + 0x48).
// UPDATE 2026/07/25: подтверждено дизасмом Initialize @0x4df3948 —
//   alloc(header[0xe8]^KEY = 29486) -> str x0,[0xBF61440]   классы
//   alloc(header[0xd0]^KEY = 226242) -> str x0,[0xBF613F0]  методы
// Все шесть metadata-глобалов сдвинулись ровно на -0x1FC00.
// Мнемоника снова сходится: ctx(0xBF613F8) + 0x48 = 0xBF61440.
static constexpr uint64_t OX_S_TYPEINFO_TABLE_RVA = 0xBF61440ULL;  // was 0xBF81040
// UPDATE 2026/07/31: TDI обновлены (grep "class X :" в новом dump.cs).
// TYPEDEF_COUNT = typeDefinitionsCount из header (XOR-decrypted @0xE4/82) = 29697.
static constexpr uint32_t OX_TDI_NETWORKCLIENT    = 24057;  // Mirror.NetworkClient (was 23916)
static constexpr uint32_t OX_TDI_PLAYERMANAGER    = 8502;  // was 8357
static constexpr uint32_t OX_TDI_BUILDINGPIECE    = 8790;  // was 8633
static constexpr uint32_t OX_TDI_PLAYERVITALS     = 8163;  // was 8030
static constexpr uint32_t OX_TYPEDEF_COUNT        = 29697; // was 29486

// Fast-seed через s_TypeInfoTable[TDI]. Детерминированный, 3 vm_readv на класс.
static bool ox_fastSeedTypeInfoFromHeader() {
    if (!il2cpp_base) return false;

    // UPDATE 2026/07/31 v19: ROBUST-FIRST для скорости старта.
    // На этой сборке (md5 14666f83...) fast-seed-слоты (OX_S_TYPEINFO_TABLE_RVA /
    // OX_META_BASE_PTR_RVA) СТАЛЫЕ — table[TDI] всегда мимо, а self-heal сканирует
    // 29697 невалидных слотов ~8 сек ВПУСТУЮ перед тем как дойти до robust.
    // Из v17-лога: launch→robust-скан = 8 сек паузы, из них ничего полезного.
    // Поэтому: если PlayerManager/BuildingPiece ещё не резолвлены — сразу robust
    // (он проверенно работает, ~2.5 сек), без стального table/self-heal.
    {
        // PlayerManager — критичный для ESP игроков. Резолвим ПЕРВЫМ и, как только
        // нашли, СРАЗУ возвращаем success — боксы появляются максимально быстро,
        // не дожидаясь BuildingPiece (тот резолвится на следующем тике).
        if (!g_playerManagerKlass) {
            ox_setScanDeadline(15);
            uint64_t k = ox_resolveKlassRobust("PlayerManager", "Oxide");
            ox_clearScanDeadline();
            if (k) g_playerManagerKlass = k;
            if (g_playerManagerKlass) return true;   // боксы — приоритет №1
            // PM ещё не нашёлся — пробуем legacy-путь ниже как fallback.
        } else {
            // PM уже есть — добираем BuildingPiece оппортунистически (для wall/build ESP).
            if (!g_buildingPieceKlass) {
                ox_setScanDeadline(15);
                uint64_t k = ox_resolveKlassRobust("BuildingPiece", "Oxide.Building");
                ox_clearScanDeadline();
                if (k) g_buildingPieceKlass = k;
            }
            return true;
        }
    }

    // ── Ниже — legacy fast-seed через s_TypeInfoTable (fallback, если robust не
    //    нашёл; на новых сборках обычно не доходит сюда). ──
    // Читаем s_TypeInfoTable pointer из libil2cpp writable BSS slot.
    uint64_t table = rpm<uint64_t>(il2cpp_base + OX_S_TYPEINFO_TABLE_RVA);
    if (!ox_isPtr(table)) {
        OXLOGD("[fast-seed] s_TypeInfoTable slot @ RVA 0x%llx = 0x%llx (init ещё не прогнан?)",
               (unsigned long long)OX_S_TYPEINFO_TABLE_RVA, (unsigned long long)table);
        return false;
    }

    // Для name-верификации нужен metadata_base
    uint64_t meta = rpm<uint64_t>(il2cpp_base + OX_META_BASE_PTR_RVA);
    if (!ox_isPtr(meta)) {
        OXLOGD("[fast-seed] metadata_base ещё null");
        return false;
    }

    static bool s_logged = false;
    if (!s_logged) {
        s_logged = true;
        OXLOGI("[fast-seed] s_TypeInfoDefinitionTable=0x%llx meta_base=0x%llx (RVA 0xBF61440, disasm-verified)",
               (unsigned long long)table, (unsigned long long)meta);
    }

    struct Seed {
        uint32_t tdi;
        uint64_t nameOff;
        const char *expected;
        uint64_t *klass_out;
    };
    Seed seeds[] = {
        { OX_TDI_PLAYERMANAGER, OX_META_NAME_OFF_PLAYERMANAGER, "PlayerManager", &g_playerManagerKlass },
        { OX_TDI_BUILDINGPIECE, OX_META_NAME_OFF_BUILDINGPIECE, "BuildingPiece", &g_buildingPieceKlass },
    };

    // ── Верификация klass ────────────────────────────────────────────────────
    // ПРЕДЫДУЩИЙ БАГ: сверяли klass->name с (meta_base + hardcoded_name_off) и
    // требовали ТОЧНОГО совпадения указателей. Лог 06:39 показал что это ложно:
    //   BuildingPiece klass=0x7c01eebd48 name_ptr=0x7c25fa6d44 ожидали 0x7c40583379
    // name_ptr указывает В LIBIL2CPP (base 0x7c21418000 + RVA 0x4b8ed44), а не в
    // загруженный global-metadata (0x7c40477000). То есть строки имён классов в
    // этой сборке живут в .rodata самой либы, а не в metadata-блобе. Хардкод
    // оффсета в metadata бесполезен.
    //
    // НОВАЯ схема: читаем C-строку по указателю и сравниваем СОДЕРЖИМОЕ. Не
    // важно откуда указатель — libil2cpp .rodata, metadata-блоб или куча.
    // ox_asciiEquals уже делает ровно это (читает и memcmp'ит).
    (void)meta;
    int seeded = 0;
    for (const Seed &s : seeds) {
        if (s.tdi >= OX_TYPEDEF_COUNT) continue;
        // klass = s_TypeInfoTable[TDI]
        uint64_t klass = rpm<uint64_t>(table + (uint64_t)s.tdi * 8);
        if (!ox_isPtr(klass)) {
            OXLOGD("[fast-seed] %s: table[%u] = 0x%llx (класс ещё не резолвен игрой)",
                   s.expected, s.tdi, (unsigned long long)klass);
            continue;
        }
        // Верификация по СОДЕРЖИМОМУ строки имени, а не по адресу.
        uint64_t name_ptr = rpm<uint64_t>(klass + ox::CLASS_NAME);
        if (!ox_asciiEquals(name_ptr, s.expected)) {
            char got[96] = {0};
            ox_className(klass, got, sizeof(got));
            OXLOGD("[fast-seed] %s: klass=0x%llx имя='%s' (не совпало)",
                   s.expected, (unsigned long long)klass, got);
            continue;
        }
        *s.klass_out = klass;
        ++seeded;
        OXLOGI("[fast-seed] %s: klass=0x%llx (s_TypeInfoTable[%u], имя сверено)",
               s.expected, (unsigned long long)klass, s.tdi);
    }

    // ── Self-heal: если TDI съехал после апдейта игры ────────────────────────
    // Таблица индексируется по TypeDefinitionIndex. При апдейте игры TDI
    // сдвигаются, и хардкод промахивается (лог: table[8357] = 0x0, хотя таблица
    // валидна). Вместо провала — сканируем таблицу ОДИН раз и находим слот, чей
    // klass->name совпадает с искомым именем. Найденный TDI кэшируем в статике,
    // дальше идём напрямую. Это чтение таблицы указателей внутри libil2cpp
    // (не анон-память игры), watchdog его не видит.
    if (seeded < (int)(sizeof(seeds) / sizeof(seeds[0]))) {
        static uint32_t s_healTdi[2]   = { 0, 0 };
        static bool     s_healTried[2] = { false, false };
        for (int i = 0; i < (int)(sizeof(seeds) / sizeof(seeds[0])); ++i) {
            Seed &s = seeds[i];
            if (*s.klass_out) continue;

            // UPDATE 2026/07/31 v9: ROBUST резолвер КАЖДЫЙ цикл (ДО s_healTried gate).
            // v8-баг был двойной: (1) mmap-retry стоял после s_healTried и не ретраился,
            // (2) ox_findKlassByNameVa пропускал регионы >16MB — а class-heap как раз
            // больше 16MB, поэтому указатель на строку никогда не находился.
            // ox_resolveKlassRobust: находит ВСЕ копии имени, chunked-scan по всем
            // регионам без cap, верифицирует name+namespace. Ретраится каждые 3 сек —
            // ловит класс как только сцена матча его инстанцирует.
            {
                const char *wantNs = (strcmp(s.expected, "BuildingPiece") == 0)
                                      ? "Oxide.Building" : "Oxide";
                ox_setScanDeadline(20);   // не даём скану висеть >20 сек за цикл
                uint64_t klass = ox_resolveKlassRobust(s.expected, wantNs);
                ox_clearScanDeadline();
                if (klass) {
                    *s.klass_out = klass;
                    ++seeded;
                    continue;   // klass найден — дальше по этому seed не идём
                }
            }

            // Уже нашли исправленный TDI в прошлый раз — используем его.
            if (s_healTdi[i]) {
                uint64_t k = rpm<uint64_t>(table + (uint64_t)s_healTdi[i] * 8);
                if (ox_isPtr(k) && ox_asciiEquals(rpm<uint64_t>(k + ox::CLASS_NAME), s.expected)) {
                    *s.klass_out = k; ++seeded;
                }
                continue;
            }
            if (s_healTried[i]) continue;   // скан уже был и не дал результата
            s_healTried[i] = true;
            OXLOGI("[self-heal] %s: TDI %u не подошёл — сканирую s_TypeInfoTable (%u слотов)",
                   s.expected, s.tdi, OX_TYPEDEF_COUNT);
            // Bulk-чтение таблицы кусками по 4096 указателей — быстро и без
            // помегабайтных проходов по памяти игры.
            const uint32_t CHUNK = 4096;
            std::vector<uint64_t> buf(CHUNK);
            bool done = false;
            for (uint32_t base = 0; base < OX_TYPEDEF_COUNT && !done; base += CHUNK) {
                uint32_t n = OX_TYPEDEF_COUNT - base;
                if (n > CHUNK) n = CHUNK;
                if (!vm_readv(table + (uint64_t)base * 8, buf.data(), (size_t)n * 8)) continue;
                for (uint32_t j = 0; j < n; ++j) {
                    uint64_t k = buf[j];
                    if (!ox_isPtr(k)) continue;
                    uint64_t np = rpm<uint64_t>(k + ox::CLASS_NAME);
                    if (!ox_asciiEquals(np, s.expected)) continue;
                    // Уточняем namespace, чтобы не поймать одноимённый класс.
                    char ns[96] = {0};
                    uint64_t nsPtr = rpm<uint64_t>(k + ox::CLASS_NAMESPACE);
                    if (ox_isPtrLoose(nsPtr)) vm_readv(nsPtr, ns, sizeof(ns) - 1);
                    const char *wantNs = (i == 1) ? "Oxide.Building" : "Oxide";
                    if (ns[0] && strcmp(ns, wantNs) != 0) continue;
                    s_healTdi[i] = base + j;
                    *s.klass_out = k;
                    ++seeded;
                    OXLOGI("[self-heal] %s: НАЙДЕН на TDI %u (был %u), klass=0x%llx ns='%s'",
                           s.expected, s_healTdi[i], s.tdi, (unsigned long long)k, ns);
                    done = true;
                    break;
                }
            }
            if (!done)
                OXLOGW("[self-heal] %s: не найден ни в одном слоте таблицы", s.expected);

            // UPDATE 2026/07/31 v7: PRE-FALLBACK — /proc/PID/maps mmap-based meta_base.
            // Берём базу global-metadata.dat напрямую из mmap таблицы игры, а не из stale
            // fast-seed slot. Полностью обходит проблему v5-лога (nameVa указывал на
            // ARM64-инструкции потому что OX_META_BASE_PTR_RVA невалиден в новой сборке).
            if (!*s.klass_out && s.nameOff != 0) {
                uint64_t mmap_base = ox_findMetadataMmapBase();
                if (mmap_base) {
                    uint64_t real_nameVa = mmap_base + s.nameOff;
                    // Верификация: должно быть strncmp("PlayerManager", real_nameVa) == 0
                    if (ox_asciiEquals(real_nameVa, s.expected)) {
                        OXLOGI("[mmap-base] %s: metadata mmap base=0x%llx, nameVa=0x%llx (ok)",
                               s.expected, (unsigned long long)mmap_base,
                               (unsigned long long)real_nameVa);
                        std::vector<OxMapRange> libRwMaps;
                        ox_collectMaps(libRwMaps, ox::MODULE, /*writeOnly=*/true, 256ULL * 1024 * 1024);
                        std::vector<OxMapRange> anonRw;
                        ox_collectMaps(anonRw, /*pathFilter=*/"", /*writeOnly=*/true,
                                       256ULL * 1024 * 1024, /*anonOnly=*/true);
                        std::vector<OxMapRange> scanMaps = libRwMaps;
                        scanMaps.insert(scanMaps.end(), anonRw.begin(), anonRw.end());
                        uint64_t klass = ox_findKlassByNameVa(real_nameVa, scanMaps);
                        if (klass) {
                            char ns[96] = {0};
                            uint64_t nsPtr = rpm<uint64_t>(klass + ox::CLASS_NAMESPACE);
                            if (ox_isPtrLoose(nsPtr)) vm_readv(nsPtr, ns, sizeof(ns) - 1);
                            const char *wantNs = (strcmp(s.expected, "BuildingPiece") == 0)
                                                  ? "Oxide.Building" : "Oxide";
                            if (!ns[0] || strcmp(ns, wantNs) == 0) {
                                *s.klass_out = klass;
                                ++seeded;
                                OXLOGI("[mmap-base] %s: НАЙДЕН, klass=0x%llx ns='%s'",
                                       s.expected, (unsigned long long)klass, ns);
                            } else {
                                OXLOGW("[mmap-base] %s: ns mismatch ('%s' vs '%s'), проверяю дальше",
                                       s.expected, ns, wantNs);
                            }
                        } else {
                            OXLOGW("[mmap-base] %s: строка есть, но pointer на неё не нашёл в RW-регионах",
                                   s.expected);
                        }
                    } else {
                        OXLOGW("[mmap-base] %s: mmap_base=0x%llx но byte@nameVa не равны ожидаемым — оффсет строки съехал?",
                               s.expected, (unsigned long long)mmap_base);
                        if (oxlog::verbose) {
                            uint8_t buf[64];
                            if (vm_readv(real_nameVa, buf, sizeof(buf))) {
                                oxlog::hexdump("candidate nameVa", real_nameVa, buf, sizeof(buf));
                            }
                        }
                    }
                } else {
                    OXLOGW("[mmap-base] %s: global-metadata.dat не найден в /proc/%d/maps игры",
                           s.expected, game_pid);
                }
            }

            // UPDATE 2026/07/31 v6: FINAL FALLBACK — memory string-scan.
            // Если и mmap-base fallback выше не сработал (например если игра сама
            // распаковала metadata в анон-память и mmap там не виден по имени файла).
            if (!*s.klass_out) {
                OXLOGI("[mem-scan] %s: старый path meta+off нерабочий (fast-seed slots stale). "
                       "Ищу '%s\\0' в памяти игры целиком.", s.expected, s.expected);
                // Собираем anon regions + все libil2cpp regions
                std::vector<OxMapRange> anonMaps;
                ox_collectMaps(anonMaps, /*pathFilter=*/"", /*writeOnly=*/false,
                               256ULL * 1024 * 1024, /*anonOnly=*/true);
                std::vector<OxMapRange> libAllMaps;
                ox_collectMaps(libAllMaps, ox::MODULE, /*writeOnly=*/false,
                               256ULL * 1024 * 1024);
                OXLOGI("[mem-scan] %s: anon=%zu regions, libil2cpp=%zu regions",
                       s.expected, anonMaps.size(), libAllMaps.size());
                std::vector<OxMapRange> allMaps = libAllMaps;
                allMaps.insert(allMaps.end(), anonMaps.begin(), anonMaps.end());

                std::vector<uint64_t> nameMatches;
                ox_findAscii(allMaps, s.expected, nameMatches, /*maxMatches=*/16);
                OXLOGI("[mem-scan] %s: найдено %zu вхождений '%s\\0'",
                       s.expected, nameMatches.size(), s.expected);
                for (size_t j = 0; j < std::min<size_t>(nameMatches.size(), 8); ++j) {
                    OXLOGI("[mem-scan] %s:   [%zu] @ 0x%llx",
                           s.expected, j, (unsigned long long)nameMatches[j]);
                }
                if (nameMatches.empty()) {
                    OXLOGE("[mem-scan] %s: строка '%s\\0' НЕ найдена в памяти игры вообще.",
                           s.expected, s.expected);
                    OXLOGE("[mem-scan] %s: значит либо metadata ещё не загружен, либо игра "
                           "хранит имена в другой форме (encrypted/length-prefixed).", s.expected);
                    continue;
                }

                // Для каждого кандидата — ищем pointer на него в libRw+anon
                std::vector<OxMapRange> libRwMaps;
                ox_collectMaps(libRwMaps, ox::MODULE, /*writeOnly=*/true, 256ULL * 1024 * 1024);
                std::vector<OxMapRange> scanMaps = libRwMaps;
                scanMaps.insert(scanMaps.end(), anonMaps.begin(), anonMaps.end());
                OXLOGI("[mem-scan] %s: ищу pointer на nameVa в %zu RW-регионах (libil2cpp+anon)",
                       s.expected, scanMaps.size());

                bool found = false;
                for (uint64_t nameVa : nameMatches) {
                    uint64_t klass = ox_findKlassByNameVa(nameVa, scanMaps);
                    if (klass) {
                        // Верификация namespace
                        char ns[96] = {0};
                        uint64_t nsPtr = rpm<uint64_t>(klass + ox::CLASS_NAMESPACE);
                        if (ox_isPtrLoose(nsPtr)) vm_readv(nsPtr, ns, sizeof(ns) - 1);
                        // s.expected — просто class name; ожидаем namespace = "Oxide" или "Oxide.Building"
                        const char *wantNs = (strcmp(s.expected, "BuildingPiece") == 0) ? "Oxide.Building" : "Oxide";
                        if (ns[0] && strcmp(ns, wantNs) != 0) {
                            OXLOGD("[mem-scan] %s: klass@0x%llx имеет ns='%s', ожидаем '%s' — пропускаю",
                                   s.expected, (unsigned long long)klass, ns, wantNs);
                            continue;
                        }
                        *s.klass_out = klass;
                        ++seeded;
                        OXLOGI("[mem-scan] %s: НАЙДЕН, klass=0x%llx ns='%s' nameVa=0x%llx",
                               s.expected, (unsigned long long)klass, ns,
                               (unsigned long long)nameVa);
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    OXLOGE("[mem-scan] %s: строка найдена но нет pointer на неё в RW-регионах.",
                           s.expected);
                    OXLOGE("[mem-scan] %s: значит klass structures хранятся в другой области либо шифрованы.",
                           s.expected);
                    // Диагностика: hex-дамп у первого найденного nameVa (окружение)
                    if (oxlog::verbose && !nameMatches.empty()) {
                        uint8_t buf[128];
                        if (vm_readv(nameMatches[0], buf, sizeof(buf))) {
                            oxlog::hexdump("mem string @ nameVa", nameMatches[0], buf, sizeof(buf));
                        }
                        // Просканируем окрестности первого nameVa на pointer-обертки
                        // (метаданные game engines иногда хранят name как length+ptr).
                        if (vm_readv(nameMatches[0] - 16, buf, 32)) {
                            oxlog::hexdump("mem 16 bytes BEFORE nameVa", nameMatches[0] - 16, buf, 32);
                        }
                    }
                }
            }
        }
    }

    // Mirror.NetworkClient по TDI из того же s_TypeInfoDefinitionTable.
    // Не входит в обязательный набор: если не поднялся, LOS просто останется
    // без резервного источника, остальное работает.
    if (!g_networkClientKlass) {
        uint64_t table = rpm<uint64_t>(il2cpp_base + OX_S_TYPEINFO_TABLE_RVA);
        if (ox_isPtr(table)) {
            uint64_t k = rpm<uint64_t>(table + (uint64_t)OX_TDI_NETWORKCLIENT * 8);
            if (ox_isPtr(k)) {
                uint64_t np = rpm<uint64_t>(k + ox::CLASS_NAME);
                if (ox_asciiEquals(np, "NetworkClient")) {
                    g_networkClientKlass = k;
                    OXLOGI("[seed] NetworkClient klass=0x%llx (TDI %u)",
                           (unsigned long long)k, OX_TDI_NETWORKCLIENT);
                } else {
                    OXLOGW("[seed] NetworkClient: имя на TDI %u не совпало",
                           OX_TDI_NETWORKCLIENT);
                }
            }
        }
    }

    bool ok = (seeded == (int)(sizeof(seeds) / sizeof(seeds[0])));
    g_typeInfoAutoResolved = ok;
    return ok;
}

static bool ox_autoResolveTypeInfos(bool full) {
    uint64_t playerRVA = 0, buildingRVA = 0, playerKlass = 0, buildingKlass = 0;
    bool playerOk = ox_autoResolveTypeInfo("PlayerManager", "Oxide", playerRVA, playerKlass, full);
    bool buildingOk = ox_autoResolveTypeInfo("BuildingPiece", "Oxide.Building", buildingRVA, buildingKlass, full);
    if (playerOk)   { g_playerManagerKlass = playerKlass;   if (playerRVA)   g_playerManagerTypeInfoRVA = playerRVA; }
    if (buildingOk) { g_buildingPieceKlass = buildingKlass; if (buildingRVA) g_buildingPieceTypeInfoRVA = buildingRVA; }
    g_typeInfoAutoResolved = playerOk && buildingOk;
    if (full) OXLOGI("[AUTO] итог: PlayerManager=%s (klass=0x%llx), BuildingPiece=%s (klass=0x%llx)",
                     playerOk ? "OK" : "FAIL", (unsigned long long)g_playerManagerKlass,
                     buildingOk ? "OK" : "FAIL", (unsigned long long)g_buildingPieceKlass);
    return playerOk;
}

// Runtime metadata extractor -------------------------------------------------
// Il2CppGlobalMetadataHeader всегда начинается с 0xFAB11BAF уже ПОСЛЕ
// расшифровки. Ищем этот заголовок в native writable mappings, валидируем
// version и таблицы offset/size, затем копируем весь blob в Download.
static constexpr uint32_t IL2CPP_METADATA_MAGIC = 0xFAB11BAFU;
[[maybe_unused]] static std::string g_metadataDumpStatus = "No metadata dump yet";

static void ox_collectMetadataMaps(std::vector<OxMapRange> &out, size_t maxBytes) {
    out.clear();
    char procPath[64]; snprintf(procPath, sizeof(procPath), "/proc/%d/maps", game_pid);
    FILE *maps = fopen(procPath, "rt");
    if (!maps) return;
    size_t total = 0;
    char line[1024];
    while (fgets(line, sizeof(line), maps)) {
        // Decrypted IL2CPP metadata normally lives in malloc/anonymous native
        // memory. Dalvik heaps, per-thread stacks and device mappings are huge
        // and cannot contain it, so skip them before reading process memory.
        if (strstr(line, "dalvik") || strstr(line, "stack_and_tls") ||
            strstr(line, "/dev/") || strstr(line, "jit-"))
            continue;
        OxMapRange map{};
        unsigned long long start = 0, end = 0;
        char path[512] = {};
        int parsed = sscanf(line, "%llx-%llx %4s %*llx %*s %*s %511[^\n]",
                            &start, &end, map.perms, path);
        if (parsed < 3 || end <= start || map.perms[0] != 'r') continue;
        // Some loaders decrypt metadata and immediately mprotect it read-only.
        // Include writable native allocations as before plus anonymous read-only
        // memory and libil2cpp's own read-only mappings; skip unrelated system
        // libraries with file-backed r-- pages.
        bool isWritable = map.perms[1] == 'w';
        bool isIl2Cpp = strstr(path, "libil2cpp.so") != nullptr;
        bool isAnonymous = path[0] == 0 || strstr(path, "[anon:") != nullptr ||
                           strstr(path, "[heap]") != nullptr;
        if (!isWritable && !isIl2Cpp && !isAnonymous) continue;
        size_t size = (size_t)(end - start);
        if (size > maxBytes || total > maxBytes - size) continue;
        map.start = start;
        map.end = end;
        snprintf(map.path, sizeof(map.path), "%s", path);
        out.push_back(map);
        total += size;
    }
    fclose(maps);
}

static bool ox_validateMetadataHeader(uint64_t address, uint64_t mappingEnd,
                                      size_t &dumpSize, uint32_t &version) {
    // The header is a sequence of offset/size fields. Read enough for every
    // current Unity metadata version, but accept only table ends inside the map.
    uint32_t words[128] = {};
    if (!vm_readv(address, words, sizeof(words))) return false;
    if (words[0] != IL2CPP_METADATA_MAGIC) return false;
    version = words[1];
    if (version < 20 || version > 40) return false;

    uint64_t available = mappingEnd - address;
    uint64_t maxEnd = 0;
    int validTables = 0;
    for (size_t i = 2; i + 1 < IM_ARRAYSIZE(words); i += 2) {
        uint64_t offset = words[i];
        uint64_t size = words[i + 1];
        if (offset < 8 || size == 0) continue;
        if (offset >= available || size > available - offset) continue;
        uint64_t tableEnd = offset + size;
        if (tableEnd > maxEnd) maxEnd = tableEnd;
        ++validTables;
    }
    // A real header has many tables and is larger than a minimal header.
    if (validTables < 8 || maxEnd < 0x1000 || maxEnd > 512ULL * 1024 * 1024) return false;
    dumpSize = (size_t)maxEnd;
    return true;
}

static bool ox_copyRemoteFile(uint64_t remote, size_t size, const char *path) {
    FILE *out = fopen(path, "wb");
    if (!out) return false;
    const size_t chunkSize = 1024 * 1024;
    std::vector<uint8_t> buffer(chunkSize);
    bool ok = true;
    for (size_t offset = 0; offset < size;) {
        size_t count = std::min(chunkSize, size - offset);
        if (!vm_readv(remote + offset, buffer.data(), count) ||
            fwrite(buffer.data(), 1, count, out) != count) {
            ok = false;
            break;
        }
        offset += count;
    }
    fclose(out);
    if (!ok) remove(path);
    return ok;
}

[[maybe_unused]] static void ox_dumpDecryptedMetadata() {
    oxlog::section("DECRYPTED METADATA DUMP");
    if (game_pid <= 0) {
        g_metadataDumpStatus = "Dump failed: game process unavailable";
        OXLOGE("[META] %s", g_metadataDumpStatus.c_str());
        return;
    }

    std::vector<OxMapRange> maps;
    ox_collectMetadataMaps(maps, 1024ULL * 1024 * 1024);
    OXLOGI("[META] scanning %zu native readable/anonymous mappings", maps.size());

    const size_t chunkSize = 1024 * 1024;
    std::vector<uint8_t> buffer(chunkSize + 4);
    uint64_t metadataAddress = 0;
    uint64_t metadataEnd = 0;
    size_t metadataSize = 0;
    uint32_t metadataVersion = 0;

    for (const OxMapRange &map : maps) {
        size_t carry = 0;
        for (uint64_t at = map.start; at < map.end && !metadataAddress;) {
            size_t want = (size_t)std::min<uint64_t>(chunkSize, map.end - at);
            if (!vm_readv(at, buffer.data() + carry, want)) { carry = 0; at += want; continue; }
            size_t total = carry + want;
            for (size_t i = 0; i + sizeof(uint32_t) <= total; i += sizeof(uint32_t)) {
                uint32_t magic = 0;
                memcpy(&magic, buffer.data() + i, sizeof(magic));
                if (magic != IL2CPP_METADATA_MAGIC) continue;
                uint64_t candidate = at - carry + i;
                if (ox_validateMetadataHeader(candidate, map.end, metadataSize, metadataVersion)) {
                    metadataAddress = candidate;
                    metadataEnd = map.end;
                    break;
                }
            }
            carry = std::min(sizeof(uint32_t) - 1, total);
            memmove(buffer.data(), buffer.data() + total - carry, carry);
            at += want;
        }
        if (metadataAddress) break;
    }

    if (!metadataAddress) {
        g_metadataDumpStatus = "Metadata header not found in native writable memory";
        OXLOGE("[META] %s", g_metadataDumpStatus.c_str());
        return;
    }

    char outputPath[256];
    time_t now = time(nullptr);
    struct tm tmv{};
    localtime_r(&now, &tmv);
    const char *dir = oxlog::activeDir();
    if (!dir || !dir[0]) dir = "/sdcard/Download/EclipsOxide";
    snprintf(outputPath, sizeof(outputPath),
             "%s/global-metadata_%04d%02d%02d_%02d%02d%02d.dat",
             dir,
             tmv.tm_year + 1900, tmv.tm_mon + 1, tmv.tm_mday,
             tmv.tm_hour, tmv.tm_min, tmv.tm_sec);

    OXLOGI("[META] header=0x%llx mappingEnd=0x%llx version=%u size=%zu",
           (unsigned long long)metadataAddress, (unsigned long long)metadataEnd,
           metadataVersion, metadataSize);
    if (!ox_copyRemoteFile(metadataAddress, metadataSize, outputPath)) {
        g_metadataDumpStatus = "Metadata copy failed: check root/storage permission";
        OXLOGE("[META] %s", g_metadataDumpStatus.c_str());
        return;
    }

    g_metadataDumpStatus = "Metadata saved: " + std::string(outputPath);
    OXLOGI("[META] COMPLETE: %s", g_metadataDumpStatus.c_str());
}

// Имя класса объекта: obj+0x0 -> klass -> name.
static void ox_objClassName(uint64_t obj, char *out, int outlen) {
    out[0] = 0;
    if (!ox_isPtr(obj)) return;
    ox_className(rpm<uint64_t>(obj), out, outlen);
}

// Найденный список игроков.
struct PlayerListView {
    uint64_t elems;   // адрес первого элемента (items + ARRAY_DATA)
    int      count;   // число элементов
    uint64_t container; // сам объект-контейнер (для лога)
    uint64_t statOff; // оффсет в static_fields
    bool     ok;
};

// Резолвит static_fields класса PlayerManager. Возвращает 0 при ошибке.
static uint64_t ox_getStatics(bool full) {
    if (!il2cpp_base) { if (full) OXLOGE("il2cpp_base == 0"); return 0; }

    // Приоритет: кэшированный указатель Il2CppClass (external-safe, без TypeInfo RVA).
    // Если его нет либо он протух (имя != PlayerManager) — сканируем память по имени.
    if (ox_isPtr(g_playerManagerKlass)) {
        char vn[96]; ox_className(g_playerManagerKlass, vn, sizeof(vn));
        if (strcmp(vn, "PlayerManager") != 0) {
            if (full) OXLOGW("Кэш klass протух ('%s') — пере-резолв", vn);
            g_playerManagerKlass = 0;
        }
    }
    if (!ox_isPtr(g_playerManagerKlass)) {
        // Fast-seed через TYPEIDX — троттлим 2.5с, иначе спамит on-demand
        // путь на каждом кадре пока Class::Init игры не прогнан.
#if OX_TRUST_HEADER_TYPEINFO
        static double s_lastSeed = -1000.0;
        double nowS = ImGui::GetTime();
        if (nowS - s_lastSeed >= 2.5) {
            s_lastSeed = nowS;
            if (ox_fastSeedTypeInfoFromHeader()) {
                if (full) OXLOGI("[AUTO] re-seed через TYPEIDX — klass восстановлен без скана");
            }
        }
#endif
    }
    // Scan-based auto-resolve ОТКЛЮЧЁН: убивает игру через watchdog CatsBit'а.
    // Startup thread единолично отвечает за fast-seed через MetadataCache-цепочку.
    // Если klass не заполнен здесь — статистики просто не будут читаться этот кадр.
    if (ox_isPtr(g_playerManagerKlass)) {
        uint64_t st = rpm<uint64_t>(g_playerManagerKlass + ox::CLASS_STATIC_FIELDS);
        if (full) oxlog::ptrstep("klass(cached) + STATIC_FIELDS(0xB8)",
                                 g_playerManagerKlass + ox::CLASS_STATIC_FIELDS, st);
        if (ox_isPtr(st)) return st;
        if (full) OXLOGW("static_fields по кэш-klass невалиден — откат на RVA");
    }

    // Откат: TypeInfo RVA из хедера (на metadata v39 может не совпасть).
    uint64_t typeInfoAddr = il2cpp_base + g_playerManagerTypeInfoRVA;
    uint64_t klass = rpm<uint64_t>(typeInfoAddr);
    if (full) {
        oxlog::section("RESOLVE static_fields");
        OXLOGI("base + PlayerManager_TypeInfo(0x%llx): [0x%llx] -> 0x%llx%s",
               (unsigned long long)g_playerManagerTypeInfoRVA,
               (unsigned long long)typeInfoAddr,
               (unsigned long long)klass,
               g_typeInfoAutoResolved ? " (auto)" : " (fallback)");
        char cn[96]; ox_className(klass, cn, sizeof(cn));
        OXLOGI("Им�� класса TypeInfo = '%s'  (ожидаем PlayerManager)", cn);
    }
    if (!ox_isPtr(klass)) { if (full) OXLOGE("klass невалиден — неверный RVA/база"); return 0; }

    uint64_t statics = rpm<uint64_t>(klass + ox::CLASS_STATIC_FIELDS);
    if (full) oxlog::ptrstep("klass + STATIC_FIELDS(0xB8)", klass + ox::CLASS_STATIC_FIELDS, statics);
    if (!ox_isPtr(statics)) { if (full) OXLOGE("static_fields невалиден"); return 0; }
    return statics;
}

// Оценивает объект-контейнер как список: возвращает count и elems, 0 если не список.
static bool ox_evalContainer(uint64_t c, uint64_t &elems, int &count,
                             char *clsOut, int clsLen, int &homo, int &checked) {
    elems = 0; count = 0; homo = 0; checked = 0; if (clsOut) clsOut[0] = 0;
    if (!ox_isPtr(c)) return false;
    uint64_t items = rpm<uint64_t>(c + ox::LIST_ITEMS);
    if (!ox_isPtr(items)) return false;

    int listSize   = rpm<int>(c + ox::LIST_SIZE);            // List._size (int)
    uint64_t arrLen = rpm<uint64_t>(items + ox::ARRAY_COUNT); // Il2CppArray.max_length

    if (listSize > 0 && listSize <= ox::LIST_COUNT_MAX) count = listSize;
    else if (arrLen > 0 && arrLen <= (uint64_t)ox::LIST_COUNT_MAX) count = (int)arrLen;
    else return false;

    elems = items + ox::ARRAY_DATA;
    uint64_t e0 = rpm<uint64_t>(elems);
    if (!ox_isPtr(e0)) return false;

    uint64_t k0 = rpm<uint64_t>(e0);
    for (int i = 0; i < count && i < 8; i++) {
        uint64_t e = rpm<uint64_t>(elems + i * 8);
        if (!ox_isPtr(e)) continue;
        checked++;
        if (rpm<uint64_t>(e) == k0) homo++;
    }
    if (clsOut) ox_objClassName(e0, clsOut, clsLen);
    return true;
}

// Сканирует static_fields и ищет список игроков (однородный массив объектов,
// имя класса содержит "Player"). full=true → логирует каждый кандидат.
static PlayerListView ox_scanForPlayerList(uint64_t statics, bool full) {
    PlayerListView best; best.ok = false; best.elems = 0; best.count = 0;
    best.container = 0; best.statOff = 0;
    PlayerListView fallback = best; // любой однородный список, если "Player" не найден

    if (full) oxlog::section("SCAN static_fields -> player list");

    for (uint64_t off = 0; off <= ox::STATIC_SCAN_MAX; off += 8) {
        uint64_t c = rpm<uint64_t>(statics + off);
        if (!ox_isPtr(c)) continue;

        uint64_t elems; int count, homo, checked; char cls[96];
        if (!ox_evalContainer(c, elems, count, cls, sizeof(cls), homo, checked)) continue;
        if (homo < 2) continue; // не однородный массив объектов

        bool nameMatch = (cls[0] && strstr(cls, "Player") != nullptr);
        if (full)
            OXLOGT("stat+0x%03llx: c=0x%llx count=%d homo=%d/%d cls='%s'%s",
                   (unsigned long long)off, (unsigned long long)c, count, homo, checked,
                   cls, nameMatch ? "  <-- PLAYER?" : "");

        if (nameMatch && !best.ok) {
            best.ok = true; best.elems = elems; best.count = count;
            best.container = c; best.statOff = off;
        }
        if (!fallback.ok) {
            fallback.ok = true; fallback.elems = elems; fallback.count = count;
            fallback.container = c; fallback.statOff = off;
        }
    }

    PlayerListView res = best.ok ? best : fallback;
    if (full) {
        if (res.ok)
            OXLOGI(">>> Список игроков: static+0x%llx container=0x%llx count=%d elems=0x%llx (%s)",
                   (unsigned long long)res.statOff, (unsigned long long)res.container,
                   res.count, (unsigned long long)res.elems,
                   best.ok ? "по имени класса" : "fallback: однородный список");
        else
            OXLOGW("Список игроков не найден. Ты точно В МАТЧЕ (не в меню)? Список может быть пуст.");
    }
    return res;
}

// Дампит объект-игрока целиком и ищет плавающие HP-кандидаты и позицию.
static void ox_dumpPlayer(int idx, uint64_t player) {
    char cls[96]; ox_objClassName(player, cls, sizeof(cls));
    OXLOGI("=== ИГРОК[%d] = 0x%llx  class='%s' ===", idx, (unsigned long long)player, cls);

    uint8_t buf[0x220];
    if (!vm_readv(player, buf, sizeof(buf))) { OXLOGW("  чтение объекта не удалось"); return; }
    oxlog::hexdump("player +0x00", player, buf, sizeof(buf));

    // Скан float-полей самого игрока: HP (1..200) и триплеты позиции.
    for (uint64_t o = 0x10; o + 4 <= sizeof(buf); o += 4) {
        float f; memcpy(&f, buf + o, 4);
        if (f >= 1.0f && f <= 200.0f && f == (float)(int)f)
            OXLOGT("  [HP?] player+0x%llx = %.1f", (unsigned long long)o, f);
    }
    for (uint64_t o = 0x10; o + 12 <= sizeof(buf); o += 4) {
        float x, y, z;
        memcpy(&x, buf + o, 4); memcpy(&y, buf + o + 4, 4); memcpy(&z, buf + o + 8, 4);
        bool ok = fabsf(x) > 0.01f && fabsf(x) < 100000.f &&
                  fabsf(y) > 0.01f && fabsf(y) < 100000.f &&
                  fabsf(z) > 0.01f && fabsf(z) < 100000.f;
        if (ok)
            OXLOGT("  [POS?] player+0x%llx = (%.2f, %.2f, %.2f)", (unsigned long long)o, x, y, z);
    }

    // Под-объекты игрока (NetworkIdentity, MouseLook, PlayerMap, vitals, transform...)
    // — HP и п���зиция обычно ЗДЕСЬ, а не в теле игрока. Рекурсивн�� сканируем каждый.
    for (uint64_t o = 0x8; o + 8 <= 0x120; o += 8) {
        uint64_t p; memcpy(&p, buf + o, 8);
        if (!ox_isPtr(p)) continue;
        char sub[96]; ox_objClassName(p, sub, sizeof(sub));
        OXLOGT("  [PTR] player+0x%llx -> 0x%llx class='%s'",
               (unsigned long long)o, (unsigned long long)p, sub);

        uint8_t sb[0x140];
        if (!vm_readv(p, sb, sizeof(sb))) continue;
        // HP-кандидаты в под-объекте.
        for (uint64_t so = 0x8; so + 4 <= sizeof(sb); so += 4) {
            float f; memcpy(&f, sb + so, 4);
            if (f >= 1.0f && f <= 200.0f && f == (float)(int)f)
                OXLOGT("      [HP?] %s+0x%llx = %.1f", sub[0]?sub:"?",
                       (unsigned long long)so, f);
        }
        // Триплеты позиции в под-объекте.
        for (uint64_t so = 0x8; so + 12 <= sizeof(sb); so += 4) {
            float x, y, z;
            memcpy(&x, sb + so, 4); memcpy(&y, sb + so + 4, 4); memcpy(&z, sb + so + 8, 4);
            bool ok = fabsf(x) > 0.5f && fabsf(x) < 100000.f &&
                      fabsf(y) > 0.5f && fabsf(y) < 100000.f &&
                      fabsf(z) > 0.5f && fabsf(z) < 100000.f;
            if (ok)
                OXLOGT("      [POS?] %s+0x%llx = (%.2f, %.2f, %.2f)", sub[0]?sub:"?",
                       (unsigned long long)so, x, y, z);
        }
    }
}

// HP ����грока: player+0xC8 -> PlayerVitals; vitals+0x88 -> float health.
static float ox_readHP(uint64_t player, bool full) {
    uint64_t vitals = rpm<uint64_t>(player + ox::PM_VITALS);
    if (full) oxlog::ptrstep("player + VITALS(0xC8)", player + ox::PM_VITALS, vitals);
    if (!ox_isPtr(vitals)) return -1.f;
    float hp = rpm<float>(vitals + ox::VITALS_HEALTH);
    if (full) OXLOGT("  vitals + 0x88 -> HP = %.3f", hp);
    return hp;
}

static std::string ox_readManagedString(uint64_t stringObject) {
    if (!ox_isPtr(stringObject)) return "";
    String value = rpm<String>(stringObject);
    if (value.length <= 0 || value.length > 128) return "";
    return value.Get();
}

// FIX bug #2: читает managed string как СЫРЫЕ UTF-16 байты (hex-строкой).
// String::Get() выкидывает всё >= 0x80 -> кириллические/эмодзи имена команд
// схлопывались в "" ИЛИ в неразличимые огрызки, из-за чего сравнение
// сокомандников молча ломалось. Здесь сравниваем по полному содержимому.
// Возвращает "" если строка пустая/невалидная.
static std::string ox_readStringKey(uint64_t stringObject) {
    if (!ox_isPtr(stringObject)) return "";
    int len = rpm<int>(stringObject + 0x10); // _stringLength
    if (len <= 0 || len > 128) return "";
    // читаем len*2 байт UTF-16 начиная с _firstChar (0x14)
    std::vector<uint8_t> raw((size_t)len * 2);
    if (!vm_readv(stringObject + 0x14, raw.data(), raw.size())) return "";
    static const char* HEX = "0123456789abcdef";
    std::string out; out.reserve(raw.size() * 2);
    for (uint8_t b : raw) { out.push_back(HEX[b >> 4]); out.push_back(HEX[b & 0xf]); }
    return out;
}

// FIX bug #2: строит СТАБИЛЬНЫЙ ключ команды игрока для сравнения сокомандников.
// Приоритет источников:
//   1) teamName (SyncVar @0x280) — реплицируется на всех клиентов для всех игроков.
//   2) team(WNn @0x120) -> pf(@0x90) -> mYs(teamId string @0x10) — corroborating.
// Возвращает "" если игрок ВНЕ команды (тогда его нельзя считать сокомандником).
static std::string ox_teamKey(uint64_t player) {
    if (!ox_isPtr(player)) return "";
    // 1) teamName (raw UTF-16). Ключ с префиксом источника, чтобы не путать.
    std::string tn = ox_readStringKey(rpm<uint64_t>(player + ox::PM_TEAM_NAME));
    if (!tn.empty()) return "N:" + tn;
    // 2) team -> pf -> mYs (teamId).
    // ВАЖНО: pf-объект РАЗДЕЛЯЕТСЯ между всеми членами команды (WNn per-player,
    // pf shared). Каждая PM имеет свою WNn, но их WNn.team_data указывают на
    // ОДИН И ТОТ ЖЕ pf. Поэтому pf-pointer — стабильный team-identity.
    uint64_t wnn = rpm<uint64_t>(player + ox::PM_TEAM);
    if (ox_isPtr(wnn)) {
        uint64_t pf = rpm<uint64_t>(wnn + ox::WNN_TEAM_DATA);
        if (ox_isPtr(pf)) {
            std::string id = ox_readStringKey(rpm<uint64_t>(pf + ox::PF_TEAM_ID_STR));
            if (!id.empty()) return "I:" + id;
            // 3) Fallback: сам pf-указатель как team-id. Все тимейты имеют
            // одинаковый pf pointer, разные — разные pf (или null для соло).
            char buf[32];
            snprintf(buf, sizeof(buf), "P:%llx", (unsigned long long)pf);
            return std::string(buf);
        }
    }
    return "";
}

// ── Прямая проверка сокомандника по составу команды ────────────────────────
// Строковые team-поля в этом билде часто пусты у обоих игроков, из-за чего
// сравнение ключей молча ничего не скрывало. Здесь идём по РЕАЛЬНОМУ составу:
//   local.PM + PM_TEAM(0x120) -> WNn
//   WNn + 0x90                -> pf (общий объект команды)
//   pf  + 0x20                -> List<TeamMember>
//   TeamMember + 0x10         -> string id  == PM.userID цели (0x278)
// Возвращает true если target числится в команде локального игрока.
// Обходит Dictionary<string,V> и отдаёт КЛЮЧИ (managed-строки) в колбэк.
// Нужен для nWc.TeammateStates, где ключ — userID сокомандника.
template <typename CB>
static int ox_forEachDictStringKeys(uint64_t dictObj, CB&& cb) {
    if (!ox_isPtr(dictObj)) return -1;
    uint64_t entries = rpm<uint64_t>(dictObj + ox::DICT_ENTRIES);
    if (!ox_isPtr(entries)) return -1;
    int count = rpm<int>(dictObj + ox::DICT_COUNT);
    if (count <= 0 || count > 64) return -1;          // команда не бывает большой
    uint64_t arrLen = rpm<uint64_t>(entries + ox::ARRAY_COUNT);
    if (arrLen == 0 || arrLen > 256) return -1;
    if ((uint64_t)count > arrLen) count = (int)arrLen;

    uint64_t dataBase = entries + ox::ARRAY_DATA;
    size_t bytes = (size_t)count * (size_t)ox::DICT_SENTRY_STRIDE;
    std::vector<uint8_t> buf(bytes);
    if (!vm_readv(dataBase, buf.data(), bytes)) return -1;

    int seen = 0;
    for (int i = 0; i < count; ++i) {
        const uint8_t* e = buf.data() + (size_t)i * ox::DICT_SENTRY_STRIDE;
        int32_t hashCode; memcpy(&hashCode, e + ox::DICT_SENTRY_HASHCODE, 4);
        if (hashCode < 0) continue;
        uint64_t keyPtr; memcpy(&keyPtr, e + ox::DICT_SENTRY_KEY, 8);
        if (!ox_isPtr(keyPtr)) continue;
        cb(keyPtr);
        ++seen;
    }
    return seen;
}

// Разовая диагностика цепочки команды (раз в 3 сек), чтобы видеть где рвётся:
// PM.team(0x120) -> nWc.team(0x90) -> Cc.dCI(0x20) -> List<TeamMember>.
[[maybe_unused]] static void ox_logTeamChain(uint64_t localPm, uint64_t targetPm) {
    static double s_last = 0.0;
    double now = (double)ImGui::GetTime();
    if (now - s_last < 3.0) return;
    s_last = now;

    uint64_t lw  = rpm<uint64_t>(localPm  + ox::PM_TEAM);
    uint64_t tw  = rpm<uint64_t>(targetPm + ox::PM_TEAM);
    uint64_t lpf = ox_isPtr(lw) ? rpm<uint64_t>(lw + ox::WNN_TEAM_DATA) : 0;
    uint64_t tpf = ox_isPtr(tw) ? rpm<uint64_t>(tw + ox::WNN_TEAM_DATA) : 0;
    int size = -1;
    if (ox_isPtr(lpf)) {
        uint64_t list = rpm<uint64_t>(lpf + ox::PF_TEAM_MEMBERS);
        if (ox_isPtr(list)) size = rpm<int>(list + ox::LIST_SIZE);
    }
    std::string tid = ox_readStringKey(rpm<uint64_t>(targetPm + ox::PM_USER_ID));
    // Состояние словаря сокомандников — теперь основной источник.
    uint64_t states = ox_isPtr(lw) ? rpm<uint64_t>(lw + ox::NWC_TEAMMATE_STATES) : 0;
    int stCount = ox_isPtr(states) ? rpm<int>(states + ox::DICT_COUNT) : -1;
    int online  = ox_isPtr(lw) ? rpm<int>(lw + ox::NWC_ONLINE) : -1;

    OXLOGI("[team] lw=0x%llx lpf=0x%llx roster=%d | states=0x%llx cnt=%d online=%d | tid='%s'",
           (unsigned long long)lw, (unsigned long long)lpf, size,
           (unsigned long long)states, stCount, online, tid.c_str());

    // Печатаем сами ключи словаря — по ним видно, совпадает ли формат с
    // PM.userID цели (оба должны быть одинаковыми hex-строками).
    if (ox_isPtr(states) && stCount > 0) {
        int shown = 0;
        ox_forEachDictStringKeys(states, [&](uint64_t k) {
            if (shown >= 3) return;
            std::string ks = ox_readStringKey(k);
            OXLOGI("[team]   mate[%d]='%s'", shown, ks.c_str());
            shown++;
        });
    }
}

static bool ox_isTeammate(uint64_t localPm, uint64_t targetPm) {
    if (!ox_isPtr(localPm) || !ox_isPtr(targetPm) || localPm == targetPm) return false;
#ifdef OX_ENABLE_LOG
    if (espHideTeammates || aimIgnoreTeammates) ox_logTeamChain(localPm, targetPm);
#endif

    // ── ПУТЬ 0 (v21, самый надёжный): teamName SyncVar (PM+0x280). ───────────
    // Реплицируется Mirror'ом на ВСЕ клиенты для КАЖДОГО игрока (доказано
    // наличием _Mirror_SyncVarHookDelegate_teamName). Непустая строка, равная
    // нашей — это сокомандник. Не зависит от серверных team-компонентов, которые
    // в этом билде пусты на неведущем клиенте.
    {
        std::string myTeam = ox_readStringKey(rpm<uint64_t>(localPm  + ox::PM_TEAM_NAME));
        std::string tgTeam = ox_readStringKey(rpm<uint64_t>(targetPm + ox::PM_TEAM_NAME));
        if (!myTeam.empty() && !tgTeam.empty() && myTeam == tgTeam) return true;
    }

    // ── ПУТЬ 0b (v21): готовый флаг игры nicklabel.isTeammate (PM+0x130 → +0x91).
    // Игра сама вычисляет «свой» для nick-label; читаем её вердикт напрямую.
    {
        uint64_t wd = rpm<uint64_t>(targetPm + ox::PM_NICKLABEL);
        if (ox_isPtr(wd)) {
            uint8_t isMate = rpm<uint8_t>(wd + ox::NICKLABEL_IS_TEAMMATE);
            if (isMate == 1) return true;
        }
    }

    // ── ГЛАВНЫЙ ПУТЬ (legacy): nWc.TeammateStates ──────────────────────────
    // В этом билде nWc.team(0x90) приходит нулём даже когда игрок в команде,
    // поэтому старая цепочка через pf молча ничего не скрывала. А словарь
    // состояний заполнен, и его ключи — это userID сокомандников.
    {
        uint64_t lw = rpm<uint64_t>(localPm + ox::PM_TEAM);
        if (ox_isPtr(lw)) {
            uint64_t states = rpm<uint64_t>(lw + ox::NWC_TEAMMATE_STATES);
            if (ox_isPtr(states)) {
                std::string tid = ox_readStringKey(rpm<uint64_t>(targetPm + ox::PM_USER_ID));
                if (!tid.empty()) {
                    bool found = false;
                    ox_forEachDictStringKeys(states, [&](uint64_t keyStr) {
                        if (found) return;
                        std::string k = ox_readStringKey(keyStr);
                        if (!k.empty() && k == tid) found = true;
                    });
                    if (found) return true;
                }
            }
        }
    }

    // Быстрый путь: одинаковый pf-объект = одна команда.
    uint64_t lw = rpm<uint64_t>(localPm  + ox::PM_TEAM);
    uint64_t tw = rpm<uint64_t>(targetPm + ox::PM_TEAM);
    uint64_t lpf = ox_isPtr(lw) ? rpm<uint64_t>(lw + ox::WNN_TEAM_DATA) : 0;
    uint64_t tpf = ox_isPtr(tw) ? rpm<uint64_t>(tw + ox::WNN_TEAM_DATA) : 0;
    if (ox_isPtr(lpf) && lpf == tpf) return true;

    // Резерв: у nWc есть ВТОРОЙ путь к данным команды — поле team(0x90) типа Cc
    // (тот же объект, что pf). Если WNN_TEAM_DATA указывает не туда после
    // обновления, сверяем по нему; совпадение указателей = одна команда.
    if (!ox_isPtr(lpf) || lpf != tpf) {
        uint64_t lcc = ox_isPtr(lw) ? rpm<uint64_t>(lw + ox::NWC_TEAM_DATA) : 0;
        uint64_t tcc = ox_isPtr(tw) ? rpm<uint64_t>(tw + ox::NWC_TEAM_DATA) : 0;
        if (ox_isPtr(lcc) && lcc == tcc) return true;
        // И берём его как источник ростера, если основной пуст.
        if (!ox_isPtr(lpf) && ox_isPtr(lcc)) lpf = lcc;
    }

    // ── ТРЕТИЙ ПУТЬ: UI-панель команды ─────────────────────────────────────
    // RaycastManager.teamManager(0x28) -> CW.membersList(0x90) -> List<nWR>,
    // где nWR.identificator(0x38) — UI.Text с userID участника. Этот список
    // живёт в UI-слое и заполнен, даже когда и nWc.team, и TeammateStates
    // пустые: панель команды рисуется из собственных данных.
    {
        uint64_t rm = rpm<uint64_t>(localPm + ox::PM_RAYCASTMANAGER);
        uint64_t cw = ox_isPtr(rm) ? rpm<uint64_t>(rm + ox::RM_TEAM_MANAGER) : 0;
        if (ox_isPtr(cw)) {
            uint64_t list = rpm<uint64_t>(cw + ox::CW_MEMBERS_LIST);
            if (ox_isPtr(list)) {
                uint64_t items = rpm<uint64_t>(list + ox::LIST_ITEMS);
                int      size  = rpm<int>(list + ox::LIST_SIZE);
                if (ox_isPtr(items) && size > 0 && size <= 16) {
                    std::string tid = ox_readStringKey(rpm<uint64_t>(targetPm + ox::PM_USER_ID));
                    if (!tid.empty()) {
                        uint64_t elems = items + ox::ARRAY_DATA;
                        for (int i = 0; i < size; ++i) {
                            uint64_t row = rpm<uint64_t>(elems + i * 8);
                            if (!ox_isPtr(row)) continue;
                            uint64_t txt = rpm<uint64_t>(row + ox::NWR_IDENTIFICATOR);
                            if (!ox_isPtr(txt)) continue;
                            std::string id = ox_readStringKey(rpm<uint64_t>(txt + ox::UITEXT_M_TEXT));
                            if (!id.empty() && id == tid) return true;
                        }
                    }
                }
            }
        }
    }

    if (!ox_isPtr(lpf)) return false;   // мы не в команде — скрывать некого

    // Медленный, но железный путь: сверяем userID по списку участников.
    // Берём ID ЦЕЛИ и ищем его в НАШЕМ ростере — так проверка не зависит от
    // того, заполнены ли строковые поля у нас самих.
    std::string targetId = ox_readStringKey(rpm<uint64_t>(targetPm + ox::PM_USER_ID));
    if (targetId.empty()) return false;

    uint64_t list = rpm<uint64_t>(lpf + ox::PF_TEAM_MEMBERS);
    if (!ox_isPtr(list)) return false;
    uint64_t items = rpm<uint64_t>(list + ox::LIST_ITEMS);
    int      size  = rpm<int>(list + ox::LIST_SIZE);
    if (!ox_isPtr(items) || size <= 0 || size > 32) return false;

    uint64_t elems = items + ox::ARRAY_DATA;
    for (int i = 0; i < size; ++i) {
        uint64_t tm = rpm<uint64_t>(elems + i * 8);
        if (!ox_isPtr(tm)) continue;
        std::string id = ox_readStringKey(rpm<uint64_t>(tm + ox::TEAMMEMBER_ID));
        if (!id.empty() && id == targetId) return true;
    }
    return false;
}

// ============================================================================
//  Расширенные данные игрока: ник, оружие, броня, флаги состояния.
//  Всё только на ЧТЕНИЕ, цепочки короткие (2-5 vm_readv на поле), берутся
//  раз в тяжёлый скан (не каждый кадр) — на watchdog не влияет.
// ============================================================================

// Ник игрока: PM -> nicklabel(lH) -> nickname(UI.Text) -> m_Text.
// Возвращает "" если UI-подпись ещё не создана (бывает у только что
// заспавненных и у самого себя).
static std::string ox_readNickname(uint64_t pm) {
    if (!ox_isPtr(pm)) return "";
    uint64_t nl = rpm<uint64_t>(pm + ox::PM_NICKLABEL);
    if (!ox_isPtr(nl)) return "";
    uint64_t txt = rpm<uint64_t>(nl + ox::NICKLABEL_NICKNAME);
    if (!ox_isPtr(txt)) return "";
    uint64_t str = rpm<uint64_t>(txt + ox::UITEXT_M_TEXT);
    return ox_readManagedString(str);
}

// Оружие в руках: PM -> FPManager -> FPObject -> Item -> ItemData -> m_ShortName.
// Короткое имя компактнее для подписи под боксом ("ak47" вместо "Assault Rifle").
static std::string ox_readWeaponName(uint64_t pm) {
    if (!ox_isPtr(pm)) return "";
    uint64_t fp = rpm<uint64_t>(pm + ox::PM_FPMANAGER);
    if (!ox_isPtr(fp)) return "";
    uint64_t obj = rpm<uint64_t>(fp + ox::FP_CURRENT_WEAPON);
    if (!ox_isPtr(obj)) return "";
    uint64_t item = rpm<uint64_t>(obj + ox::FPOBJ_ITEM);
    if (!ox_isPtr(item)) return "";
    uint64_t data = rpm<uint64_t>(item + ox::ITEM_DATA);
    if (!ox_isPtr(data)) return "";
    std::string sn = ox_readManagedString(rpm<uint64_t>(data + ox::ITEMDATA_SHORTNAME));
    if (!sn.empty()) return sn;
    return ox_readManagedString(rpm<uint64_t>(data + ox::ITEMDATA_NAME));
}

// Флаги состояния. Enum PlayerManager.PlayerFlags: Sleeping / Spectating / Muted.
// Значения самих констант в дампе обнулены (обфускация), поэтому трактуем как
// битовую маску в порядке объявления — это стандартный [Flags] enum.
struct OxPlayerFlags { bool sleeping, spectating, muted, prime, inAir, respawning; };
static OxPlayerFlags ox_readPlayerFlags(uint64_t pm) {
    OxPlayerFlags f{};
    if (!ox_isPtr(pm)) return f;
    uint32_t bits = rpm<uint32_t>(pm + ox::PM_PLAYER_FLAGS);
    f.sleeping   = (bits & 1u) != 0;
    f.spectating = (bits & 2u) != 0;
    f.muted      = (bits & 4u) != 0;
    f.prime      = rpm<uint8_t>(pm + ox::PM_PRIME) != 0;
    f.inAir      = rpm<uint8_t>(pm + ox::PM_IS_IN_AIR) != 0;
    f.respawning = rpm<uint8_t>(pm + ox::PM_RESPAWNING) != 0;
    return f;
}

// Броня: PM -> vitals -> GenericVitals.m_Protection (ProtectionValues).
// Возвращает суммарное значение защиты, 0 если брони нет.
static float ox_readArmor(uint64_t pm) {
    if (!ox_isPtr(pm)) return 0.f;
    uint64_t v = rpm<uint64_t>(pm + ox::PM_VITALS);
    if (!ox_isPtr(v)) return 0.f;
    uint64_t prot = rpm<uint64_t>(v + ox::VITALS_PROTECTION);
    if (!ox_isPtr(prot)) return 0.f;
    // ProtectionValues — managed-объект с набором float'ов. Берём первое поле
    // после заголовка как обобщённый уровень защиты.
    float a = rpm<float>(prot + 0x10);
    if (!isfinite(a) || a < 0.f || a > 1000.f) return 0.f;
    return a;
}

// --- Кватернион-хелперы для обхода иерархии Transform ---
struct Quat { float x, y, z, w; };

static constexpr float DEG2RAD = 0.01745329251994f;

static inline Vector3 quatRotate(const Quat &q, const Vector3 &v) {
    float x2 = q.x * 2.f, y2 = q.y * 2.f, z2 = q.z * 2.f;
    float xx = q.x * x2, yy = q.y * y2, zz = q.z * z2;
    float xy = q.x * y2, xz = q.x * z2, yz = q.y * z2;
    float wx = q.w * x2, wy = q.w * y2, wz = q.w * z2;
    Vector3 r;
    r.x = (1.f - (yy + zz)) * v.x + (xy - wz) * v.y + (xz + wy) * v.z;
    r.y = (xy + wz) * v.x + (1.f - (xx + zz)) * v.y + (yz - wx) * v.z;
    r.z = (xz - wy) * v.x + (yz + wx) * v.y + (1.f - (xx + yy)) * v.z;
    return r;
}

static inline Quat quatMul(const Quat &a, const Quat &b) {
    return Quat{
        a.w * b.x + a.x * b.w + a.y * b.z - a.z * b.y,
        a.w * b.y - a.x * b.z + a.y * b.w + a.z * b.x,
        a.w * b.z + a.x * b.y - a.y * b.x + a.z * b.w,
        a.w * b.w - a.x * b.x - a.y * b.y - a.z * b.z
    };
}

// Низкоу��овневое чтение мировой TRS из НАТИВНОГО указателя Transform (managed).
// managed Transform + 0x10 -> internal; internal + 0x28 -> matrixData;
//   matrixData + 0x90 -> Vector3 pos; +0xA0 -> Quaternion rot.
// Возвращает true при валидном matrixData. rot/pos могут быть nullptr.
static bool ox_transformWorld(uint64_t transform, Vector3 *pos, Quat *rot, bool full, const char *tag) {
    if (!ox_isPtr(transform)) return false;
    uint64_t internal = rpm<uint64_t>(transform + ox::OBJ_CACHED_PTR);
    if (full && tag) oxlog::ptrstep(tag, transform + ox::OBJ_CACHED_PTR, internal);
    if (!ox_isPtr(internal)) return false;
    uint64_t matrixData = rpm<uint64_t>(internal + ox::TR_INT_MATRIXPTR);
    if (!ox_isPtr(matrixData)) return false;

    if (pos) *pos = rpm<Vector3>(matrixData + ox::TR_MATRIX_WORLDPOS);
    if (rot) *rot = rpm<Quat>(matrixData + ox::TR_MATRIX_ROT);
    return true;
}

// ============================================================================
//  МАТРИЦА КАМЕРЫ — забираем у игры то, чем она РИСУЕТ кадр
//
//  Сейчас базис камеры реконструируется из углов MouseLook + FOV из FPManager.
//  Это работает, но это ПРИБЛИЖЕНИЕ: любая правка, которую движок вносит в
//  матрицу (шейк, отдача, наклон, нестандартный projection при ADS) мимо нас.
//
//  Правильный источник — сама матрица:
//    RaycastManager.m_WorldCamera(0x30) -> UnityEngine.Camera (managed)
//    Camera + OBJ_CACHED_PTR(0x10)      -> нативный объект камеры (в libunity)
//    нативный объект + ???              -> worldToCameraMatrix / projectionMatrix
//
//  Последнее смещение зависит от версии Unity и живёт в libunity.so, поэтому
//  захардкодить его нельзя. Зато матрицу можно НАЙТИ по подписи:
//    * view-матрица: последняя строка ровно (0,0,0,1), верхний блок 3x3
//      ортонормирован (длина каждой строки == 1 с точностью до 1e-3)
//    * projection: столбцовая форма Unity — m00,m11 != 0, m23 == -1 либо 1,
//      остальные элементы вне диагонали и последнего столбца == 0
//
//  Сканируем ОДИН объект в окне 0x400 байт с шагом 4. Это ~256 точечных чтений
//  один раз за сессию, не массовый скан памяти — watchdog на такое не реагирует.
// ============================================================================


// Кэш найденных смещений. -1 = ещё не искали, -2 = искали и не нашли.
static int      g_camViewMatOff = -1;
static int      g_camProjMatOff = -1;
static uint64_t g_camNativeCached = 0;   // для какого нативного объекта нашли

// Проверка: похоже ли на матрицу вида (world->camera).
// Последняя строка (0,0,0,1) + ортонормированный поворот 3x3.
static bool ox_looksLikeViewMatrix(const OxMat4 &M) {
    for (int i = 0; i < 16; i++) {
        if (!isfinite(M.m[i]) || fabsf(M.m[i]) > 1e6f) return false;
    }
    // Unity Matrix4x4 в памяти: m00 m10 m20 m30 m01 m11 ... (column-major).
    // Последний столбец в памяти — элементы 12..15 = m03 m13 m23 m33.
    // Для view-матрицы m33 == 1, а строка (m30,m31,m32) == 0.
    if (fabsf(M.m[3])  > 1e-4f) return false;   // m30
    if (fabsf(M.m[7])  > 1e-4f) return false;   // m31
    if (fabsf(M.m[11]) > 1e-4f) return false;   // m32
    if (fabsf(M.m[15] - 1.0f) > 1e-4f) return false; // m33

    // Три базисных вектора (столбцы 0..2, без трансляции) должны быть единичными.
    float l0 = sqrtf(M.m[0]*M.m[0] + M.m[1]*M.m[1] + M.m[2]*M.m[2]);
    float l1 = sqrtf(M.m[4]*M.m[4] + M.m[5]*M.m[5] + M.m[6]*M.m[6]);
    float l2 = sqrtf(M.m[8]*M.m[8] + M.m[9]*M.m[9] + M.m[10]*M.m[10]);
    if (fabsf(l0 - 1.f) > 2e-3f) return false;
    if (fabsf(l1 - 1.f) > 2e-3f) return false;
    if (fabsf(l2 - 1.f) > 2e-3f) return false;

    // И взаимно перпендикулярными.
    float d01 = M.m[0]*M.m[4] + M.m[1]*M.m[5] + M.m[2]*M.m[6];
    float d02 = M.m[0]*M.m[8] + M.m[1]*M.m[9] + M.m[2]*M.m[10];
    if (fabsf(d01) > 3e-3f || fabsf(d02) > 3e-3f) return false;

    // Трансляция не должна быть нулевой (иначе это просто identity-заглушка).
    float t = fabsf(M.m[12]) + fabsf(M.m[13]) + fabsf(M.m[14]);
    if (t < 1e-4f) return false;
    return true;
}

// Проверка: похоже ли на проекционную матрицу перспективы.
// Unity column-major: m00 на [0], m11 на [5], m22 на [10], m23 на [11], m32 на [14].
static bool ox_looksLikeProjMatrix(const OxMat4 &M) {
    for (int i = 0; i < 16; i++) {
        if (!isfinite(M.m[i]) || fabsf(M.m[i]) > 1e6f) return false;
    }
    // Диагональные множители FOV: осмысленный диапазон для игровых камер.
    if (M.m[0] < 0.15f || M.m[0] > 12.f) return false;   // m00
    if (M.m[5] < 0.15f || M.m[5] > 12.f) return false;   // m11
    // m23 == -1 для right-handed перспективы Unity.
    if (fabsf(M.m[11] + 1.0f) > 1e-3f) return false;
    // m33 == 0 у перспективы (у ортографической было бы 1).
    if (fabsf(M.m[15]) > 1e-4f) return false;
    // Нули там, где их требует форма перспективной матрицы.
    const int zeros[] = {1, 2, 3, 4, 6, 7, 12, 13};
    for (int z : zeros) if (fabsf(M.m[z]) > 1e-4f) return false;
    // m22 отрицательный (far/near диапазон), m32 отрицательный.
    if (M.m[10] > 0.f || M.m[14] > 0.f) return false;
    return true;
}

// Ищет смещения обеих матриц внутри нативного объекта камеры.
// Вызывать редко: результат кэшируется до смены объекта камеры.
static void ox_findCameraMatrices(uint64_t nativeCam) {
    if (!ox_isPtr(nativeCam)) return;
    if (nativeCam == g_camNativeCached && g_camViewMatOff != -1) return;

    g_camNativeCached = nativeCam;
    g_camViewMatOff = -2;
    g_camProjMatOff = -2;

    // Окно поиска. Матрицы в UnityEngine::Camera лежат в первых ~1 КБ.
    const int WINDOW = 0x600;
    const int STEP   = 4;

    for (int off = 0; off + 64 <= WINDOW; off += STEP) {
        OxMat4 M;
        if (!vm_readv(nativeCam + off, &M, sizeof(M))) continue;

        if (g_camViewMatOff == -2 && ox_looksLikeViewMatrix(M)) {
            g_camViewMatOff = off;
            OXLOGI("[cammat] view-матрица найдена @+0x%X  t=(%.2f %.2f %.2f)",
                   off, M.m[12], M.m[13], M.m[14]);
        }
        if (g_camProjMatOff == -2 && ox_looksLikeProjMatrix(M)) {
            g_camProjMatOff = off;
            OXLOGI("[cammat] proj-матрица найдена @+0x%X  m00=%.4f m11=%.4f",
                   off, M.m[0], M.m[5]);
        }
        if (g_camViewMatOff >= 0 && g_camProjMatOff >= 0) break;
    }

    if (g_camViewMatOff < 0)
        OXLOGI("[cammat] view-матрица НЕ найдена в окне 0x%X", WINDOW);
    if (g_camProjMatOff < 0)
        OXLOGI("[cammat] proj-матрица НЕ найдена в окне 0x%X", WINDOW);
}

// Достаёт нативный объект камеры из PM. Возвращает 0 если не вышло.
static uint64_t ox_getNativeCamera(uint64_t player) {
    if (!ox_isPtr(player)) return 0;
    uint64_t rm = rpm<uint64_t>(player + ox::PM_RAYCASTMANAGER);
    if (!ox_isPtr(rm)) return 0;
    uint64_t camManaged = rpm<uint64_t>(rm + ox::RM_WORLD_CAMERA);
    if (!ox_isPtr(camManaged)) return 0;
    uint64_t native = rpm<uint64_t>(camManaged + ox::OBJ_CACHED_PTR);
    return ox_isPtr(native) ? native : 0;
}

// Позиция камеры ИЗ view-матрицы. Для ортонормированной view-матрицы
// V = [R | t], где t = -R * eye, поэтому eye = -R^T * t.
// Критично для аимбота: углы доворота обязаны считаться от ТОЙ ЖЕ точки, из
// которой строится проекция. Если брать позицию из worldCameraRoot (наша
// реконструкция), а проецировать матрицей — прицел уезжает по вертикали
// ровно на разницу этих двух точек. Это и был симптом «целит выше игрока».
static bool ox_cameraPosFromView(const OxMat4 &V, Vector3 *out) {
    if (!out) return false;
    // Column-major: столбец i = {V.m[i*4+0], V.m[i*4+1], V.m[i*4+2]}.
    // R^T * t: строки R — это компоненты одного индекса по всем столбцам.
    float tx = V.m[12], ty = V.m[13], tz = V.m[14];
    out->x = -(V.m[0]*tx + V.m[1]*ty + V.m[2]*tz);
    out->y = -(V.m[4]*tx + V.m[5]*ty + V.m[6]*tz);
    out->z = -(V.m[8]*tx + V.m[9]*ty + V.m[10]*tz);
    return isfinite(out->x) && isfinite(out->y) && isfinite(out->z);
}

// Читает VP = proj * view из нативной камеры. false если смещения неизвестны.
static bool ox_readViewProjection(uint64_t nativeCam, OxMat4 *outVP) {
    if (!outVP || !ox_isPtr(nativeCam)) return false;
    if (g_camViewMatOff < 0 || g_camProjMatOff < 0) return false;

    OxMat4 V, P;
    if (!vm_readv(nativeCam + g_camViewMatOff, &V, sizeof(V))) return false;
    if (!vm_readv(nativeCam + g_camProjMatOff, &P, sizeof(P))) return false;
    if (!ox_looksLikeViewMatrix(V) || !ox_looksLikeProjMatrix(P)) return false;

    g_camView = V;
    g_camPosValid = ox_cameraPosFromView(V, &g_camPosFromMatrix);

    // Column-major умножение: VP = P * V.
    for (int c = 0; c < 4; c++) {
        for (int r = 0; r < 4; r++) {
            float sum = 0.f;
            for (int k = 0; k < 4; k++)
                sum += P.m[k * 4 + r] * V.m[c * 4 + k];
            outVP->m[c * 4 + r] = sum;
        }
    }
    return true;
}

// World -> screen через настоящую VP-матрицу игры.
// Возвращает false если точка за камерой или матрицы недоступны.
static bool ox_w2sMatrix(const OxMat4 &VP, const Vector3 &p,
                         float screenW, float screenH, ImVec2 *out) {
    if (!out) return false;
    float cx = VP.m[0]*p.x + VP.m[4]*p.y + VP.m[8]*p.z  + VP.m[12];
    float cy = VP.m[1]*p.x + VP.m[5]*p.y + VP.m[9]*p.z  + VP.m[13];
    float cw = VP.m[3]*p.x + VP.m[7]*p.y + VP.m[11]*p.z + VP.m[15];
    if (cw < 0.01f) return false;             // за камерой
    float ndcX = cx / cw, ndcY = cy / cw;
    if (!isfinite(ndcX) || !isfinite(ndcY)) return false;
    out->x = (ndcX * 0.5f + 0.5f) * screenW;
    out->y = (1.f - (ndcY * 0.5f + 0.5f)) * screenH;   // Y вниз в экранных
    return true;
}

// ============================================================================
//  ЯКОРЯ МОДЕЛИ — привязка ESP к тому, что игра РИСУЕТ, а не к серверному тику
//
//  Проблема старого пути: позиция бралась из PM.lastTickPosition (0x1C8) —
//  это серверный тик, 10-20 Гц. Модель на экране между тиками движется
//  интерполированно, поэтому бокс отставал от бегущей цели на 0.5-1 м, и
//  вертикальную привязку приходилось подгонять руками (espBoxYOffset).
//
//  Новый путь берёт данные ровно из тех объектов, по которым игра строит кадр:
//    KCC.head (0x88)                      -> Transform головы, интерполирован
//    KCC.Motor(0x68).LastInterpolatedPosition(0x1EC) -> позиция ног этого кадра
//
//  Габариты бокса теперь ФАКТИЧЕСКИЕ (от ног до головы), а не «позиция + 1.8 м
//  на глаз». Вертикальный оффсет при этом не нужен вообще.
// ============================================================================

struct OxModelAnchors {
    Vector3 head{0,0,0};    // мировая позиция головы (реальная кость)
    Vector3 feet{0,0,0};    // мировая позиция ног (интерполированная мотором)
    float   height = 0.f;   // фактический рост = head.y - feet.y
    bool    valid  = false;
    // Диагностика: на каком шаге оборвалась цепочка.
    // 0 = ок, 1 = нет kccReference, 2 = не нашли KCC ни в обёртке ни напрямую,
    // 3 = не прочитался трансформ головы, 4 = нет позиции ног,
    // 5 = геометрия не прошла санити (см. lastDy / lastDxz).
    int      failStage = 0;
    uint64_t kccPtr    = 0;
    float    lastDy    = 0.f;
    float    lastDxz   = 0.f;
    // Живые данные капсулы: высота этого кадра и признак приседа.
    uint64_t headTr    = 0;     // Transform головы (для диагностики stage 3)
    uint64_t headCached = 0;    // его m_CachedPtr
    uint64_t headMatrix = 0;    // matrixData внутри нативного трансформа
    bool     headFromCapsule = false; // голова взята геометрически, не из кости
    float    capsuleH  = 0.f;   // Motor.CapsuleHeight сейчас
    float    normalH   = 0.f;   // KCC.normalHeight (рост стоя)
    bool     crouching = false; // высота просела ниже 85% от нормальной
    Vector3  velocity{0,0,0};   // Motor.BaseVelocity — точнее численной производной
};

// Читает якоря модели игрока. ~6 точечных vm_readv, никаких сканов.
// Возвращает valid=false если цепочка оборвана или геометрия не прошла
// санити-чек — вызывающий тогда откатывается на старый путь.
static OxModelAnchors ox_readModelAnchors(uint64_t player) {
    OxModelAnchors a;
    if (!ox_isPtr(player)) return a;

    // PM.kccReference — это InterfaceReference<sA>, MANAGED-ОБЪЁКТ, а не сам KCC.
    // В дампе его поле _component значится на +0x0, но это смещение внутри
    // блока данных: у managed-объекта первые 0x10 байт занимает заголовок
    // (klass + monitor). Реальный KCC лежит на +0x10 от обёртки.
    // Пробуем оба варианта — на случай если поле инлайнится напрямую.
    uint64_t kccRaw = rpm<uint64_t>(player + ox::PM_KCC_REFERENCE);
    if (!ox_isPtr(kccRaw)) { a.failStage = 1; return a; }

    // Ищем настоящий KCC САМОПРОВЕРКОЙ, а не угадыванием смещения внутри
    // обёртки: у KCC поле player (+0x78) указывает ОБРАТНО на наш PM. Такое
    // совпадение случайным быть не может, поэтому проверка однозначна и
    // переживёт любую перетасовку полей InterfaceReference.
    // v9 (подтверждённо рабочая) проверка: back-ref KCC.player==PM. Мотор-проверку
    // из v10 откатил — она в критическом пути и могла отвергать валидный KCC, у
    // которого Motor на момент кадра ещё не присвоен.
    auto isRealKcc = [&](uint64_t cand) -> bool {
        if (!ox_isPtr(cand)) return false;
        return rpm<uint64_t>(cand + ox::KCC_PLAYER) == player;
    };

    uint64_t kcc = 0;
    if (isRealKcc(kccRaw)) {
        kcc = kccRaw;                       // поле хранит KCC напрямую
    } else {
        // Обёртка: перебираем её первые 0x40 байт — _component лежит там.
        for (int w = 0x00; w <= 0x30 && !kcc; w += 8) {
            uint64_t cand = rpm<uint64_t>(kccRaw + w);
            if (isRealKcc(cand)) kcc = cand;
        }
    }
    if (!kcc) { a.failStage = 2; return a; }
    a.kccPtr = kcc;

    // UPDATE 2026/07/31 v10: КРИТИЧЕСКИЙ ФИКС "боксы прилипли к камере".
    // Из лога: kcc self-verified (KCC.player@0x78 == PM), НО KCC.head@0x88 == 0x0
    // для ВСЕХ удалённых игроков (headTr=0x0, stage=3, anchors=0/N каждый кадр).
    // Причина: `head` Transform (FP-риг точки глаз) инстанцируется движком ТОЛЬКО
    // для ЛОКАЛЬНОГО игрока. У remote-игроков он null — их модель это TP-скелет.
    // СТАРЫЙ БАГ: `if (!ox_isPtr(headTr)) { failStage=3; return; }` возвращался
    // ДО Motor-фолбэка. Из-за этого W2S не получал НИ ОДНОГО валидного якоря →
    // ESP рисовал по устаревшим экранным координатам → боксы «прилипали к экрану»
    // и ехали вместе с камерой. Теперь head=null НЕ фатален: сразу идём в Motor
    // (feet + CapsuleHeight), который есть у всех игроков.
    // ═══════════════════════════════════════════════════════════════════════
    // UPDATE 2026/07/31 v17: ФУНДАМЕНТАЛЬНЫЙ ФИКС «боксы застряли на спавне».
    // ═══════════════════════════════════════════════════════════════════════
    // Доказано сравнением v9-лога (рабочего) и v13:
    //   v9: stage=0 (успех) = 0 раз, stage=3 (обрыв на head=null) = 61 раз.
    //       → anchor ВСЕГДА падал у remote, бокс откатывался на livePos
    //         (PM.lastTickPosition) — и та ДВИГАЛАСЬ. Поэтому v9 работал.
    //   v13: мой v10-«фикс» заставил anchor УСПЕВАТЬ через Motor-фолбэк.
    //        anch.feet = Motor.LastInterpolatedPosition, а она ЗАМОРОЖЕНА у
    //        remote-игроков (их KinematicCharacterMotor локально НЕ симулируется,
    //        позиция приходит через networkPositionObserver, не в Motor).
    //        В логе: pos=(-10.74,10.38,71.52) не менялась 7 кадров подряд.
    //
    // ВЫВОД: Motor.LastInterpolatedPosition НЕЛЬЗЯ использовать для позиции
    // remote-игроков. Единственный ДВИЖУЩИЙСЯ источник — PM.lastTickPosition.
    // Motor даёт только СКАЛЯР высоты капсулы (он валиден, cap=1.25 в логе) —
    // им пользуемся для роста бокса, но НЕ для позиции.
    //
    // Новый порядок:
    //   feet = PM.lastTickPosition (ДВИЖЕТСЯ — сервер-тик, интерполируется игрой)
    //   height = Motor.CapsuleHeight (скаляр, для верха бокса)
    //   head = feet + height + lookOffset
    uint64_t motor = rpm<uint64_t>(kcc + ox::KCC_MOTOR);

    // --- Ноги: ТОЛЬКО lastTickPosition (единственный движущийся источник) ---
    Vector3 tickPos = rpm<Vector3>(player + ox::PM_LAST_TICK_POS);
    bool haveFeet = false;
    if (isfinite(tickPos.x) && isfinite(tickPos.y) && isfinite(tickPos.z) &&
        (fabsf(tickPos.x) > 0.001f || fabsf(tickPos.z) > 0.001f)) {
        a.feet = tickPos; haveFeet = true;
    }
    // Фолбэк если tick пуст (первые кадры): lastSavedPosition.
    if (!haveFeet) {
        Vector3 savedPos = rpm<Vector3>(player + ox::PM_LAST_SAVED_POS);
        if (isfinite(savedPos.x) && (fabsf(savedPos.x) > 0.001f || fabsf(savedPos.z) > 0.001f)) {
            a.feet = savedPos; haveFeet = true;
        }
    }
    if (!haveFeet) { a.failStage = 4; return a; }

    // --- Высота капсулы (скаляр) из Motor — для роста бокса ---
    float capH = 1.80f;   // дефолт-рост если Motor не прочитался
    a.headTr = rpm<uint64_t>(kcc + ox::KCC_HEAD);   // для диагностики
    if (ox_isPtr(motor)) {
        float ch = rpm<float>(motor + ox::MOTOR_CAPSULE_HEIGHT);
        if (isfinite(ch) && ch > 0.3f && ch < 3.5f) capH = ch;
    }
    a.capsuleH = capH;

    // --- Голова = ноги + высота капсулы + lookHeightOffset ---
    float lo = rpm<float>(kcc + ox::KCC_LOOK_HEIGHT_OFF);
    if (!isfinite(lo) || lo < -1.f || lo > 1.f) lo = 0.f;
    a.head = Vector3(a.feet.x, a.feet.y + capH + lo, a.feet.z);
    a.headFromCapsule = true;

    // --- Санити: рост человека и голова примерно над ногами ---
    // Отсекает мусор от переиспользованной памяти и чужие указатели.
    float dy  = a.head.y - a.feet.y;
    float dx  = a.head.x - a.feet.x;
    float dz  = a.head.z - a.feet.z;
    float dxz = sqrtf(dx*dx + dz*dz);
    if (!isfinite(dy) || dy < 0.40f || dy > 2.60f || dxz > 1.50f) {
        a.failStage = 5; a.lastDy = dy; a.lastDxz = dxz; return a;
    }

    a.lastDy = dy; a.lastDxz = dxz;
    a.height = dy;

    // --- Живая геометрия капсулы: присед и скорость ---
    if (ox_isPtr(motor)) {
        float ch = rpm<float>(motor + ox::MOTOR_CAPSULE_HEIGHT);
        float nh = rpm<float>(kcc   + ox::KCC_NORMAL_HEIGHT);
        if (isfinite(ch) && ch > 0.2f && ch < 4.0f) a.capsuleH = ch;
        if (isfinite(nh) && nh > 0.2f && nh < 4.0f) a.normalH  = nh;
        if (a.capsuleH > 0.f && a.normalH > 0.f)
            a.crouching = (a.capsuleH < a.normalH * 0.85f);

        Vector3 v = rpm<Vector3>(motor + ox::MOTOR_BASE_VELOCITY);
        if (isfinite(v.x) && isfinite(v.y) && isfinite(v.z) &&
            fabsf(v.x) < 100.f && fabsf(v.y) < 100.f && fabsf(v.z) < 100.f)
            a.velocity = v;
    }
    a.valid  = true;
    return a;
}

// ============================================================================
//  СКЕЛЕТ — чтение реальных костей модели игрока
//
//  Цепочка (оффсеты из il2cpp.h дампа 2026/07/24):
//    PM + PM_ANIMATOR(0x190)                -> UnityEngine.Animator
//    Animator..CharacterAnimation           -> ищем через PM.characterModel
//    CharacterAnimation + 0x30              -> PlayerModelInfo
//    PlayerModelInfo + 0x20 head            -> Transform головы
//                    + 0x28 rightWeaponHolder -> Transform правой кисти
//                    + 0x30 leftWeaponHolder  -> Transform левой кисти
//                    + 0x40 body            -> Transform корпуса
//    CharacterAnimation + 0x38              -> Ragdoll
//    Ragdoll + 0x20 m_Pelvis                -> Rigidbody таза
//
//  Читаем ЧЕТЫРЕ реальные кости (голова, корпус, две кисти) + таз, остальные
//  суставы достраиваем интерполяцией. Так на игрока уходит ~10 vm_readv вместо
//  ~45 при полном обходе скелета — важно, потому что watchdog игры реагирует
//  на объём чтений.
// ============================================================================

// Заполняет кости в PlayerCacheData. feet — позиция ног (после yOffset).
// Возвращает true если удалось прочитать хотя бы голову.
// ── РЕАЛЬНЫЙ анимированный скелет из lag-comp хитбоксов (eR[]) ───────────────
//  Читает ЖИВЫЕ мировые позиции костей (голова/грудь/ноги/ступни/кисти), которые
//  игра пересчитывает каждый тик для лаг-компенсации попаданий. Ноги и кисти
//  ДВИГАЮТСЯ по-настоящему (анимация), в отличие от процедурного фолбэка. Это
//  единственный источник костей, живой у REMOTE-игроков (KCC.head=null, Motor
//  заморожен). Цепочка: PM.kccReference(0xB0) -> SingleKcc(player@0x80 back-ref)
//  -> hitBoxRecorderRoot(0x78) -> BnM eR[] (0x80) -> eR{HitBox*@0x10, wpos@0x34}.
static bool ox_readSkeletonReal(uint64_t player, const Vector3 &feet, PlayerCacheData &out) {
    if (!ox_isPtr(player)) return false;

    // 1) Резолв SingleKcc через Mirror-обёртку по back-ref player(0x80)==наш PM.
    uint64_t wrap = rpm<uint64_t>(player + ox::PM_KCC_REFERENCE);
    if (!ox_isPtr(wrap)) return false;
    uint64_t skcc = 0;
    if (rpm<uint64_t>(wrap + ox::SKCC_PLAYER) == player) skcc = wrap;
    else for (int w = 0x00; w <= 0x40 && !skcc; w += 8) {
        uint64_t cand = rpm<uint64_t>(wrap + w);
        if (ox_isPtr(cand) && rpm<uint64_t>(cand + ox::SKCC_PLAYER) == player) skcc = cand;
    }
    if (!ox_isPtr(skcc)) return false;

    // 2) recorder -> BnM (eR[])
    uint64_t rec = rpm<uint64_t>(skcc + ox::SKCC_RECORDER);
    if (!ox_isPtr(rec)) return false;
    uint64_t bnm = rpm<uint64_t>(rec + ox::HBR_BNM);
    if (!ox_isPtr(bnm)) return false;
    int n = rpm<int>(bnm + ox::ARRAY_COUNT);
    if (n <= 0 || n > 64) return false;
    uint64_t base = bnm + ox::ARRAY_DATA;

    // 3) собрать кости по зонам HitArea (0 Head,1 Chest,2 Leg,3 Foot,4 Hand)
    Vector3 head{0,0,0}, chest{0,0,0};
    bool haveHead = false, haveChest = false;
    std::vector<Vector3> legs, feetHB, hands;
    for (int i = 0; i < n; ++i) {
        uint64_t eR = rpm<uint64_t>(base + (uint64_t)i * 8);
        if (!ox_isPtr(eR)) continue;
        Vector3 wp = rpm<Vector3>(eR + ox::ER_WORLDPOS);
        if (!isfinite(wp.x) || !isfinite(wp.y) || !isfinite(wp.z)) continue;
        uint64_t hb = rpm<uint64_t>(eR + ox::ER_HITBOX);
        int area = ox_isPtr(hb) ? rpm<int>(hb + ox::HB_HITAREA) : -1;
        switch (area) {
            case 0: head = wp;  haveHead = true;  break;
            case 1: chest = wp; haveChest = true; break;
            case 2: if (legs.size()   < 4) legs.push_back(wp);   break;
            case 3: if (feetHB.size() < 4) feetHB.push_back(wp); break;
            case 4: if (hands.size()  < 4) hands.push_back(wp);  break;
            default: break;
        }
    }
    if (!haveHead) return false;

    // валидация головы относительно ног (защита от указателя прошлого владельца)
    float dy  = head.y - feet.y;
    float dxz = sqrtf((head.x-feet.x)*(head.x-feet.x) + (head.z-feet.z)*(head.z-feet.z));
    if (!isfinite(dy) || dy < 0.4f || dy > 2.6f || dxz > 2.0f) return false;

    if (!haveChest) chest = Vector3(head.x + (feet.x-head.x)*0.34f,
                                    head.y + (feet.y-head.y)*0.34f,
                                    head.z + (feet.z-head.z)*0.34f);

    // боковой вектор для разнесения лево/право — из кистей, иначе ступней, иначе X
    Vector3 side(1.f, 0.f, 0.f);
    auto pickSide = [&](const std::vector<Vector3>& v)->bool{
        if (v.size() >= 2) { Vector3 d(v[0].x-v[1].x, 0.f, v[0].z-v[1].z);
            float L = sqrtf(d.x*d.x + d.z*d.z); if (L > 0.05f) { side = Vector3(d.x/L,0.f,d.z/L); return true; } }
        return false;
    };
    if (!pickSide(hands)) if (!pickSide(feetHB)) pickSide(legs);
    auto dotSide = [&](const Vector3& p){ return (p.x-chest.x)*side.x + (p.z-chest.z)*side.z; };
    auto splitLR = [&](std::vector<Vector3>& v, Vector3& R, Vector3& Lp, bool& hasR, bool& hasL){
        hasR = hasL = false;
        for (auto& p : v) { if (dotSide(p) >= 0.f) { if(!hasR){R=p;hasR=true;} } else { if(!hasL){Lp=p;hasL=true;} } }
        if (v.size() == 1) { R = Lp = v[0]; hasR = hasL = true; }
        if (v.size() >= 2 && (!hasR || !hasL)) { R = v[0]; Lp = v[1]; hasR = hasL = true; }
    };
    Vector3 handR,handL,footR,footL,legR,legL; bool hR,hL,fR,fL,lR,lL;
    splitLR(hands,  handR, handL, hR, hL);
    splitLR(feetHB, footR, footL, fR, fL);
    splitLR(legs,   legR,  legL,  lR, lL);

    Vector3 pelvis;
    if (lR && lL) pelvis = Vector3((legR.x+legL.x)*0.5f, (legR.y+legL.y)*0.5f + dy*0.10f, (legR.z+legL.z)*0.5f);
    else          pelvis = Vector3(chest.x + (feet.x-chest.x)*0.55f,
                                    chest.y + (feet.y-chest.y)*0.55f,
                                    chest.z + (feet.z-chest.z)*0.55f);

    float shoulderHalf = dy * 0.115f, hipHalf = dy * 0.075f;
    Vector3 neck = Vector3(head.x+(chest.x-head.x)*0.42f, head.y+(chest.y-head.y)*0.42f, head.z+(chest.z-head.z)*0.42f);

    out.headPos      = head;                 // РЕАЛЬНАЯ
    out.neckPos      = neck;
    out.spine1Pos    = chest;                // РЕАЛЬНАЯ
    out.spine2Pos    = pelvis;
    out.rshoulderPos = Vector3(chest.x + side.x*shoulderHalf, chest.y, chest.z + side.z*shoulderHalf);
    out.lshoulderPos = Vector3(chest.x - side.x*shoulderHalf, chest.y, chest.z - side.z*shoulderHalf);
    out.rlowarmPos   = hR ? handR : out.rshoulderPos;   // РЕАЛЬНАЯ кисть (анимируется)
    out.llowarmPos   = hL ? handL : out.lshoulderPos;
    out.ruparmPos    = Vector3((out.rshoulderPos.x+out.rlowarmPos.x)*0.5f,(out.rshoulderPos.y+out.rlowarmPos.y)*0.5f,(out.rshoulderPos.z+out.rlowarmPos.z)*0.5f);
    out.luparmPos    = Vector3((out.lshoulderPos.x+out.llowarmPos.x)*0.5f,(out.lshoulderPos.y+out.llowarmPos.y)*0.5f,(out.lshoulderPos.z+out.llowarmPos.z)*0.5f);
    out.rhipPos      = Vector3(pelvis.x + side.x*hipHalf, pelvis.y, pelvis.z + side.z*hipHalf);
    out.lhipPos      = Vector3(pelvis.x - side.x*hipHalf, pelvis.y, pelvis.z - side.z*hipHalf);
    out.rfootPos     = fR ? footR : Vector3(out.rhipPos.x, feet.y, out.rhipPos.z);   // РЕАЛЬНАЯ ступня
    out.lfootPos     = fL ? footL : Vector3(out.lhipPos.x, feet.y, out.lhipPos.z);
    out.rkneePos     = lR ? legR : Vector3((out.rhipPos.x+out.rfootPos.x)*0.5f,(out.rhipPos.y+out.rfootPos.y)*0.5f,(out.rhipPos.z+out.rfootPos.z)*0.5f); // РЕАЛЬНАЯ голень
    out.lkneePos     = lL ? legL : Vector3((out.lhipPos.x+out.lfootPos.x)*0.5f,(out.lhipPos.y+out.lfootPos.y)*0.5f,(out.lhipPos.z+out.lfootPos.z)*0.5f);

    out.hasSkeletonData = true;
    return true;
}

static bool ox_readSkeleton(uint64_t player, const Vector3 &feet, PlayerCacheData &out) {
    out.hasSkeletonData = false;
    if (!ox_isPtr(player)) return false;

    // PRIMARY: реальные анимированные кости (ноги/ступни/кисти двигаются). Если
    // не прочиталось (recorder пуст / не в матче) — процедурный фолбэк ниже.
    if (ox_readSkeletonReal(player, feet, out)) return true;

    Vector3 headW{0,0,0}, bodyW{0,0,0}, rhW{0,0,0}, lhW{0,0,0};
    bool haveHead = false, haveBody = false, haveRH = false, haveLH = false;

    // 1) KCC.head — самый надёжный и дешёвый источник головы.
    // PM+0xB0 это InterfaceReference<sA>, ОБЁРТКА, а не сам KCC. Раньше здесь
    // читалось напрямую — поэтому вся цепочка (голова, руки, корпус) молча
    // рвалась и скелет не рисовался ВООБЩЕ. Якоря я вчера починил, а этот
    // путь пропустил: он свой, отдельный.
    // Ищем настоящий KCC самопроверкой: у него поле player(0x78) указывает
    // ОБРАТНО на наш PM — случайным такое совпадение быть не может.
    uint64_t kccRaw = rpm<uint64_t>(player + ox::PM_KCC_REFERENCE);
    uint64_t kcc = 0;
    if (ox_isPtr(kccRaw)) {
        if (rpm<uint64_t>(kccRaw + ox::KCC_PLAYER) == player) {
            kcc = kccRaw;
        } else {
            for (int w = 0x00; w <= 0x30 && !kcc; w += 8) {
                uint64_t cand = rpm<uint64_t>(kccRaw + w);
                if (ox_isPtr(cand) &&
                    rpm<uint64_t>(cand + ox::KCC_PLAYER) == player) kcc = cand;
            }
        }
    }
    if (ox_isPtr(kcc)) {
        uint64_t headTr = rpm<uint64_t>(kcc + ox::KCC_HEAD);
        if (ox_isPtr(headTr))
            haveHead = ox_transformWorld(headTr, &headW, nullptr, false, nullptr);
    }

    // 2) PlayerModelInfo через CharacterAnimation — руки и корпус.
    //    CharacterAnimation достаём из KCC.faM (0x108).
    if (ox_isPtr(kcc)) {
        uint64_t charAnim = rpm<uint64_t>(kcc + 0x108);   // faM
        if (ox_isPtr(charAnim)) {
            uint64_t pmi = rpm<uint64_t>(charAnim + ox::CHARANIM_MODELINFO);
            if (ox_isPtr(pmi)) {
                if (!haveHead) {
                    uint64_t h = rpm<uint64_t>(pmi + ox::PMI_HEAD);
                    if (ox_isPtr(h)) haveHead = ox_transformWorld(h, &headW, nullptr, false, nullptr);
                }
                uint64_t b = rpm<uint64_t>(pmi + ox::PMI_BODY);
                if (ox_isPtr(b)) haveBody = ox_transformWorld(b, &bodyW, nullptr, false, nullptr);
                uint64_t r = rpm<uint64_t>(pmi + ox::PMI_RIGHT_HAND);
                if (ox_isPtr(r)) haveRH = ox_transformWorld(r, &rhW, nullptr, false, nullptr);
                uint64_t l = rpm<uint64_t>(pmi + ox::PMI_LEFT_HAND);
                if (ox_isPtr(l)) haveLH = ox_transformWorld(l, &lhW, nullptr, false, nullptr);
            }
        }
    }

    // ФОЛБЭК: тот же приём, что и в ox_readModelAnchors — если кость головы
    // не читается (трансформ есть, а матрица не отдаётся), берём точку глаз
    // геометрически из живой капсулы моторa. Без этого скелет молча не
    // рисовался вообще, хотя все остальные данные были на месте.
    if (!haveHead && ox_isPtr(kcc)) {
        // UPDATE 2026/07/31 v20: голову якорим к ДВИЖУЩИМСЯ ногам (feet =
        // lastTickPosition, передан аргументом), а НЕ к Motor.LastInterpolatedPosition
        // (та заморожена у remote — та же причина «боксы на спавне»). Из Motor
        // берём только СКАЛЯР высоты капсулы. Так голова едет вместе с игроком.
        uint64_t m = rpm<uint64_t>(kcc + ox::KCC_MOTOR);
        float ch = 1.80f;
        if (ox_isPtr(m)) {
            float mch = rpm<float>(m + ox::MOTOR_CAPSULE_HEIGHT);
            if (isfinite(mch) && mch > 0.3f && mch < 3.5f) ch = mch;
        }
        float lo = rpm<float>(kcc + ox::KCC_LOOK_HEIGHT_OFF);
        if (!isfinite(lo) || lo < -1.f || lo > 1.f) lo = 0.f;
        headW = Vector3(feet.x, feet.y + ch + lo, feet.z);
        haveHead = true;
    }

    if (!haveHead) return false;   // без головы скелет не строим

    // Валидация: голова должна быть в разумном радиусе от ног. Иначе это
    // указатель от прошлого владельца памяти.
    float dy = headW.y - feet.y;
    float dxz = sqrtf((headW.x-feet.x)*(headW.x-feet.x) + (headW.z-feet.z)*(headW.z-feet.z));
    if (!isfinite(dy) || dy < 0.4f || dy > 2.6f || dxz > 1.5f) return false;

    // ── Достраиваем скелет ──────────────────────────────────────────────────
    Vector3 pelvis = haveBody ? bodyW : Vector3(feet.x, feet.y + dy * 0.52f, feet.z);
    // Если body оказался не тазом, а центром — подстрахуемся диапазоном.
    if (pelvis.y - feet.y > dy * 0.75f || pelvis.y - feet.y < dy * 0.30f)
        pelvis = Vector3(feet.x, feet.y + dy * 0.52f, feet.z);

    Vector3 chest = Vector3(headW.x + (pelvis.x - headW.x) * 0.34f,
                            headW.y + (pelvis.y - headW.y) * 0.34f,
                            headW.z + (pelvis.z - headW.z) * 0.34f);
    Vector3 neck  = Vector3(headW.x + (chest.x - headW.x) * 0.42f,
                            headW.y + (chest.y - headW.y) * 0.42f,
                            headW.z + (chest.z - headW.z) * 0.42f);

    // Ширина плеч/таза от роста — модель у всех одна, пропорции стабильны.
    float shoulderHalf = dy * 0.115f;
    float hipHalf      = dy * 0.075f;
    // Боковое направление берём из вектора между кистями, если обе есть;
    // иначе — из мировой оси X (боксы всё равно билборд-ориентированы).
    Vector3 side(1.f, 0.f, 0.f);
    if (haveRH && haveLH) {
        Vector3 d(rhW.x - lhW.x, 0.f, rhW.z - lhW.z);
        float len = sqrtf(d.x*d.x + d.z*d.z);
        if (len > 0.05f) side = Vector3(d.x/len, 0.f, d.z/len);
    }

    out.headPos      = headW;
    out.neckPos      = neck;
    out.spine1Pos    = chest;
    out.spine2Pos    = pelvis;
    out.rshoulderPos = Vector3(chest.x + side.x*shoulderHalf, chest.y, chest.z + side.z*shoulderHalf);
    out.lshoulderPos = Vector3(chest.x - side.x*shoulderHalf, chest.y, chest.z - side.z*shoulderHalf);
    out.rlowarmPos   = haveRH ? rhW : Vector3(out.rshoulderPos.x + side.x*dy*0.06f,
                                              pelvis.y + dy*0.06f,
                                              out.rshoulderPos.z + side.z*dy*0.06f);
    out.llowarmPos   = haveLH ? lhW : Vector3(out.lshoulderPos.x - side.x*dy*0.06f,
                                              pelvis.y + dy*0.06f,
                                              out.lshoulderPos.z - side.z*dy*0.06f);
    out.ruparmPos    = Vector3((out.rshoulderPos.x + out.rlowarmPos.x)*0.5f,
                               (out.rshoulderPos.y + out.rlowarmPos.y)*0.5f,
                               (out.rshoulderPos.z + out.rlowarmPos.z)*0.5f);
    out.luparmPos    = Vector3((out.lshoulderPos.x + out.llowarmPos.x)*0.5f,
                               (out.lshoulderPos.y + out.llowarmPos.y)*0.5f,
                               (out.lshoulderPos.z + out.llowarmPos.z)*0.5f);
    out.rhipPos      = Vector3(pelvis.x + side.x*hipHalf, pelvis.y, pelvis.z + side.z*hipHalf);
    out.lhipPos      = Vector3(pelvis.x - side.x*hipHalf, pelvis.y, pelvis.z - side.z*hipHalf);
    out.rfootPos     = Vector3(out.rhipPos.x, feet.y, out.rhipPos.z);
    out.lfootPos     = Vector3(out.lhipPos.x, feet.y, out.lhipPos.z);
    out.rkneePos     = Vector3((out.rhipPos.x + out.rfootPos.x)*0.5f,
                               (out.rhipPos.y + out.rfootPos.y)*0.5f,
                               (out.rhipPos.z + out.rfootPos.z)*0.5f);
    out.lkneePos     = Vector3((out.lhipPos.x + out.lfootPos.x)*0.5f,
                               (out.lhipPos.y + out.lfootPos.y)*0.5f,
                               (out.lhipPos.z + out.lfootPos.z)*0.5f);

    out.hasSkeletonData = true;
    return true;
}

// Мировая позиция игрока: player+0x68 (worldCameraRoot) -> matrixData+0x90.
static Vector3 ox_readPos(uint64_t player, bool full) {
    // UPDATE 2026/07/31 v15: ОТКАТ к рабочему v9 варианту. В v13/v14 я переставил
    // приоритет на Motor.LastInterpolatedPosition и characterModel.transform,
    // предположив что lastTickPosition стоит на месте. **Ошибка** — в v9 боксы
    // двигались именно потому что lastTickPosition обновляется. Motor/characterModel
    // как раз стоят на месте для remote-игроков (у них клиентская физика/GO не
    // тикает). Возвращаемся к порядку v9: lastTickPosition → savedPos → transform.
    //
    // Раньше читали worldCameraRoot (@0x68) — у remote игроков он NULL, отсюда
    // ESP крепился к нашей камере вместо тел противников.
    Vector3 tickPos = rpm<Vector3>(player + ox::PM_LAST_TICK_POS);
    if (full) OXLOGT("  lastTickPos = (%.2f, %.2f, %.2f)", tickPos.x, tickPos.y, tickPos.z);
    if (tickPos.x != 0.f || tickPos.y != 0.f || tickPos.z != 0.f) return tickPos;

    // Fallback #1: lastSavedPosition (иногда актуальнее чем lastTickPos на первых кадрах)
    Vector3 savedPos = rpm<Vector3>(player + ox::PM_LAST_SAVED_POS);
    if (savedPos.x != 0.f || savedPos.y != 0.f || savedPos.z != 0.f) {
        if (full) OXLOGT("  lastSavedPos fallback = (%.2f, %.2f, %.2f)", savedPos.x, savedPos.y, savedPos.z);
        return savedPos;
    }

    // Fallback #2: worldCameraRoot (работает только для локального игрока)
    Vector3 wPos(0, 0, 0);
    uint64_t transform = rpm<uint64_t>(player + ox::PM_TRANSFORM);
    if (full) oxlog::ptrstep("player + TRANSFORM(0x68)", player + ox::PM_TRANSFORM, transform);
    ox_transformWorld(transform, &wPos, nullptr, full, "  transform + m_CachedPtr(0x10)");
    if (full) OXLOGT("  worldCamRoot fallback = (%.2f, %.2f, %.2f)", wPos.x, wPos.y, wPos.z);
    return wPos;
}

static inline void ox_normalize3(Vector3 &v) {
    float n = sqrtf(v.x*v.x + v.y*v.y + v.z*v.z);
    if (n > 1e-6f) { v.x/=n; v.y/=n; v.z/=n; }
}

// ============================================================================
//  FIX bug #1/#2/#3 — базис камеры ИЗ УГЛОВ (kqP.x pitch, kqP.y yaw).
//  ---------------------------------------------------------------------------
//  Раньше базис брался из МИРОВОГО кватерниона m_LookRoot через нативный
//  Transform (matrixData+0xA0). Это ЛОМАЛОСЬ дважды:
//    (a) matrixData читался по internal+0x28; в Unity Transform_internal 0x28 =
//        `self` (back-ptr), а mData@0x38 -> читался мусор;
//    (b) даже с верным 0x38 world-кватернион лежит в libunity (icall
//        get_rotation_Injected) — оффсет непроверяем и версионно-хрупок.
//  Симптомы: ESP уезжал по вертикали при наклоне камеры, «плавал» по экрану,
//  а LOS-луч (для аима-через-стены) стартовал из неверной точки/направления.
//
//  Теперь используем ПРОВЕРЕННЫЕ managed-поля MouseLook.kqP:
//    pitch° = kqP.x @0x60   (disasm uae: m_LookRoot.localRotation=Euler(kqP.x,0,roll))
//    yaw°   = kqP.y @0x64   (аккумулятор yaw; конвенция == aimbot write)
//  Прямая тригонометрия (Unity left-handed, y-up), сверена численно с обратной
//  математикой аимбота до 1e-16:
//    right   = ( cosYaw,            0,        -sinYaw )
//    up      = ( sinYaw*sinPitch,   cosPitch,  cosYaw*sinPitch )
//    forward = ( sinYaw*cosPitch,  -sinPitch,  cosYaw*cosPitch )
//  Никаких нативных Transform-чтений — только два float'а. Инверты — на вызове.
//  eyePos НЕ выставляем здесь (позиция глаза считается отдельно из feet+eye).
// ============================================================================
static bool ox_readLookBasis(uint64_t player, Vector3 &right, Vector3 &up,
                             Vector3 &fwd, Vector3 *eyePos, bool full) {
    (void)eyePos;
    uint64_t mouseLook = rpm<uint64_t>(player + ox::PM_MOUSELOOK);
    if (!ox_isPtr(mouseLook)) return false;
    float pitchDeg = rpm<float>(mouseLook + ox::ML_PITCH); // kqP.x
    float yawDeg   = rpm<float>(mouseLook + ox::ML_YAW);   // kqP.y
    if (!isfinite(pitchDeg) || !isfinite(yawDeg)) return false;
    // Санитарная проверка pitch (игра клампит его к look-лимитам, |pitch|<=~89).
    if (fabsf(pitchDeg) > 179.f) return false;

    float p = pitchDeg * DEG2RAD;
    float y = yawDeg   * DEG2RAD;
    float sp = sinf(p), cp = cosf(p);
    float sy = sinf(y), cy = cosf(y);

    right   = Vector3(cy,        0.f, -sy);
    up      = Vector3(sy*sp,     cp,   cy*sp);
    fwd     = Vector3(sy*cp,    -sp,   cy*cp);
    ox_normalize3(right); ox_normalize3(up); ox_normalize3(fwd);
    if (full) OXLOGT("  lookBasis(angles) pitch=%.2f yaw=%.2f fwd=(%.3f,%.3f,%.3f)",
                     pitchDeg, yawDeg, fwd.x, fwd.y, fwd.z);
    return true;
}

// Живой ВЕРТИКАЛЬНЫЙ FOV камеры + ADS-детект из FPManager (PM+0x90).
//   effFOV = kYl(0xA0) - kSP(0xB4) ; base = _kSQ(0xAC).
//   aiming = effFOV < base*ADS_FOV_RATIO (при прицеле FOV зумится вниз).
// Возвращает верт. FOV (>0) или 0, если FPManager недоступен/значения мусор.
// aimingOut (может быть nullptr) — true если игрок целится.
static float ox_readCameraFovV(uint64_t player, bool *aimingOut, bool full) {
    if (aimingOut) *aimingOut = false;
    uint64_t fp = rpm<uint64_t>(player + ox::PM_FPMANAGER);
    if (!ox_isPtr(fp)) return 0.f;
    float cur  = rpm<float>(fp + ox::FP_FOV_CURRENT); // kYl
    float off  = rpm<float>(fp + ox::FP_FOV_OFFSET);  // kSP
    float base = rpm<float>(fp + ox::FP_FOV_BASE);    // _kSQ
    if (!isfinite(cur) || !isfinite(off) || !isfinite(base)) return 0.f;
    float eff = cur - off;
    if (eff < ox::EYE_FOV_MIN || eff > ox::EYE_FOV_MAX) return 0.f;
    if (aimingOut) {
        // ADS = текущий FOV ощутимо ниже БАЗОВОГО (зум прицела). База — это
        // хипфайр-FOV игрока (_kSQ), сравниваем ОТНОСИТЕЛЬНО его, чтобы работало
        // и при низком пользовательском FOV. Если _kSQ протух (мусор) — дефолт 60.
        float ref = (isfinite(base) && base > ox::EYE_FOV_MIN && base < ox::EYE_FOV_MAX)
                        ? base : ox::DEFAULT_VFOV;
        *aimingOut = (cur < ref * ox::ADS_FOV_RATIO);
    }
    if (full) OXLOGT("  FOV: kYl=%.2f kSP=%.2f base=%.2f -> effV=%.2f aiming=%d",
                     cur, off, base, eff, aimingOut ? (int)*aimingOut : -1);
    // Периодический лог (раз в ~2 сек) — без него нельзя понять почему
    // ADS-детект не срабатывает: нужны живые значения kYl/_kSQ с устройства.
    {
        static double s_lastFovLog = 0.0;
        double now = (double)time(nullptr);
        if (now - s_lastFovLog >= 2.0) {
            s_lastFovLog = now;
            OXLOGI("[ads] kYl=%.2f kSP=%.2f base=%.2f eff=%.2f ratio=%.3f aiming=%d",
                   cur, off, base, eff,
                   (base > 1.f ? cur / base : -1.f),
                   aimingOut ? (int)*aimingOut : -1);
        }
    }
    return eff;
}

// Строит камеру из КОНКРЕТНОГО (локального) игрока.
//   pos    = feet(lastTickPosition) + EYE_HEIGHT  (managed-поле, проверяемо)
//   basis  = из углов kqP.x(pitch)/kqP.y(yaw)     (проверяемо, без libunity)
//   fovV   = живой верт. FOV из FPManager          (kYl - kSP), меняется при ADS
// Дёшево (несколько managed-чтений) — можно звать каждый кадр.
static CameraView ox_buildCameraFromPlayer(uint64_t player, bool full) {
    CameraView cam;
    cam.valid = false;
    cam.fovH  = camFov;   // legacy горизонтальный fallback
    if (!ox_isPtr(player)) return cam;

    Vector3 body = ox_readPos(player, full);

    Vector3 right{1,0,0}, up{0,1,0}, fwd{0,0,1};
    bool haveDir = ox_readLookBasis(player, right, up, fwd, nullptr, full);

    // FIX ESP drift on spawn/respawn: перед тем как строить cam.pos из lastTickPos,
    // предпочитаем LIVE позицию из worldCameraRoot Transform, если она доступна.
    // lastTickPosition обновляется на server tick (~20 Hz) и после respawn
    // задерживается или показывает (0,0,0) — до этого ESP уезжает "с камерой".
    // worldCameraRoot — нативный Transform игрока, обновляется каждый кадр игрой.
    uint64_t camRoot = rpm<uint64_t>(player + ox::PM_TRANSFORM);
    Vector3 camRootPos{0,0,0};
    bool haveCamRoot = ox_isPtr(camRoot) &&
                       ox_transformWorld(camRoot, &camRootPos, nullptr, false, nullptr) &&
                       (camRootPos.x != 0.f || camRootPos.y != 0.f || camRootPos.z != 0.f);
    // Санити: worldCameraRoot обязан быть над своим же телом. После смерти
    // Transform остаётся на месте гибели, а lastTickPosition уезжает на точку
    // респавна — расхождение в метрах. Такой Transform брать нельзя, иначе
    // камера окажется в старой точке и вся сцена «поедет» относительно неё.
    if (haveCamRoot) {
        float dx = camRootPos.x - body.x, dz = camRootPos.z - body.z;
        float dxz = sqrtf(dx*dx + dz*dz);
        float dy  = camRootPos.y - body.y;
        if (!isfinite(dxz) || dxz > 2.0f || dy < -0.5f || dy > 3.0f) {
            if (full) OXLOGW("[camera] worldCameraRoot разошёлся с телом "
                             "(dxz=%.2f dy=%.2f) — беру feet+eye", dxz, dy);
            haveCamRoot = false;
        }
    }

    if (haveCamRoot) {
        cam.pos = camRootPos;                       // real head position (fresh)
    } else {
        cam.pos = body + Vector3(0.f, ox::EYE_HEIGHT, 0.f);   // fallback: feet + eye_height
    }
    // Basis validity: kqP.x/y == 0 exactly = MouseLook ещё не проинициализирован
    // (респавн, первый кадр после смерти). Пока не валидировано — cam.valid=false
    // чтобы render-loop не рисовал ESP с identity-basis'ом (ESP липнет к камере).
    if (haveDir) {
        float fwdSum = fabsf(fwd.x) + fabsf(fwd.y) + fabsf(fwd.z);
        if (fwdSum < 0.01f || (fabsf(fwd.x) < 1e-4f && fabsf(fwd.z) < 1e-4f && fabsf(fwd.y - 1.f) < 1e-4f)) {
            // basis == identity forward (0,0,1) или zero — kqP не готов
            haveDir = false;
            if (full) OXLOGW("[camera] kqP не инициализирован (basis identity/zero) — ESP отключён до синка");
        }
    }

    // Живой FOV + ADS-состояние (для W2S-масштаба и aimbot ADS-only).
    bool aiming = false;
    float fovV = ox_readCameraFovV(player, &aiming, full);
    cam.fovV   = fovV;      // 0 => W2S упадёт на горизонтальный слайдер
    cam.aiming = aiming;

    if (haveDir) {
        // Инверты — чистые флипы осей проекции (управляются галками в меню).
        if (camInvertYaw)   right = Vector3(-right.x, -right.y, -right.z);
        if (camInvertPitch) up    = Vector3(-up.x,    -up.y,    -up.z);
        cam.hasBasis = true;
        cam.right = right; cam.up = up; cam.forward = fwd;
    }

    // yaw/pitch как fallback (если базис не собрался).
    float distXZ = sqrtf(fwd.x*fwd.x + fwd.z*fwd.z);
    float yaw    = atan2f(fwd.x, fwd.z) * 57.2957795f;
    float pitch  = atan2f(fwd.y, distXZ) * 57.2957795f;
    if (camInvertPitch) pitch = -pitch;
    if (camInvertYaw)   yaw   = -yaw;
    cam.pitch = pitch;
    cam.yaw   = yaw;
    // КРИТИЧНО: без валидного базиса камеру нельзя объявлять годной. Раньше
    // здесь стояло безусловное cam.valid = true, и при мёртвом/несинхронном
    // MouseLook рендер получал identity-forward (0,0,1) — все проекции
    // считались от неподвижной оси, из-за чего боксы «прилипали» к экрану
    // и ездили вместе с камерой. Теперь такой кадр просто пропускается.
    cam.valid = haveDir;
    if (!haveDir && full)
        OXLOGW("[camera] базис не собран — кадр пропущен (ESP не рисуется)");

    if (full) {
        OXLOGI("ЛОКАЛЬНЫЙ игрок=0x%llx", (unsigned long long)player);
        OXLOGI("  feet=(%.2f,%.2f,%.2f) eye=+%.2f -> cam.pos=(%.3f,%.3f,%.3f)",
               body.x, body.y, body.z, ox::EYE_HEIGHT, cam.pos.x, cam.pos.y, cam.pos.z);
        OXLOGI("  forward=(%.3f,%.3f,%.3f) haveBasis=%d fovV=%.2f aiming=%d",
               fwd.x, fwd.y, fwd.z, (int)haveDir, cam.fovV, (int)cam.aiming);
    }
    return cam;
}

// Проверка: остаётся ли кэшированный g_localPlayer валидным (не респавн).
// После смерти + респавна игра часто выделяет НОВЫЙ PlayerManager для локального
// игрока, а старый освобождается. Кэшированный g_localPlayer тогда указывает
// в garbage → камера строится с мусором → ESP плывёт.
// Валидация: у живого локального PM должны быть mouseLook + raycastManager
// non-null (только у него их выставляют).
// ФИКС респавна (2026/07/25): прошлая проверка требовала лишь чтобы
// mouseLook/raycastManager ВЫГЛЯДЕЛИ как указатели. После смерти игра
// освобождает PlayerManager, но освобождённая память ещё какое-то время
// хранит старые байты — проверка проходила, и камера продолжала строиться
// из мёртвого объекта. Отсюда «ESP липнет к моей камере»: kqP у мёртвого
// MouseLook больше не обновляется, базис застывает, проекции едут вместе
// с экраном. Через минуту GC перетирал память, указатели становились
// мусором, проверка наконец падала — ESP «сам чинился».
//
// Теперь живость проверяется по независимым признакам:
//   1) mouseLook / raycastManager — валидные указатели
//   2) mouseLook->m_LookRoot — живой Transform (у трупа нулится/мусор)
//   3) kqP.x / kqP.y — конечные углы в разумном диапазоне
// Плюс в ox_getCamera: присутствие PM в activePlayerList (игра убирает
// труп из списка сразу при смерти — самый надёжный сигнал).
static bool ox_localPlayerAlive(uint64_t pm) {
    if (!ox_isPtr(pm)) return false;
    uint64_t mouseLook = rpm<uint64_t>(pm + ox::PM_MOUSELOOK);
    uint64_t raycast   = rpm<uint64_t>(pm + ox::PM_RAYCASTMANAGER);
    if (!ox_isPtr(mouseLook) || !ox_isPtr(raycast)) return false;
    uint64_t lookRoot = rpm<uint64_t>(mouseLook + ox::ML_LOOKROOT);
    if (!ox_isPtr(lookRoot)) return false;
    float pitch = rpm<float>(mouseLook + ox::ML_PITCH);
    float yaw   = rpm<float>(mouseLook + ox::ML_YAW);
    if (!isfinite(pitch) || !isfinite(yaw)) return false;
    if (fabsf(pitch) > 179.f || fabsf(yaw) > 100000.f) return false;
    return true;
}

static bool ox_localPlayerStillValid() { return ox_localPlayerAlive(g_localPlayer); }

// ── Детект «замороженной» камеры ────────────────────────────────────────────
// Симптом с устройства: после респавна ESP держится верно ПОКА не двигаешь
// камеру, а при повороте боксы остаются на прежнем месте экрана. То есть
// позиции целей читаются нормально, а базис камеры застыл — kqP выбранного
// MouseLook больше не обновляется (объект мёртвый, игра пишет углы в НОВЫЙ).
// Статически такой труп неотличим: указатели валидны, углы конечны.
//
// Единственный надёжный признак — ДИНАМИКА. Живой MouseLook меняет kqP
// постоянно (даже стоя: микро-дрейф, отдача, дыхание). Мёртвый застывает
// намертво. Считаем сколько секунд углы не менялись; если дольше порога —
// объявляем PM мёртвым и форсируем пере-выбор.
// БАГ ПРОШЛОЙ ВЕРСИИ: наблюдение велось в ОДНОЙ глобальной ячейке, а
// ox_lookFrozen вызывается по очереди для НЕСКОЛЬКИХ кандидатов. Каждый вызов
// с другим pm сбрасывал ячейку и возвращал false («только начали наблюдать»).
// Порог 2.5 с не достигался НИКОГДА — детект был мёртвым кодом, поэтому баг
// после респавна остался. Теперь слот на каждого кандидата.
struct OxLookSlot {
    uint64_t pm    = 0;
    float    pitch = 0.f, yaw = 0.f;
    double   lastChange = 0.0;
    bool     seeded = false;
};
static OxLookSlot g_lookSlots[8];

static OxLookSlot* ox_lookSlotFor(uint64_t pm, double nowSec) {
    OxLookSlot* free_ = nullptr;
    OxLookSlot* oldest = &g_lookSlots[0];
    for (auto &sl : g_lookSlots) {
        if (sl.pm == pm) return &sl;
        if (!sl.seeded && !free_) free_ = &sl;
        if (sl.lastChange < oldest->lastChange) oldest = &sl;
    }
    OxLookSlot* pick = free_ ? free_ : oldest;
    *pick = OxLookSlot{};
    pick->pm = pm;
    pick->lastChange = nowSec;
    return pick;
}

// Возвращает true если углы этого PM «мертвы» (не менялись дольше stallSec).
static bool ox_lookFrozen(uint64_t pm, double nowSec, float stallSec = 1.2f) {
    if (!ox_isPtr(pm)) return true;
    uint64_t ml = rpm<uint64_t>(pm + ox::PM_MOUSELOOK);
    if (!ox_isPtr(ml)) return true;
    float p = rpm<float>(ml + ox::ML_PITCH);
    float y = rpm<float>(ml + ox::ML_YAW);
    if (!isfinite(p) || !isfinite(y)) return true;

    OxLookSlot* sl = ox_lookSlotFor(pm, nowSec);
    if (!sl->seeded) {
        sl->pitch = p; sl->yaw = y; sl->lastChange = nowSec; sl->seeded = true;
        return false;                      // только начали наблюдать
    }
    if (fabsf(p - sl->pitch) > 1e-4f || fabsf(y - sl->yaw) > 1e-4f) {
        sl->pitch = p; sl->yaw = y; sl->lastChange = nowSec;
        return false;
    }
    return (nowSec - sl->lastChange) > (double)stallSec;
}

// Сбросить наблюдение (при смене локального игрока).
static void ox_lookWatchReset() {
    for (auto &sl : g_lookSlots) sl = OxLookSlot{};
}

// Находит локального игрока в списке, запоминает g_localPlayer и строит камеру.
static CameraView ox_getCamera(uint64_t elems, int count, bool full) {
    if (full) oxlog::section("CAMERA (local player)");

    const double nowSec = (double)ImGui::GetTime();

    // Кандидаты: все PM с валидной связкой камеры. Их может быть НЕСКОЛЬКО —
    // после респавна старый труп какое-то время лежит в списке рядом с новым.
    // Сначала ищем владельца по флагу ПО ВСЕМУ списку, а не по первым восьми:
    // потолок массива отсекал часть игроков, и если наш PM оказывался девятым,
    // его просто не рассматривали.
    uint64_t cands[16]; int nc = 0;
    uint64_t flagged = 0;
    for (int i = 0; i < count; i++) {
        uint64_t p = rpm<uint64_t>(elems + i * 8);
        if (!ox_isPtr(p)) continue;
        if (!flagged) {
            uint64_t ni = rpm<uint64_t>(p + ox::NB_NET_IDENTITY);
            if (ox_isPtr(ni) && rpm<uint8_t>(ni + ox::NI_IS_LOCAL_PLAYER) != 0)
                flagged = p;
        }
        if (nc < 16 && ox_localPlayerAlive(p)) cands[nc++] = p;
    }
    // Флаг найден — он и есть ответ, остальные кандидаты не нужны.
    if (flagged) { cands[0] = flagged; nc = 1; }

    bool inList = false;
    for (int i = 0; i < nc; i++) if (cands[i] == g_localPlayer) { inList = true; break; }

    // Заморожен ли базис текущего выбора? Это ловит именно тот случай, когда
    // указатели валидны, позиции читаются, но углы застыли — ESP «идёт за
    // камерой». Если рядом есть ДРУГОЙ кандидат — переключаемся на него.
    // ВАЖНО: ox_localPlayerAlive пропускает ЛЮБОГО игрока с валидной связкой
    // MouseLook+RaycastManager, то есть почти всех в списке — nc упирается в
    // потолок массива (8). Поэтому условие «frozen && nc > 1» срабатывало
    // ВСЕГДА, стоило игроку на пару секунд замереть: локальный PM выбрасывался,
    // выбирался заново, снова замирал — карусель на весь матч (в логе 97
    // сбросов подряд). А каждый сброс обнулял кэш матрицы камеры, из-за чего
    // поиск не доживал до использования (viewOff=-1 весь лог).
    //
    // Замороженные углы — слишком слабый признак: живой игрок, не трогающий
    // экран, неотличим от трупа. Геометрический тест ниже (камера должна быть
    // над ногами своего владельца) решает ту же задачу мгновенно и без ложных
    // срабатываний, поэтому frozen здесь больше НЕ основание для сброса.
    bool frozen = g_localPlayer && inList && ox_lookFrozen(g_localPlayer, nowSec);
    if (g_localPlayer && (!inList || !ox_localPlayerAlive(g_localPlayer))) {
        OXLOGI("[respawn] PM=0x%llx отброшен (inList=%d alive=%d frozen=%d cands=%d)",
               (unsigned long long)g_localPlayer, (int)inList,
               (int)ox_localPlayerAlive(g_localPlayer), (int)frozen, nc);
        g_localPlayer = 0;
        g_localTeamName.clear();
        ox_lookWatchReset();
    }

    // ── ГЛАВНЫЙ КРИТЕРИЙ: Mirror.NetworkIdentity.isLocalPlayer ─────────────
    // Mirror выставляет этот флаг РОВНО ОДНОМУ объекту за матч — тому, которым
    // управляет данный клиент. Это прямой ответ на вопрос «кто я», а не
    // догадка по косвенным признакам.
    //
    // Все прежние критерии были эвристиками и промахивались:
    //   * наличие MouseLook+RaycastManager — есть у КАЖДОГО игрока
    //   * замороженные углы — живой игрок, не трогающий экран, неотличим от трупа
    //   * Transform над ногами — верно для всех живых, не только для нас
    // Если выбирался чужой PM, базис камеры строился из ЧУЖИХ углов: свою
    // камеру поворачиваешь, а боксы считаются от чужой — ESP «плавает».
    {
        int owner = -1;
        for (int ci = 0; ci < nc; ci++) {
            uint64_t ni = rpm<uint64_t>(cands[ci] + ox::NB_NET_IDENTITY);
            if (!ox_isPtr(ni)) continue;
            if (rpm<uint8_t>(ni + ox::NI_IS_LOCAL_PLAYER) != 0) { owner = ci; break; }
        }
        if (owner >= 0) {
            if (cands[owner] != g_localPlayer)
                OXLOGI("[local] найден по NetworkIdentity.isLocalPlayer: PM=0x%llx (был 0x%llx)",
                       (unsigned long long)cands[owner],
                       (unsigned long long)g_localPlayer);
            cands[0] = cands[owner]; nc = 1;
        } else {
            static double s_lastNoOwner = 0.0;
            double nw2 = (double)ImGui::GetTime();
            if (nw2 - s_lastNoOwner > 5.0) {
                s_lastNoOwner = nw2;
                OXLOGW("[local] isLocalPlayer не найден ни у одного из %d кандидатов "
                       "— падаю на геометрический тест", nc);
            }
        }
    }

    // ── Запасной выбор: геометрия (когда флаг не прочитался) ───────────────
    // Детект по «замороженным углам» ненадёжен: труп может простоять неподвижно
    // ровно столько же, сколько живой игрок, который не трогает экран. Поэтому
    // основной критерий другой и мгновенный: у ЖИВОГО локального игрока
    // worldCameraRoot (нативный Transform, обновляется движком каждый кадр)
    // совпадает по горизонтали с его же lastTickPosition. У трупа Transform
    // остаётся там, где игрок умер, а lastTickPosition уже уехал на точку
    // респавна — они расходятся на метры. Это и есть тот самый симптом
    // «ESP привязан к камере»: мы строили камеру из мёртвого Transform.
    if (nc > 1) {
        int best = -1; float bestD = 1e9f;
        for (int ci = 0; ci < nc; ci++) {
            uint64_t p = cands[ci];
            uint64_t camRoot = rpm<uint64_t>(p + ox::PM_TRANSFORM);
            Vector3 cr{0,0,0};
            if (!ox_isPtr(camRoot) ||
                !ox_transformWorld(camRoot, &cr, nullptr, false, nullptr)) continue;
            Vector3 feet = rpm<Vector3>(p + ox::PM_LAST_TICK_POS);
            if (!isfinite(feet.x) || !isfinite(cr.x)) continue;
            float dx = cr.x - feet.x, dz = cr.z - feet.z;
            float d = sqrtf(dx*dx + dz*dz);          // расхождение по горизонтали
            if (d < bestD) { bestD = d; best = ci; }
        }
        if (best >= 0 && bestD < 2.0f) {
            if (cands[best] != g_localPlayer)
                OXLOGI("[local] выбран по совпадению Transform<->tickPos "
                       "(расхождение %.2f м, кандидатов %d)", bestD, nc);
            uint64_t pick = cands[best];
            cands[0] = pick; nc = 1;                 // остальных отбрасываем
        }
    }

    for (int ci = 0; ci < nc; ci++) {
        uint64_t player = cands[ci];
        if (full)
            OXLOGT("cand[%d]=0x%llx (из %d)", ci, (unsigned long long)player, nc);
        if (g_localPlayer != player) {
            OXLOGI("[local] выбран локальный игрок PM=0x%llx (был 0x%llx, кандидатов %d)",
                   (unsigned long long)player, (unsigned long long)g_localPlayer, nc);
            g_localPlayer = player;
            ox_lookWatchReset();
        }
        // Team-ключ обновляем КАЖДЫЙ раз, а не только при смене локального PM.
        // Команда собирается уже в матче: на момент первого выбора игрока
        // PM.team ещё null, и старый код кэшировал пустую строку навсегда —
        // отсюда «скрыть тимейтов не работает».
        {
            std::string tk = ox_teamKey(player);
            if (tk != g_localTeamName) {
                OXLOGI("[local] teamKey: '%s' -> '%s'", g_localTeamName.c_str(), tk.c_str());
                g_localTeamName = tk;
                cache_needs_update = true;   // пере-оценить состав кэша
            }
        }
        return ox_buildCameraFromPlayer(player, full);
    }
    if (full) OXLOGW("Локальный игрок не найден (нет живого PM с mouseLook в списке)");
    CameraView cam; cam.valid = false; cam.fovH = camFov;
    return cam;
}

static float ox_normalizeAngle(float angle) {
    while (angle > 180.0f) angle -= 360.0f;
    while (angle < -180.0f) angle += 360.0f;
    return angle;
}

// ============================================================================
//  LOS-чек через BuildingPiece.saveList
// ============================================================================
//  Резолвим BuildingPiece_TypeInfo (обновлённый RVA 0xB8B97E0) -> static_fields ->
//  saveList (List<BuildingPiece>) -> перебираемm_Bounds (локальные) + m_CorrectPosition
//  (мировые) -> world AABB -> классический slab-method ray-AABB.
//
//  Кэш: раз в N кадров (BUILDING_CACHE_INTERVAL) перечитываем список построек,
//  между кадрами — переиспользуем. Это убирает ~2000*8 байт/кадр лишних чтений.
//  Альтернативно — для получения ВСЕХ твёрдых объектов стоило бы звать
//  Physics.Raycast, но это требует внедрения метода в процесс — вне рамок
//  внешнего чита. Building-LOS покрывает ~90% случаев (стены/фундаменты/потолки).
//
//  Структура Bounds (UnityEngine, TypeDefIndex 13482):
//    0x00  Vector3 m_Center
//    0x0C  Vector3 m_Extents
//  min = center - extents, max = center + extents
// ============================================================================

struct WorldAABB {
    Vector3 min;
    Vector3 max;
};

struct BuildingCacheEntry {
    uint64_t address;       // адрес BuildingPiece (для лога)
    WorldAABB bounds;       // World-space AABB
    bool      valid;
};

static std::vector<BuildingCacheEntry> g_buildingCache;
static std::mutex g_buildingMutex;
static int g_buildingCacheFrame = -1000;
static constexpr int BUILDING_CACHE_INTERVAL = 30; // перечитываем раз в 30 кадров (~0.5с)

// Резолв static_fields для класса по его TypeInfo RVA. Возвращает 0 при ошибке.
// Читает static_fields класса. Приоритет — кэширован��ый указатель Il2CppClass
// (надёжно на metadata v39). Если его нет, откат на TypeInfo RVA (нестабилен).
static uint64_t ox_getClassStatics(uint64_t typeInfoRVA, uint64_t cachedKlass, bool tryLog) {
    if (!il2cpp_base) { if (tryLog) OXLOGE("il2cpp_base == 0 (getClassStatics)"); return 0; }
    uint64_t klass = ox_isPtr(cachedKlass) ? cachedKlass : 0;
    if (!ox_isPtr(klass)) {
        uint64_t typeInfoAddr = il2cpp_base + typeInfoRVA;
        klass = rpm<uint64_t>(typeInfoAddr);
        if (tryLog) OXLOGD("getClassStatics: klass из RVA 0x%llx -> 0x%llx",
                           (unsigned long long)typeInfoRVA, (unsigned long long)klass);
    }
    if (!ox_isPtr(klass)) { if (tryLog) OXLOGE("klass невалиден (RVA=0x%llx, cached=0x%llx)", (unsigned long long)typeInfoRVA, (unsigned long long)cachedKlass); return 0; }
    uint64_t statics = rpm<uint64_t>(klass + ox::CLASS_STATIC_FIELDS);
    if (!ox_isPtr(statics)) { if (tryLog) OXLOGE("static_fields невалиден"); return 0; }
    return statics;
}

// Развёртка List<T> -> {elements_ptr, count}. Аналог ox_evalContainer, без проверки
// однородности (для BuildingPiece.saveList не нужно — оно типизировано).
static bool ox_readList(uint64_t listObj, uint64_t &elems, int &count) {
    elems = 0; count = 0;
    if (!ox_isPtr(listObj)) return false;
    uint64_t items = rpm<uint64_t>(listObj + ox::LIST_ITEMS);
    if (!ox_isPtr(items)) return false;
    int listSize = rpm<int>(listObj + ox::LIST_SIZE);
    uint64_t arrLen = rpm<uint64_t>(items + ox::ARRAY_COUNT);
    if (listSize > 0 && listSize <= ox::LOS_SAVELIST_MAX) count = listSize;
    else if (arrLen > 0 && arrLen <= (uint64_t)ox::LOS_SAVELIST_MAX) count = (int)arrLen;
    else return false;
    elems = items + ox::ARRAY_DATA;
    return count > 0;
}

// ============================================================================
//  FIX bug #1: BuildingPiece.saveList — это HashSet<T>, а НЕ List<T>.
//  Старый ox_readList на HashSet возвращал мусор -> кэш построек всегда пуст ->
//  aimCheckWalls/espColorByVisibility НИКОГДА не срабатывали. Ниже — корректный
//  обход Mono HashSet<T> и Dictionary<K,V> (fallback).
// ============================================================================

// Обходит Mono HashSet<T> (T — ссылочный тип), вызывая cb(value) для каждого
// живого элемента. Читает Slot[] одним bulk-vm_readv (быстро, без пер-элемент чтений).
//   set+0x18 -> Slot[] _slots ; set+0x24 -> _lastIndex
//   Slot { int hashCode; int next; T value } stride 0x10, занятый: hashCode>=0.
// Возвращает число обойдённых живых элементов, -1 при невалидном наборе.
template<typename CB>
static int ox_forEachHashSet(uint64_t setObj, CB&& cb) {
    if (!ox_isPtr(setObj)) return -1;
    uint64_t slots = rpm<uint64_t>(setObj + ox::HASHSET_SLOTS);
    if (!ox_isPtr(slots)) return -1;
    int lastIndex = rpm<int>(setObj + ox::HASHSET_LASTINDEX);
    int count     = rpm<int>(setObj + ox::HASHSET_COUNT);
    if (lastIndex <= 0 || lastIndex > ox::LOS_SAVELIST_MAX) {
        // _lastIndex мусор — попробуем _count как границу.
        if (count <= 0 || count > ox::LOS_SAVELIST_MAX) return -1;
        lastIndex = count;
    }
    uint64_t arrLen = rpm<uint64_t>(slots + ox::ARRAY_COUNT);
    if (arrLen == 0 || arrLen > (uint64_t)ox::LOS_SAVELIST_MAX) return -1;
    if ((uint64_t)lastIndex > arrLen) lastIndex = (int)arrLen;

    // Bulk-read всего slots-массива (Slot stride 0x10) одним чтением.
    uint64_t dataBase = slots + ox::ARRAY_DATA;
    size_t bytes = (size_t)lastIndex * (size_t)ox::HASHSET_SLOT_STRIDE;
    std::vector<uint8_t> buf(bytes);
    if (!vm_readv(dataBase, buf.data(), bytes)) return -1;

    int seen = 0;
    for (int i = 0; i < lastIndex; ++i) {
        const uint8_t* s = buf.data() + (size_t)i * ox::HASHSET_SLOT_STRIDE;
        int32_t hashCode; memcpy(&hashCode, s + ox::HASHSET_SLOT_HASHCODE, 4);
        if (hashCode < 0) continue; // свободный слот
        uint64_t value; memcpy(&value, s + ox::HASHSET_SLOT_VALUE, 8);
        if (!ox_isPtr(value)) continue;
        cb(value);
        ++seen;
    }
    return seen;
}

// Обходит Mono Dictionary<int,T> (fallback для saveLookup) -> cb(value).
//   dict+0x18 -> Entry[] entries ; dict+0x28 -> count
//   Entry { int hashCode; int next; int key; T value } stride 0x18, занят: hashCode>=0.
template<typename CB>
static int ox_forEachDictValues(uint64_t dictObj, CB&& cb) {
    if (!ox_isPtr(dictObj)) return -1;
    uint64_t entries = rpm<uint64_t>(dictObj + ox::DICT_ENTRIES);
    if (!ox_isPtr(entries)) return -1;
    int count = rpm<int>(dictObj + ox::DICT_COUNT);
    if (count <= 0 || count > ox::LOS_SAVELIST_MAX) return -1;
    uint64_t arrLen = rpm<uint64_t>(entries + ox::ARRAY_COUNT);
    if (arrLen == 0 || arrLen > (uint64_t)ox::LOS_SAVELIST_MAX) return -1;
    if ((uint64_t)count > arrLen) count = (int)arrLen;

    uint64_t dataBase = entries + ox::ARRAY_DATA;
    size_t bytes = (size_t)count * (size_t)ox::DICT_ENTRY_STRIDE;
    std::vector<uint8_t> buf(bytes);
    if (!vm_readv(dataBase, buf.data(), bytes)) return -1;

    int seen = 0;
    for (int i = 0; i < count; ++i) {
        const uint8_t* e = buf.data() + (size_t)i * ox::DICT_ENTRY_STRIDE;
        int32_t hashCode; memcpy(&hashCode, e + ox::DICT_ENTRY_HASHCODE, 4);
        if (hashCode < 0) continue;
        uint64_t value; memcpy(&value, e + ox::DICT_ENTRY_VALUE, 8);
        if (!ox_isPtr(value)) continue;
        cb(value);
        ++seen;
    }
    return seen;
}

// Читает Bounds в мировую AABB. Инфлейтит на LOS_AABB_INFLATE со всех сторон.
// Euler (deg, Unity ZXY) -> Quat. Для поворота локальных bounds в мир.
static Quat ox_eulerToQuat(const Vector3 &degEuler) {
    float rx = degEuler.x * DEG2RAD * 0.5f;
    float ry = degEuler.y * DEG2RAD * 0.5f;
    float rz = degEuler.z * DEG2RAD * 0.5f;
    float cx = cosf(rx), sx = sinf(rx);
    float cy = cosf(ry), sy = sinf(ry);
    float cz = cosf(rz), sz = sinf(rz);
    // Unity order ZXY: q = Y * X * Z (applied right-to-left)
    Quat qx{ sx, 0, 0, cx };
    Quat qy{ 0, sy, 0, cy };
    Quat qz{ 0, 0, sz, cz };
    return quatMul(quatMul(qy, qx), qz);
}

static bool ox_readWorldAABB(uint64_t building, WorldAABB &out) {
    out = WorldAABB{Vector3(0,0,0), Vector3(0,0,0)};
    if (!ox_isPtr(building)) return false;

    // World-позиция постройки (server-authoritative m_CorrectPosition @0x8C).
    Vector3 worldPos = rpm<Vector3>(building + ox::BP_CORRECT_POSITION);
    // m_CorrectRotation (Euler deg @0x98) — поворот постройки в мире.
    Vector3 worldRotEuler = rpm<Vector3>(building + ox::BP_CORRECT_ROTATION);
    // Bounds локальны к pivot'у (m_Center 0x0, m_Extents 0xC на building+BP_BOUNDS).
    uint64_t bAddr = building + ox::BP_BOUNDS;
    Vector3 center = rpm<Vector3>(bAddr + ox::BOUNDS_CENTER);
    Vector3 extents = rpm<Vector3>(bAddr + ox::BOUNDS_EXTENTS);

    // Валидность.
    if (extents.x < 0.f || extents.y < 0.f || extents.z < 0.f) return false;
    if (extents.x > 100.f || extents.y > 100.f || extents.z > 100.f) return false;
    if (!isfinite(center.x) || !isfinite(center.y) || !isfinite(center.z)) return false;
    if (!isfinite(extents.x) || !isfinite(extents.y) || !isfinite(extents.z)) return false;
    if (!isfinite(worldRotEuler.x) || !isfinite(worldRotEuler.y) || !isfinite(worldRotEuler.z))
        worldRotEuler = Vector3(0,0,0);

    float infl = ox::LOS_AABB_INFLATE;

    // FIX bug #1: учитываем ПОВОРОТ постройки. Стены/фундаменты в Oxide повёрнуты
    // (кратно 90° и не только) -> без учёта rotation AABB съезжал и LOS промахивался.
    // Строим мировой axis-aligned AABB из 8 повёрнутых углов локального Bounds.
    bool rotated = (fabsf(worldRotEuler.x) > 0.01f || fabsf(worldRotEuler.y) > 0.01f ||
                    fabsf(worldRotEuler.z) > 0.01f);
    if (!rotated) {
        Vector3 wc(center.x + worldPos.x, center.y + worldPos.y, center.z + worldPos.z);
        out.min = Vector3(wc.x - extents.x - infl, wc.y - extents.y - infl, wc.z - extents.z - infl);
        out.max = Vector3(wc.x + extents.x + infl, wc.y + extents.y + infl, wc.z + extents.z + infl);
        return true;
    }

    Quat q = ox_eulerToQuat(worldRotEuler);
    Vector3 mn( 1e30f, 1e30f, 1e30f), mx(-1e30f,-1e30f,-1e30f);
    for (int sx = -1; sx <= 1; sx += 2)
    for (int sy = -1; sy <= 1; sy += 2)
    for (int sz = -1; sz <= 1; sz += 2) {
        Vector3 localCorner(center.x + sx*extents.x,
                            center.y + sy*extents.y,
                            center.z + sz*extents.z);
        Vector3 r = quatRotate(q, localCorner);      // повернули вокруг pivot
        Vector3 w(r.x + worldPos.x, r.y + worldPos.y, r.z + worldPos.z);
        if (w.x < mn.x) mn.x = w.x; if (w.x > mx.x) mx.x = w.x;
        if (w.y < mn.y) mn.y = w.y; if (w.y > mx.y) mx.y = w.y;
        if (w.z < mn.z) mn.z = w.z; if (w.z > mx.z) mx.z = w.z;
    }
    out.min = Vector3(mn.x - infl, mn.y - infl, mn.z - infl);
    out.max = Vector3(mx.x + infl, mx.y + infl, mx.z + infl);
    return true;
}

// Slab-method ray-AABB. Возвращает true если луч попадает в AABB, и t-интервал
// [tNear, tFar]. Если начало луча внутри AABB — tNear=0, tFar=dist до выхода.
static bool ox_rayAABB(const Vector3 &origin, const Vector3 &dirNorm,
                       const WorldAABB &b, float &tNear, float &tFar) {
    tNear = -1e30f;
    tFar  = +1e30f;
    const float *o = &origin.x;
    const float *d = &dirNorm.x;
    const float *mn = &b.min.x;
    const float *mx = &b.max.x;
    for (int i = 0; i < 3; ++i) {
        float oi = o[i], di = d[i], mni = mn[i], mxi = mx[i];
        if (fabsf(di) < 1e-6f) {
            // Параллельная оси — луч вне slab
            if (oi < mni || oi > mxi) return false;
        } else {
            float inv = 1.0f / di;
            float t1 = (mni - oi) * inv;
            float t2 = (mxi - oi) * inv;
            if (t1 > t2) { float t = t1; t1 = t2; t2 = t; }
            if (t1 > tNear) tNear = t1;
            if (t2 < tFar)  tFar  = t2;
            if (tNear > tFar) return false;
        }
    }
    return tFar >= 0.f; // пересечение в положительном направлении
}

// Обновляет кэш построе��. Тяжёлая часть — single-thread-safe (locks mutex).
static void ox_updateBuildingCache(bool full) {
    int frame = ImGui::GetFrameCount();
    if (frame - g_buildingCacheFrame < BUILDING_CACHE_INTERVAL && !g_buildingCache.empty())
        return;
    g_buildingCacheFrame = frame;

    if (!il2cpp_base) return;
    uint64_t statics = ox_getClassStatics(g_buildingPieceTypeInfoRVA, g_buildingPieceKlass, full);
    if (!statics) { if (full) OXLOGW("[LOS] BuildingPiece.statics не резолвится"); return; }

    std::vector<BuildingCacheEntry> newCache;
    int valid = 0, total = 0;

    // Общий приёмник одного BuildingPiece -> world-AABB (с фильтром health>0).
    auto addPiece = [&](uint64_t b) {
        ++total;
        if (!ox_isPtr(b)) return;
        BuildingCacheEntry e;
        e.address = b;
        e.valid = ox_readWorldAABB(b, e.bounds);
        if (!e.valid) return;
        float hp = rpm<float>(b + ox::BP_HEALTH);
        if (hp <= 0.f || !isfinite(hp)) return; // разрушенная/невалидная — пропуск
        newCache.push_back(e);
        ++valid;
    };

    // ── ПЕРВИЧНО: saveList — HashSet<BuildingPiece> (static+0x0) ──
    // FIX bug #1: раньше читалось как List<T> -> всегда пусто -> LOS не работал.
    uint64_t saveList = rpm<uint64_t>(statics + ox::STATIC_BUILDING_SAVELIST);
    int hsSeen = ox_forEachHashSet(saveList, addPiece);
    if (full) OXLOGI("[LOS] saveList(HashSet)=0x%llx seen=%d",
                     (unsigned long long)saveList, hsSeen);

    // ── FALLBACK: saveLookup — Dictionary<int,BuildingPiece> (static+0x8) ──
    // Если HashSet не дал элементов (иная реализация/пусто) — берём словарь.
    if (hsSeen <= 0) {
        uint64_t saveLookup = rpm<uint64_t>(statics + ox::STATIC_BUILDING_SAVELOOKUP);
        int dSeen = ox_forEachDictValues(saveLookup, addPiece);
        if (full) OXLOGI("[LOS] fallback saveLookup(Dict)=0x%llx seen=%d",
                         (unsigned long long)saveLookup, dSeen);
    }

    // Всегда логируем результат раз в ~5 сек чтобы видеть если LOS не работает
    // (кэш пуст = wall check не может ничего блокировать).
    static int s_lastLogFrame = -10000;
    if (full || (frame - s_lastLogFrame > 300)) {
        s_lastLogFrame = frame;
        OXLOGI("[LOS] building cache: valid=%d/%d, active=%d", valid, total, (int)newCache.size());
        if (valid == 0 && total == 0) {
            // Диагностика ПОЧЕМУ пусто: печатаем сырые значения контейнеров,
            // иначе невозможно отличить «сервер не прислал стены» от
            // «прочитали не тот оффсет».
            uint64_t sl  = rpm<uint64_t>(statics + ox::STATIC_BUILDING_SAVELIST);
            uint64_t slk = rpm<uint64_t>(statics + ox::STATIC_BUILDING_SAVELOOKUP);
            int hsCount = ox_isPtr(sl)  ? rpm<int>(sl  + ox::HASHSET_COUNT) : -1;
            int hsLast  = ox_isPtr(sl)  ? rpm<int>(sl  + ox::HASHSET_LASTINDEX) : -1;
            uint64_t hsSlots = ox_isPtr(sl) ? rpm<uint64_t>(sl + ox::HASHSET_SLOTS) : 0;
            OXLOGW("[LOS] пусто. statics=0x%llx saveList=0x%llx (count=%d lastIdx=%d slots=0x%llx) "
                   "saveLookup=0x%llx",
                   (unsigned long long)statics, (unsigned long long)sl,
                   hsCount, hsLast, (unsigned long long)hsSlots,
                   (unsigned long long)slk);
            OXLOGW("[LOS] если count>0 но valid=0 — не тот layout HashSet; "
                   "если count<=0 — клиент не получает постройки от сервера.");
        }
    }
    // ── РЕЗЕРВ: NetworkClient.spawned ──────────────────────────────────────
    // BuildingPiece попадает в saveList только на СЕРВЕРЕ (OnStartServer), у
    // клиента этот список пустой — в логах стабильно count=0, поэтому LOS не
    // работал вообще. А spawned заполнен всегда: это реестр всех сетевых
    // объектов, которые знает клиент.
    // Обход: spawned -> NetworkIdentity -> NetworkBehaviours[] -> ищем среди
    // компонентов BuildingPiece. Опознаём его по САМОСОГЛАСОВАННОСТИ полей:
    // health/maxHealth в разумном диапазоне и m_Bounds с ненулевыми extents.
    // Так не нужно знать индекс компонента и класс заранее.
    if (newCache.empty() && g_networkClientKlass) {
        uint64_t ncStatics = rpm<uint64_t>(g_networkClientKlass + ox::CLASS_STATIC_FIELDS);
        uint64_t spawned = ox_isPtr(ncStatics)
                         ? rpm<uint64_t>(ncStatics + ox::NC_SPAWNED_DICT) : 0;
        int walked = 0, matched = 0;
        // Собственный обход, а НЕ ox_forEachDictValues: тот режет словари
        // больше LOS_SAVELIST_MAX (2000), а spawned на большой карте заведомо
        // крупнее и весь резерв молча вернул бы -1.
        auto walkSpawned = [&](uint64_t dictObj, auto&& cb) {
            if (!ox_isPtr(dictObj)) return;
            uint64_t entries = rpm<uint64_t>(dictObj + ox::DICT_ENTRIES);
            if (!ox_isPtr(entries)) return;
            int count = rpm<int>(dictObj + ox::DICT_COUNT);
            if (count <= 0) return;
            uint64_t arrLen = rpm<uint64_t>(entries + ox::ARRAY_COUNT);
            if (arrLen == 0) return;
            if ((uint64_t)count > arrLen) count = (int)arrLen;
            if (count > ox::SPAWNED_SCAN_MAX) count = ox::SPAWNED_SCAN_MAX;

            // Одним vm_readv на весь блок — это ~96 КБ, дёшево. Дорогая часть
            // ниже (чтение компонентов), поэтому она под потолком и идёт раз
            // в BUILDING_CACHE_INTERVAL кадров.
            size_t bytes = (size_t)count * (size_t)ox::DICT_ENTRY_STRIDE;
            std::vector<uint8_t> buf(bytes);
            if (!vm_readv(entries + ox::ARRAY_DATA, buf.data(), bytes)) return;
            for (int i = 0; i < count; ++i) {
                const uint8_t* e = buf.data() + (size_t)i * ox::DICT_ENTRY_STRIDE;
                int32_t hc; memcpy(&hc, e + ox::DICT_ENTRY_HASHCODE, 4);
                if (hc < 0) continue;
                uint64_t v; memcpy(&v, e + ox::DICT_ENTRY_VALUE, 8);
                if (ox_isPtr(v)) cb(v);
            }
        };
        if (ox_isPtr(spawned)) {
            walkSpawned(spawned, [&](uint64_t ni) {
                if (walked++ > ox::SPAWNED_SCAN_MAX) return;
                uint64_t arr = rpm<uint64_t>(ni + ox::NI_BEHAVIOURS);
                if (!ox_isPtr(arr)) return;
                uint64_t n = rpm<uint64_t>(arr + ox::ARRAY_COUNT);
                if (n == 0 || n > 16) return;
                uint64_t base = arr + ox::ARRAY_DATA;
                for (uint64_t k = 0; k < n; ++k) {
                    uint64_t comp = rpm<uint64_t>(base + k * 8);
                    if (!ox_isPtr(comp)) continue;
                    // Самопроверка «это BuildingPiece»: здоровье осмысленное.
                    float hp  = rpm<float>(comp + ox::BP_HEALTH);
                    float mhp = rpm<float>(comp + ox::BP_MAXHEALTH);
                    if (!isfinite(hp) || !isfinite(mhp)) continue;
                    if (hp <= 0.f || mhp <= 0.f || hp > mhp * 1.05f || mhp > 100000.f) continue;
                    BuildingCacheEntry e{};
                    e.address = comp;
                    if (!ox_readWorldAABB(comp, e.bounds)) continue;
                    e.valid = true;
                    newCache.push_back(e);
                    matched++;
                    break;   // один BuildingPiece на объект
                }
            });
        }
        if (full || matched > 0)
            OXLOGI("[LOS] fallback NetworkClient.spawned=0x%llx walked=%d matched=%d",
                   (unsigned long long)spawned, walked, matched);
    }

    {
        std::lock_guard<std::mutex> lock(g_buildingMutex);
        g_buildingCache = std::move(newCache);
    }
}

// Главная функция LOS-чека. Возвращает true, если путь origin→target свободен
// (не перекрыт никаким BuildingPiece). assumeBuilding=true → считается, что
// невидима. distance = |target - origin|.
static bool ox_lineOfSightClear(const Vector3 &origin, const Vector3 &target, float distance) {
    if (g_buildingCache.empty()) return true; // безblocks не резолвится => считаем видимым
    Vector3 dir = target - origin;
    float len = sqrtf(dir.x*dir.x + dir.y*dir.y + dir.z*dir.z);
    if (len < 0.001f) return true;
    Vector3 dirN = Vector3(dir.x/len, dir.y/len, dir.z/len);

    // Небольшой отступ от камеры: игнорируем стены, в чьём инфлейт-AABB мы
    // фактически стоим (иначе стоя вплотную к стене ВСЁ считалось бы за стеной).
    const float NEAR_EPS = 0.35f;

    std::lock_guard<std::mutex> lock(g_buildingMutex);
    for (const BuildingCacheEntry &e : g_buildingCache) {
        if (!e.valid) continue;
        float tNear, tFar;
        if (!ox_rayAABB(origin, dirN, e.bounds, tNear, tFar)) continue;
        // Блокирует ТОЛЬКО стена, стоящая МЕЖДУ камерой и целью:
        //   tNear в (NEAR_EPS .. distance - TARGET_EPS).
        // tNear <= NEAR_EPS => мы внутри/у самой стены (не считаем перекрытием).
        // tNear >= distance - eps => стена за целью (не мешает).
        if (tNear > NEAR_EPS && tNear < distance - ox::LOS_TARGET_EPS)
            return false;
    }
    return true;
}

// Булева видимость цели: true если path от камеры до точкиBone свободен.
// Используется и в ESP (для окрашивания бокса), и в aimbot для фильтрации.
static bool ox_isTargetVisible(const Vector3 &camPos, const Vector3 &targetPos) {
    float dist = Vector3::Distance(camPos, targetPos);
    if (dist < 0.001f) return true;
    // Без искусственного лимита дальности — ray-AABB дёшево (200 построек × 12
    // сравнений), а aimMaxDistance может быть до 1000м.
    return ox_lineOfSightClear(camPos, targetPos, dist);
}

// Одноразовый runtime-профиль для обновления игры. Запускается кнопкой из меню
// и пишет в обычный eclips_oxide_*.log: реальные адреса, цепочки статиков и полей,
// а также хексы первых игроков. Это не заменяет Il2CppDumper для RVA методов,
// но даёт все runtime offsets, которые нужны ESP/LOS/aim для калибровки версии.
[[maybe_unused]] static std::string g_runtimeDumpStatus = "No runtime dump yet";

[[maybe_unused]] static void ox_dumpRuntimeProfile() {
    oxlog::section("RUNTIME OFFSET DUMP");
    const char *logPath = oxlog::init();

    if (!ox_ensureBase(true)) {
        g_runtimeDumpStatus = "Dump failed: libil2cpp.so is not loaded";
        OXLOGE("[DUMP] %s", g_runtimeDumpStatus.c_str());
        return;
    }

    OXLOGI("[DUMP] PID=%d base=0x%llx log=%s", game_pid,
           (unsigned long long)il2cpp_base, logPath ? logPath : "<none>");
    OXLOGI("[DUMP] RVA PlayerManager_TypeInfo=0x%llx BuildingPiece_TypeInfo=0x%llx",
           (unsigned long long)g_playerManagerTypeInfoRVA,
           (unsigned long long)g_buildingPieceTypeInfoRVA);
    OXLOGI("[DUMP] PlayerManager fields: transform=0x%llx mouseLook=0x%llx raycastManager=0x%llx vitals=0x%llx local=0x%llx team=0x%llx",
           (unsigned long long)ox::PM_TRANSFORM,
           (unsigned long long)ox::PM_MOUSELOOK,
           (unsigned long long)ox::PM_RAYCASTMANAGER,
           (unsigned long long)ox::PM_VITALS,
           (unsigned long long)ox::PM_IS_LOCAL_PLAYER,
           (unsigned long long)ox::PM_TEAM_NAME);
    OXLOGI("[DUMP] MouseLook fields: lookRoot=0x%llx pitch=0x%llx yaw=0x%llx",
           (unsigned long long)ox::ML_LOOKROOT,
           (unsigned long long)ox::ML_PITCH,
           (unsigned long long)ox::ML_YAW);
    OXLOGI("[DUMP] BuildingPiece fields: worldPos=0x%llx bounds=0x%llx health=0x%llx saveList(static)=0x%llx",
           (unsigned long long)ox::BP_CORRECT_POSITION,
           (unsigned long long)ox::BP_BOUNDS,
           (unsigned long long)ox::BP_HEALTH,
           (unsigned long long)ox::STATIC_BUILDING_SAVELIST);

    // Полная карта модулей и проверка ELF magic помогают сразу увидеть неверную базу.
    ox_moduleInfo();

    uint64_t playerStatics = ox_getStatics(true);
    if (!playerStatics) {
        g_runtimeDumpStatus = "Dump partial: PlayerManager statics unresolved";
        OXLOGE("[DUMP] %s", g_runtimeDumpStatus.c_str());
        return;
    }

    PlayerListView players = ox_scanForPlayerList(playerStatics, true);
    if (!players.ok) {
        g_runtimeDumpStatus = "Dump partial: activePlayerList unresolved";
        OXLOGE("[DUMP] %s", g_runtimeDumpStatus.c_str());
        return;
    }

    OXLOGI("[DUMP] players: static+0x%llx list=0x%llx elements=0x%llx count=%d",
           (unsigned long long)players.statOff,
           (unsigned long long)players.container,
           (unsigned long long)players.elems,
           players.count);

    CameraView cam = ox_getCamera(players.elems, players.count, true);
    OXLOGI("[DUMP] camera: valid=%d local=0x%llx pos=(%.3f,%.3f,%.3f) fov=%.3f",
           (int)cam.valid, (unsigned long long)g_localPlayer,
           cam.pos.x, cam.pos.y, cam.pos.z, cam.fovH);

    if (ox_isPtr(g_localPlayer)) {
        uint64_t mouseLook = rpm<uint64_t>(g_localPlayer + ox::PM_MOUSELOOK);
        uint64_t raycast = rpm<uint64_t>(g_localPlayer + ox::PM_RAYCASTMANAGER);
        OXLOGI("[DUMP] local MouseLook=0x%llx pitch=%.3f yaw=%.3f",
               (unsigned long long)mouseLook,
               rpm<float>(mouseLook + ox::ML_PITCH),
               rpm<float>(mouseLook + ox::ML_YAW));
        OXLOGI("[DUMP] RaycastManager=0x%llx camera=0x%llx rayLength=%.3f aimRayLength=%.3f mask=0x%x aimMask=0x%x",
               (unsigned long long)raycast,
               (unsigned long long)rpm<uint64_t>(raycast + ox::RM_WORLD_CAMERA),
               rpm<float>(raycast + ox::RM_RAY_LENGTH),
               rpm<float>(raycast + ox::RM_AIM_RAY_LENGTH),
               rpm<int>(raycast + ox::RM_LAYER_MASK),
               rpm<int>(raycast + ox::RM_AIM_LAYER_MASK));
    }

    oxlog::section("RUNTIME OFFSET DUMP - PLAYER SAMPLES");
    for (int i = 0, dumped = 0; i < players.count && dumped < 3; ++i) {
        uint64_t player = rpm<uint64_t>(players.elems + i * 8);
        if (!ox_isPtr(player)) continue;
        ox_dumpPlayer(i, player);
        ++dumped;
    }

    uint64_t buildingStatics = ox_getClassStatics(g_buildingPieceTypeInfoRVA, g_buildingPieceKlass, true);
    uint64_t saveList   = buildingStatics ? rpm<uint64_t>(buildingStatics + ox::STATIC_BUILDING_SAVELIST) : 0;
    uint64_t saveLookup = buildingStatics ? rpm<uint64_t>(buildingStatics + ox::STATIC_BUILDING_SAVELOOKUP) : 0;
    // saveList — HashSet<BuildingPiece>, НЕ List. Считаем корректным обходом.
    int hsCount = 0, dCount = 0;
    ox_forEachHashSet(saveList, [&](uint64_t){ ++hsCount; });
    ox_forEachDictValues(saveLookup, [&](uint64_t){ ++dCount; });
    OXLOGI("[DUMP] BuildingPiece: statics=0x%llx saveList(HashSet)=0x%llx count=%d | saveLookup(Dict)=0x%llx count=%d",
           (unsigned long long)buildingStatics,
           (unsigned long long)saveList, hsCount,
           (unsigned long long)saveLookup, dCount);

    ox_updateBuildingCache(true);
    size_t cachedBuildings = 0;
    {
        std::lock_guard<std::mutex> lock(g_buildingMutex);
        cachedBuildings = g_buildingCache.size();
    }
    OXLOGI("[DUMP] Building LOS cache=%zu", cachedBuildings);

    g_runtimeDumpStatus = "Dump saved: " + std::string(logPath ? logPath : "/sdcard/Download");
    OXLOGI("[DUMP] COMPLETE: %s", g_runtimeDumpStatus.c_str());
}

// playerPosition = FEET (lastTickPosition, server-authoritative). Bones — offsets
// ВВЕРХ от ног. Стоящая модель: макушка ~1.85, центр головы ~1.62, шея ~1.45,
// грудь ~1.30. bug #4: при aimCrouchSafe опускаем на crouch-дельту (ручной режим,
// т.к. реальное состояние присед недоступно внешнему читу — см. коммент выше).
static Vector3 ox_aimPoint(Vector3 playerPosition) {
    float h;
    switch (aimcurbone) {
        case 0: h = 1.62f; break; // head (центр головы, а не макушка — надёжнее)
        case 1: h = 1.45f; break; // neck
        default: h = 1.30f; break; // body/chest
    }
    if (aimCrouchSafe) h -= aimCrouchDrop;
    // Та же вертикальная привязка что и у ESP-бокса — иначе прицел уедет
    // относительно того что нарисовано на экране.
    return playerPosition + Vector3(0.f, ox_boxYOffset() + h, 0.f);
}

// Точка прицеливания по ФАКТИЧЕСКИМ габаритам модели, когда якоря прочитаны.
// Доли от реального роста вместо абсолютных метров: работает и на приседе, и
// на нестандартной модели, и не зависит от espBoxYOffset. Если якорей нет —
// откат на старую формулу, поведение прежнее.
static Vector3 ox_aimPointFor(const PlayerCacheData& pl) {
    if (!pl.usedModelAnchor) return ox_aimPoint(pl.position);

    // H — ФАКТИЧЕСКАЯ высота цели В ЭТОМ КАДРЕ. Когда игрок приседает, игра
    // опускает голову, H уменьшается, и точка прицела едет вниз ВМЕСТЕ с ним.
    // Никакого ручного «crouch drop» больше не нужно — присед учитывается сам.
    float H = pl.anchorHead.y - pl.anchorFeet.y;
    if (!isfinite(H) || H < 0.40f || H > 2.60f) return ox_aimPoint(pl.position);

    // Доли от реального роста, а не абсолютные метры. anchorHead — это точка
    // KCC.head (уровень глаз/шеи), поэтому:
    //   1.00 = ровно глаза, 0.90 ≈ центр головы, 0.80 ≈ шея, 0.66 ≈ грудь.
    float frac;
    switch (aimcurbone) {
        case 0: frac = 0.97f; break;  // head — чуть ниже глаз, по центру черепа
        case 1: frac = 0.86f; break;  // neck
        default: frac = 0.68f; break; // body — центр массы груди
    }

    // Ручной crouch-safe оставлен как страховка, но при живом приседе он уже
    // не нужен: применяем его только когда капсула НЕ показывает присед.
    if (aimCrouchSafe && !pl.anchorCrouching) frac -= aimCrouchDrop / H;
    frac = ::clamp<float>(frac, 0.10f, 1.02f);

    // По X/Z берём голову: на бегу корпус наклонён, ноги отстают от торса.
    return Vector3(pl.anchorHead.x,
                   pl.anchorFeet.y + H * frac,
                   pl.anchorHead.z);
}

// UPDATE 2026/07/31 v22: детект «стреляем сейчас» для режимов Fire/ADS+Fire.
// Читает FPManager (PM+0x90) -> _currentWeapon (0x50). Флаг стрельбы у оружия
// обфусцирован, поэтому используем change-detection: пока идёт стрельба, движок
// быстро меняет состояние weapon-объекта (анимация отдачи/таймеры). Держим
// хэш небольшого окна weapon-объекта, при изменении считаем «стреляет» ещё
// FIRE_HOLD_MS. Оффсет-независимо. Если не сработает на устройстве — снимем
// точный fire-флаг из одного лога.
static bool ox_localIsFiring() {
    if (!ox_isPtr(g_localPlayer)) return false;
    uint64_t fp = rpm<uint64_t>(g_localPlayer + ox::PM_FPMANAGER);
    if (!ox_isPtr(fp)) return false;
    uint64_t weap = rpm<uint64_t>(fp + ox::FP_CURRENT_WEAPON);
    if (!ox_isPtr(weap)) return false;

    // Хэшируем окно 0x30..0x90 weapon-объекта (там таймеры/состояние отдачи).
    uint8_t buf[96] = {0};
    if (!vm_readv(weap + 0x30, buf, sizeof(buf))) return false;
    uint32_t h = 2166136261u;
    for (size_t i = 0; i < sizeof(buf); ++i) { h ^= buf[i]; h *= 16777619u; }

    static uint32_t s_lastHash = 0;
    static double   s_lastChange = -10.0;
    double now = (double)ImGui::GetTime();
    if (h != s_lastHash) { s_lastHash = h; s_lastChange = now; }
    // «Стреляет», если состояние менялось в последние 160 мс.
    return (now - s_lastChange) < 0.160;
}

// Selects the target nearest the crosshair and adjusts the local MouseLook angles.
static void ox_runAimbot(const CameraView& cam, const std::vector<PlayerCacheData>& players) {
    if (!aimm || !cam.valid || !ox_isPtr(g_localPlayer)) return;

    // UPDATE v22: режим активации аима.
    //   0 Always | 1 ADS | 2 Fire | 3 ADS+Fire
    // cam.aiming — из живого FOV (FPManager.kYl<_kSQ*ratio), проверенный сигнал ADS.
    {
        bool ads  = cam.aiming;
        bool fire = (aimTriggerMode == 2 || aimTriggerMode == 3) ? ox_localIsFiring() : false;
        bool allow;
        switch (aimTriggerMode) {
            case 0:  allow = true;            break;  // всегда
            case 1:  allow = ads;             break;  // только прицел
            case 2:  allow = fire;            break;  // только стрельба
            case 3:  allow = ads || fire;     break;  // прицел или стрельба
            default: allow = ads;             break;
        }
        if (!allow) return;
    }

    const ImVec2 screenCenter((float)abs_ScreenX * 0.5f, (float)abs_ScreenY * 0.5f);
    const float maxFovSquared = aimFovPixels * aimFovPixels;
    Vector3 bestPoint;
    float bestFovSquared = maxFovSquared;
    bool foundTarget = false;

    for (const PlayerCacheData& player : players) {
        if (!ox_isPtr(player.address)) continue;
        // Toggle-controlled skip сокомандников. player.teamName хранит стабильный
        // team-key (см. UpdatePlayerCache / ox_teamKey). Ключ имеет префикс:
        // "N:<name>", "I:<pfTeamId>", или "P:<wnn_ptr>" (fallback pointer-eq).
        if (aimIgnoreTeammates &&
            (ox_isTeammate(g_localPlayer, player.address) ||
             (!g_localTeamName.empty() && !player.teamName.empty() &&
              player.teamName == g_localTeamName))) continue;
        Vector3 livePosition = player.position;
        Vector3 point = ox_aimPointFor(player);
        Vector3 eyeDist = (g_camVPValid && g_camPosValid) ? g_camPosFromMatrix : cam.pos;
        float distance = Vector3::Distance(eyeDist, point);
        if (aimMaxDistance > 0.f && distance > aimMaxDistance) continue;

        if (aimPrediction && aimProjectileSpeed > 1.0f) {
            // UPDATE v20: скорость цели. Для REMOTE-игроков Motor.BaseVelocity
            // ЗАМОРОЖЕН (мотор локально не тикает — та же причина что и «боксы на
            // спавне»). Поэтому ПРИОРИТЕТ у численной velocity (производная от
            // движущегося lastTickPosition, сглажена EMA). motorVelocity —
            // только если численная нулевая (первые кадры) и мотор реально живой.
            Vector3 vel = player.velocity;
            if (vel.x == 0.f && vel.y == 0.f && vel.z == 0.f &&
                (player.motorVelocity.x != 0.f || player.motorVelocity.y != 0.f ||
                 player.motorVelocity.z != 0.f))
                vel = player.motorVelocity;

            // Итеративное схождение к точке встречи: t = dist(eye, target+vel*t)/speed.
            // Цель уходит — дистанция растёт — время растёт. 3 итерации сходятся
            // с точностью до сантиметров на реальных скоростях.
            const float lat = aimLatencyMs * 0.001f;
            float leadTime = distance / aimProjectileSpeed + lat;
            int iters = aimPredictIters < 1 ? 1 : (aimPredictIters > 6 ? 6 : aimPredictIters);
            for (int it = 0; it < iters; ++it) {
                Vector3 predicted = point + vel * leadTime;
                float d = Vector3::Distance(eyeDist, predicted);
                float t = d / aimProjectileSpeed + lat;
                t = ::clamp<float>(t, 0.0f, aimMaxLeadTime);
                if (fabsf(t - leadTime) < 0.0005f) { leadTime = t; break; }
                leadTime = t;
            }
            leadTime = ::clamp<float>(leadTime, 0.0f, aimMaxLeadTime);
            point += vel * leadTime;

            // Компенсация падения пули (баллистика): за время полёта пуля
            // проседает на 0.5*g*t². Поднимаем точку прицела ровно на дроп, чтобы
            // траектория пришла в цель. При gravity=0 (hitscan) слагаемое нулевое.
            if (aimProjectileGravity > 0.001f) {
                float drop = 0.5f * aimProjectileGravity * leadTime * leadTime;
                if (isfinite(drop) && drop < 20.0f) point.y += drop;
            }
        }

        // --- LOS-чек (аим не через стены) ---
        // Внимание: player.losBlocked считается в ESP-секции для ТЕЛА игрока
        // (livePos) и используется только для окраски бокса. В aimbot проверяем
        // реальный point (head/neck/body) — т.к. голова может торчать из-за
        // стены при перекрытом теле.
        bool blocked = false;
        if (aimCheckWalls) {
            Vector3 eyeLos = (g_camVPValid && g_camPosValid) ? g_camPosFromMatrix : cam.pos;
            blocked = !ox_isTargetVisible(eyeLos, point);
        }
        if (blocked) continue;

        bool onScreen = false;
        ImVec2 screen;
        if (g_camVPValid) {
            if (!ox_w2sMatrix(g_camVP, point, (float)abs_ScreenX,
                              (float)abs_ScreenY, &screen)) {
                onScreen = false;
                screen = ImVec2(-1.f, -1.f);
            } else {
                onScreen = (screen.x >= 0.f && screen.x <= abs_ScreenX &&
                            screen.y >= 0.f && screen.y <= abs_ScreenY);
            }
        } else {
            screen = w2s_angular(point, cam, &onScreen);
        }
        if (aimvisible && !onScreen) continue;
        float dx = screen.x - screenCenter.x;
        float dy = screen.y - screenCenter.y;
        float fovSquared = dx * dx + dy * dy;
        if (!onScreen || fovSquared > bestFovSquared) continue;

        bestFovSquared = fovSquared;
        bestPoint = point;
        foundTarget = true;
    }

    if (!foundTarget) return;

    uint64_t mouseLook = rpm<uint64_t>(g_localPlayer + ox::PM_MOUSELOOK);
    if (!ox_isPtr(mouseLook)) return;

    // Точка отсчёта углов ОБЯЗАНА совпадать с точкой, из которой строилась
    // проекция при выборе цели. Иначе прицел уезжает на разницу между
    // реконструированной камерой и настоящей — это и был баг «целит выше».
    Vector3 eye = (g_camVPValid && g_camPosValid) ? g_camPosFromMatrix : cam.pos;

    Vector3 delta = bestPoint - eye;
    float horizontalDistance = sqrtf(delta.x * delta.x + delta.z * delta.z);
    if (horizontalDistance < 0.001f) return;

    const float radToDeg = 57.2957795131f;
    // MouseLook stores positive pitch when looking down, opposite Unity world Y.
    float targetPitch = -atan2f(delta.y, horizontalDistance) * radToDeg;
    float targetYaw = atan2f(delta.x, delta.z) * radToDeg;
    float currentPitch = rpm<float>(mouseLook + ox::ML_PITCH);
    float currentYaw = rpm<float>(mouseLook + ox::ML_YAW);
    if (!isfinite(currentPitch) || !isfinite(currentYaw)) return;

    float smooth = aimSmooth < 1.0f ? 1.0f : aimSmooth;
    float nextPitch = currentPitch + (targetPitch - currentPitch) / smooth;
    float nextYaw = currentYaw + ox_normalizeAngle(targetYaw - currentYaw) / smooth;
    nextPitch = ::clamp<float>(nextPitch, -80.0f, 80.0f);
    nextYaw = ox_normalizeAngle(nextYaw);

    // Диагностика раз в 2 сек: видно откуда считаются углы и куда целимся.
    // eyeSrc=M — позиция камеры взята из матрицы (правильно), =R — из
    // реконструкции (значит матрица не поднялась).
    {
        static double s_lastAimLog = 0.0;
        double nowA = (double)ImGui::GetTime();
        if (nowA - s_lastAimLog > 2.0) {
            s_lastAimLog = nowA;
            OXLOGI("[aim] eyeSrc=%c eye=(%.2f %.2f %.2f) pt=(%.2f %.2f %.2f) "
                   "dy=%.2f pitch %.1f->%.1f yaw %.1f->%.1f bone=%d",
                   (g_camVPValid && g_camPosValid) ? 'M' : 'R',
                   eye.x, eye.y, eye.z,
                   bestPoint.x, bestPoint.y, bestPoint.z,
                   delta.y, currentPitch, targetPitch, currentYaw, targetYaw,
                   aimcurbone);
        }
    }

    wpm<float>(mouseLook + ox::ML_PITCH, nextPitch);
    wpm<float>(mouseLook + ox::ML_YAW, nextYaw);
}

// ============================================================================
//  РАДАР 360° — миникарта вокруг локального игрока.
//  Чистое рисование по уже собранному кэшу: ни одного лишнего vm_readv.
//  Точки поворачиваются на yaw камеры, поэтому "вверх" на радаре = куда
//  смотришь. Кольцо дистанции + сектор обзора для ориентации.
// ============================================================================
static void ox_drawRadar(ImDrawList* dl, const CameraView& cam,
                         const std::vector<PlayerCacheData>& players) {
    if (!dl || !cam.valid) return;

    const float R  = radarSize * 0.5f;
    const ImVec2 c(radarPos[0] + R, radarPos[1] + R);
    const int    aBg = (int)(::clamp<float>(radarAlpha, 0.05f, 1.0f) * 255.f);

    // --- Подложка: тёмный круг + мягкая рамка ---
    dl->AddCircleFilled(c, R, IM_COL32(8, 8, 14, aBg), 64);
    dl->AddCircle(c, R, IM_COL32(120, 140, 180, 130), 64, 1.6f);
    // кольца дистанции на 1/3 и 2/3 радиуса
    dl->AddCircle(c, R * 0.66f, IM_COL32(120, 140, 180, 55), 48, 1.0f);
    dl->AddCircle(c, R * 0.33f, IM_COL32(120, 140, 180, 40), 40, 1.0f);
    // перекрестье
    dl->AddLine(ImVec2(c.x - R, c.y), ImVec2(c.x + R, c.y), IM_COL32(120, 140, 180, 45), 1.0f);
    dl->AddLine(ImVec2(c.x, c.y - R), ImVec2(c.x, c.y + R), IM_COL32(120, 140, 180, 45), 1.0f);

    // --- Сектор обзора (куда смотрит камера — всегда вверх) ---
    {
        float half = (cam.fovV > 1.f ? cam.fovV : 60.f) * 0.5f * 0.01745329f;
        ImVec2 l(c.x + sinf(-half) * R, c.y - cosf(-half) * R);
        ImVec2 r(c.x + sinf( half) * R, c.y - cosf( half) * R);
        dl->AddTriangleFilled(c, l, r, IM_COL32(90, 170, 255, 40));
        dl->AddLine(c, l, IM_COL32(90, 170, 255, 90), 1.0f);
        dl->AddLine(c, r, IM_COL32(90, 170, 255, 90), 1.0f);
    }

    // --- Точки игроков ---
    // Мир -> радар: смещение относительно камеры, повёрнутое на -yaw, чтобы
    // направление взгляда смотрело вверх экрана.
    const float yawRad = cam.yaw * 0.01745329f;
    const float cs = cosf(yawRad), sn = sinf(yawRad);
    const float range = radarRange < 20.f ? 20.f : radarRange;

    // cached_players уже отфильтрован в UpdatePlayerCache: локального игрока
    // и (при espHideTeammates) сокомандников там нет. Доп. проверок не нужно.
    for (const auto& pl : players) {
        if (pl.address == 0 || pl.address == g_localPlayer) continue;

        float dx = pl.position.x - cam.pos.x;
        float dz = pl.position.z - cam.pos.z;
        if (!isfinite(dx) || !isfinite(dz)) continue;

        // Поворот в систему камеры: X вправо, Z вперёд.
        float rx =  dx * cs - dz * sn;
        float rz =  dx * sn + dz * cs;

        float dist = sqrtf(rx * rx + rz * rz);
        float k = R / range;
        float px = c.x + rx * k;
        float py = c.y - rz * k;   // вперёд = вверх

        bool  clamped = false;
        if (dist > range) {
            // За пределами радиуса — прижимаем к кромке стрелкой-треугольником.
            float nx = rx / dist, nz = rz / dist;
            px = c.x + nx * (R - 5.f);
            py = c.y - nz * (R - 5.f);
            clamped = true;
        }

        // Цвет точки: по высоте относительно камеры (выше/ниже) либо по HP.
        float dy = pl.position.y - cam.pos.y;
        ImU32 col;
        if (dy > 2.5f)       col = IM_COL32(255, 190, 80, 255);   // выше — оранжевый
        else if (dy < -2.5f) col = IM_COL32(120, 200, 255, 255);  // ниже — голубой
        else                 col = IM_COL32(255, 70, 70, 255);    // на уровне — красный
        if (pl.flagSleeping) col = IM_COL32(140, 140, 155, 255);  // спит — серый

        if (clamped) {
            // Треугольник, направленный наружу.
            float ang = atan2f(py - c.y, px - c.x);
            float a1 = ang + 2.6f, a2 = ang - 2.6f;
            dl->AddTriangleFilled(ImVec2(px, py),
                                  ImVec2(px + cosf(a1) * 7.f, py + sinf(a1) * 7.f),
                                  ImVec2(px + cosf(a2) * 7.f, py + sinf(a2) * 7.f), col);
        } else {
            dl->AddCircleFilled(ImVec2(px, py), 4.2f, col, 12);
            dl->AddCircle(ImVec2(px, py), 4.2f, IM_COL32(0, 0, 0, 170), 12, 1.2f);
            // Дистанция мелким текстом рядом с точкой.
            char ds[16]; snprintf(ds, sizeof(ds), "%.0f", pl.distance);
            dl->AddText(ImVec2(px + 6.f, py - 6.f), IM_COL32(0, 0, 0, 180), ds);
            dl->AddText(ImVec2(px + 5.f, py - 7.f), IM_COL32(225, 230, 240, 220), ds);
        }
    }

    // --- Локальный игрок в центре: стрелка вверх ---
    dl->AddTriangleFilled(ImVec2(c.x, c.y - 7.f), ImVec2(c.x - 5.f, c.y + 5.f),
                          ImVec2(c.x + 5.f, c.y + 5.f), IM_COL32(90, 230, 130, 255));
    dl->AddTriangle(ImVec2(c.x, c.y - 7.f), ImVec2(c.x - 5.f, c.y + 5.f),
                    ImVec2(c.x + 5.f, c.y + 5.f), IM_COL32(0, 0, 0, 160), 1.2f);

    // Подпись радиуса в правом-нижнем углу виджета.
    {
        char rs[24]; snprintf(rs, sizeof(rs), "%.0fm", range);
        dl->AddText(ImVec2(c.x + R - 34.f, c.y + R - 16.f), IM_COL32(0,0,0,180), rs);
        dl->AddText(ImVec2(c.x + R - 35.f, c.y + R - 17.f), IM_COL32(150,170,200,200), rs);
    }
}


// функция обновления кэша игроков (Oxide)
void UpdatePlayerCache() {
    if (!(espdraw || aimm)) {
        cache_needs_update = true;
        return;
    }

    // UPDATE v15: убрано ожидание g_startupInProgress. UpdatePlayerCache
    // теперь стартует сразу; если klass ещё не резолвился — resolver внутри
    // фонового треда возьмёт его, а мы просто вернёмся с cache_needs_update.
    // Раньше пользователь ждал 2-3 мин пока фоновый резолвер добежит.
    if (!g_playerManagerKlass) {
        cache_needs_update = true;
        return;
    }

    oxlog::frameCounter++;
    bool full = oxlog::shouldLogFull();   // подробно — первые N кадров
    static int diag = 0;
    bool logNow = full || ((diag++ % 120) == 0); // ��альше — сводка раз в ~2c

    if (full) {
        oxlog::section("FRAME UpdatePlayerCache");
        OXLOGT("il2cpp_base=0x%llx screen=%dx%d",
               (unsigned long long)il2cpp_base, ::abs_ScreenX, ::abs_ScreenY);
    }

    // Ленивый резолв базы: игра могла ещё не загрузить libil2cpp.so на старте.
    if (!ox_ensureBase(full || logNow)) {
        if (logNow) OXLOGW("Ждём загрузку %s игрой... (base=0)", ox::MODULE);
        cache_needs_update = true;
        return;
    }

    // static_fields резолвим один раз �� кэшируем. При смене базы (перезапуск
    // игры / другой PID) кэ�� инвалидируется.
    static uint64_t statics_cached = 0;
    static uint64_t base_at_cache  = 0;
    static uint64_t listOff_cached = ~0ULL;
    if (base_at_cache != il2cpp_base) {
        base_at_cache = il2cpp_base;
        statics_cached = 0;
        listOff_cached = ~0ULL;
        g_playerManagerKlass = 0; // база сменилась (рестарт игры) — пере-резолв klass
        g_buildingPieceKlass = 0;
    }
    if (!statics_cached) statics_cached = ox_getStatics(full);
    if (!statics_cached) {
        if (logNow) OXLOGW("static_fields не резолвится (base=0x%llx)", (unsigned long long)il2cpp_base);
        cache_needs_update = true;
        return;
    }

    // Список игроков ищем авто-сканом; кэшируем найденный оффсет (см. выше).
    PlayerListView plist;
    if (listOff_cached != ~0ULL) {
        // Быстрый путь: пересчитываем по изв��стному оффсету.
        uint64_t c = rpm<uint64_t>(statics_cached + listOff_cached);
        int cnt, homo, checked; uint64_t elems; char cls[96];
        if (ox_evalContainer(c, elems, cnt, cls, sizeof(cls), homo, checked) && homo >= 2) {
            plist.ok = true; plist.elems = elems; plist.count = cnt;
            plist.container = c; plist.statOff = listOff_cached;
        } else {
            plist.ok = false; listOff_cached = ~0ULL; // сбросить — перескан
        }
    }
    if (!plist.ok) {
        plist = ox_scanForPlayerList(statics_cached, full || logNow);
        if (plist.ok) {
            listOff_cached = plist.statOff;
            oxlog::armFull(20); // список найден (в��шли в матч) — писать подробно 20 кадров
            full = oxlog::shouldLogFull();
        }
    }
    if (!plist.ok) { cache_needs_update = true; return; }

    uint64_t elems = plist.elems;
    int size = plist.count;

    // Дамп первых игроков — только в под��обных кадрах, для поиска оффсетов HP/позиции.
    if (full) {
        oxlog::section("PLAYER DUMP (offset discovery)");
        for (int i = 0; i < size && i < 2; i++) {
            uint64_t p = rpm<uint64_t>(elems + i * 8);
            if (ox_isPtr(p)) ox_dumpPlayer(i, p);
        }
    }

    CameraView cam = ox_getCamera(elems, size, full);

    std::vector<PlayerCacheData> new_cache;
    double sampleTime = ImGui::GetTime();
    int valid = 0;
    int checkedHP = 0, skippedHP = 0, skippedPos = 0, skippedLocal = 0, skippedTeam = 0, skippedVis = 0;

    if (full) oxlog::section("PLAYER SCAN");

    for (int i = 0; i < size; i++) {
        uint64_t player = rpm<uint64_t>(elems + i * 8);
        if (!ox_isPtr(player)) continue;

        float hp = ox_readHP(player, full && i < 2);
        checkedHP++;
        if (hp < ox::HP_MIN || hp > ox::HP_MAX) {
            skippedHP++;
            if (full && i < 8) OXLOGT("player[%d]=0x%llx откинут: hp=%.2f вне [%.0f..%.0f]",
                                      i, (unsigned long long)player, hp, ox::HP_MIN, ox::HP_MAX);
            continue;
        }

        Vector3 pos = ox_readPos(player, full && i < 2);
        if (pos == Vector3::Zero()) { skippedPos++; continue; }

        // Себя не рисуем. Основной критерий — прямой флаг Mirror:
        // NetworkBehaviour.netIdentity(0x40).isLocalPlayer(0x4A). Он не зависит
        // от того, успел ли ox_getCamera выбрать владельца, поэтому свой бокс
        // не мелькает в первые кадры матча. Сверка по указателю оставлена
        // вторым условием на случай, если netIdentity ещё не привязан.
        {
            bool isSelf = (player == g_localPlayer);
            if (!isSelf) {
                uint64_t ni = rpm<uint64_t>(player + ox::NB_NET_IDENTITY);
                if (ox_isPtr(ni) && rpm<uint8_t>(ni + ox::NI_IS_LOCAL_PLAYER) != 0)
                    isSelf = true;
            }
            if (isSelf) { skippedLocal++; continue; }
        }

        // FIX bug #2: стабильный team-key (raw UTF-16 teamName / pf.teamId / pf-ptr).
        // pf-указатель как fallback — все тимейты имеют один shared pf, разные — разные pf.
        std::string teamKey = ox_teamKey(player);
        // Диагностика: первые 4 игрока за проход логируем team-ключ (одна строка).
        if (full && checkedHP < 4) {
            OXLOGI("[team] player[%d]=0x%llx teamKey='%s' localKey='%s' match=%d",
                   checkedHP, (unsigned long long)player,
                   teamKey.c_str(), g_localTeamName.c_str(),
                   (int)(!g_localTeamName.empty() && !teamKey.empty() && teamKey == g_localTeamName));
        }
        // Скрытие тимейтов: сначала прямая проверка по составу команды
        // (не зависит от строковых полей), затем сравнение team-ключей.
        bool isMate = ox_isTeammate(g_localPlayer, player) ||
                      (!g_localTeamName.empty() && !teamKey.empty() &&
                       teamKey == g_localTeamName);
        if (espHideTeammates && isMate) {
            skippedTeam++;
            continue;
        }

        PlayerCacheData data{};
        data.address = player;
        data.health  = (int)hp;
        data.armor   = 0;
        data.teamId  = 0;
        data.position = pos;
        data.sampledPosition = pos;
        data.sampleTime = sampleTime;
        data.teamName = teamKey;   // хранит team-key для aimbot-фильтра
        data.velocity = Vector3::Zero();

        for (const PlayerCacheData& previous : cached_players) {
            if (previous.address != player) continue;
            double dt = sampleTime - previous.sampleTime;
            if (dt > 0.01 && dt < 2.0) {
                Vector3 measured = (pos - previous.sampledPosition) / (float)dt;
                float speed = measured.magnitude();
                if (isfinite(speed) && speed <= 30.0f)
                    data.velocity = previous.velocity * 0.65f + measured * 0.35f;
            }
            break;
        }
        data.distance = cam.valid ? Vector3::Distance(cam.pos, pos) : 0.f;

        // Огромный радиус по умолчанию (5000 м). 0 = вообще без лимита.
        if (espMaxDistance > 0.f && data.distance > espMaxDistance) { skippedVis++; continue; }

        w2sLogDetail = (full && valid < 3); // детальная трассировка для первых целей
        // pos = уровень глаз/головы → низ бокса опускаем к ногам, верх чуть выше макушки.
        // espBoxYOffset — живая вертикальная привязка (см. комментарий у глобала).
        Vector3 anchor = pos + Vector3(0.f, ox_boxYOffset(), 0.f);
        data.w2sBottom = w2s_angular(anchor - Vector3(0, ox::BOX_FOOT, 0), cam, &data.isVisibleBottom);
        data.w2sTop    = w2s_angular(anchor + Vector3(0, ox::BOX_HEAD, 0), cam, &data.isVisibleTop);
        w2sLogDetail = false;

        // Расширенные данные — читаем в тяжёлом скане (раз в g_cacheInterval
        // кадров), не каждый кадр: цепочки длинные, а меняются они редко.
        data.name   = espname   ? ox_readNickname(player)   : std::string();
        data.weapon = espweapon ? ox_readWeaponName(player) : std::string();
        data.armor  = (int)ox_readArmor(player);
        OxPlayerFlags pf = ox_readPlayerFlags(player);
        data.flagSleeping   = pf.sleeping;
        data.flagSpectating = pf.spectating;
        data.flagPrime      = pf.prime;
        data.viewPtr = 0;
        data.hasSkeletonData = false;

        if (logNow && valid < 5)
            OXLOGI("ЦЕЛЬ[%d]=0x%llx hp=%.0f pos=(%.2f,%.2f,%.2f) dist=%.1f visB=%d visT=%d w2sB=(%.0f,%.0f) w2sT=(%.0f,%.0f)",
                   i, (unsigned long long)player, hp, pos.x, pos.y, pos.z, data.distance,
                   (int)data.isVisibleBottom, (int)data.isVisibleTop,
                   data.w2sBottom.x, data.w2sBottom.y, data.w2sTop.x, data.w2sTop.y);

        // 360° counter fix: НЕ отсеиваем игроков вне frustum'а. Просто помечаем
        // visibility, downstream ESP-render сам скипнет отрисовку если оба
        // isVisibleBottom/Top=false. Счётчик g_enemyCount теперь считает ВСЕХ
        // живых игроков в матче, не только тех кого мы видим.
        new_cache.push_back(data);
        valid++;
    }

    if (logNow)
        OXLOGI("ИТОГ: static+0x%llx elems=0x%llx count=%d camValid=%d | проверено HP=%d, откинуто(hp=%d,pos=%d,local=%d,team=%d,vis=%d) -> целей=%d",
               (unsigned long long)plist.statOff, (unsigned long long)elems, size,
               (int)cam.valid, checkedHP, skippedHP, skippedPos, skippedLocal, skippedTeam, skippedVis, valid);

    {
        std::lock_guard<std::mutex> lock(player_data_mutex);
        cached_players = std::move(new_cache);
        cache_needs_update = false;
        g_enemyCount = (int)cached_players.size();
    }
}

// ============================================================================
//  Стартовый диагностический дамп. Пишется в файл лога
//  (/sdcard/Download/eclips_oxide_<время>.log) ОДИН раз при запуске,
//  НЕЗАВИСИМО от verbose-режима меню (oxlog::enabled по умолчанию true).
//  Содержит всё для отладки оффсетов после апдейта игры: версию
//  il2cpp-метаданных, базы модулей, результат авто-резолва TypeInfo
//  и полную таблицу оффсетов из oxide_offsets.h.
// ============================================================================

// Лёгкий пробник версии метаданных: находит первый валидный заголовок
// 0xFAB11BAF и возвращает version/size БЕЗ копирования blob в файл.
static bool ox_probeMetadataVersion(uint32_t &outVersion, size_t &outSize) {
    outVersion = 0; outSize = 0;
    if (game_pid <= 0) return false;
    std::vector<OxMapRange> maps;
    ox_collectMetadataMaps(maps, 1024ULL * 1024 * 1024);
    const size_t chunkSize = 1024 * 1024;
    std::vector<uint8_t> buffer(chunkSize + 4);
    for (const OxMapRange &map : maps) {
        size_t carry = 0;
        for (uint64_t at = map.start; at < map.end;) {
            size_t want = (size_t)std::min<uint64_t>(chunkSize, map.end - at);
            if (!vm_readv(at, buffer.data() + carry, want)) { carry = 0; at += want; continue; }
            size_t total = carry + want;
            for (size_t i = 0; i + sizeof(uint32_t) <= total; i += sizeof(uint32_t)) {
                uint32_t magic = 0;
                memcpy(&magic, buffer.data() + i, sizeof(magic));
                if (magic != IL2CPP_METADATA_MAGIC) continue;
                uint64_t candidate = at - carry + i;
                size_t sz = 0; uint32_t ver = 0;
                if (ox_validateMetadataHeader(candidate, map.end, sz, ver)) {
                    outVersion = ver; outSize = sz;
                    return true;
                }
            }
            carry = std::min(sizeof(uint32_t) - 1, total);
            memmove(buffer.data(), buffer.data() + total - carry, carry);
            at += want;
        }
    }
    return false;
}

static void ox_logStartupDiagnostics() {
    oxlog::section("STARTUP DIAGNOSTICS");
    OXLOGI("build: %s %s", __DATE__, __TIME__);
    OXLOGI("package=%s module=%s native=%s", ox::PACKAGE, ox::MODULE, ox::MODULE_NATIVE);
    OXLOGI("game_pid=%d libil2cpp_mapped=%s", game_pid,
           (game_pid > 0 && pidHasModule(game_pid, ox::MODULE)) ? "yes" : "no");

    // --- Базы модулей ---
    if (!ox_ensureBase(true))
        OXLOGW("il2cpp base ещё не готова (игра догрузит либу) — будет до-резолв в кадре");
    OXLOGI("il2cpp_base = 0x%llx", (unsigned long long)il2cpp_base);
    uint64_t nativeBase = get_module_base_real(ox::MODULE_NATIVE);
    OXLOGI("%s base = 0x%llx", ox::MODULE_NATIVE, (unsigned long long)nativeBase);

    // --- Версия il2cpp метаданных (лёгкий пробник, без дампа файла) ---
    uint32_t metaVer = 0; size_t metaSize = 0;
    if (ox_probeMetadataVersion(metaVer, metaSize))
        OXLOGI("il2cpp metadata: version=%u size=%zu (0x%zx)", metaVer, metaSize, metaSize);
    else
        OXLOGW("il2cpp metadata header не найден (зашифрован/ещё не расшифрован)");

    // --- Авто-резолв TypeInfo (перекрывает fallback из хедера) ---
    OXLOGI("TypeInfo fallback из хедера: PM=0x%llx BP=0x%llx PV=0x%llx",
           (unsigned long long)ox::PLAYERMANAGER_TYPEINFO,
           (unsigned long long)ox::BUILDINGPIECE_TYPEINFO,
           (unsigned long long)ox::PLAYERVITALS_TYPEINFO);
    if (il2cpp_base) {
        bool ok = ox_autoResolveTypeInfos(true);
        OXLOGI("TypeInfo auto-resolve: %s -> PM=0x%llx BP=0x%llx",
               ok ? "OK" : "PARTIAL/FAIL",
               (unsigned long long)g_playerManagerTypeInfoRVA,
               (unsigned long long)g_buildingPieceTypeInfoRVA);
    } else {
        OXLOGW("TypeInfo auto-resolve пропущен: нет il2cpp base");
    }

    // --- Полная таблица оффсетов из oxide_offsets.h ---
    oxlog::section("OFFSETS TABLE (oxide_offsets.h)");
    #define OXDUMP(name) OXLOGI("  %-24s = 0x%llx", #name, (unsigned long long)ox::name)
    OXDUMP(CLASS_STATIC_FIELDS); OXDUMP(STATIC_ACTIVE_LIST); OXDUMP(STATIC_BUILDING_SAVELIST);
    OXDUMP(CLASS_NAME); OXDUMP(CLASS_NAMESPACE);
    OXDUMP(LIST_ITEMS); OXDUMP(LIST_SIZE); OXDUMP(ARRAY_COUNT); OXDUMP(ARRAY_DATA);
    OXDUMP(PM_TRANSFORM); OXDUMP(PM_MOUSELOOK); OXDUMP(PM_RAYCASTMANAGER);
    OXDUMP(PM_IS_LOCAL_PLAYER); OXDUMP(PM_VITALS); OXDUMP(PM_TEAM_ID); OXDUMP(PM_TEAM_NAME);
    OXDUMP(ML_ANGLES); OXDUMP(ML_LOOKROOT); OXDUMP(ML_PITCH); OXDUMP(ML_YAW);
    OXDUMP(RM_WORLD_CAMERA); OXDUMP(RM_RAY_LENGTH); OXDUMP(RM_AIM_RAY_LENGTH);
    OXDUMP(RM_LAYER_MASK); OXDUMP(RM_AIM_LAYER_MASK);
    OXDUMP(VITALS_HEALTH);
    OXDUMP(OBJ_CACHED_PTR); OXDUMP(TR_INT_MATRIXPTR); OXDUMP(TR_MATRIX_WORLDPOS);
    OXDUMP(TR_MATRIX_ROT); OXDUMP(TR_MATRIX_SCALE);
    OXDUMP(BP_CORRECT_POSITION); OXDUMP(BP_BOUNDS); OXDUMP(BP_CORRECT_ROTATION);
    OXDUMP(BP_ADDITIONAL_BOUNDS); OXDUMP(BP_M_GRADE); OXDUMP(BP_GRADE_HOLDER);
    OXDUMP(BP_PIECE_NAME); OXDUMP(BP_ID); OXDUMP(BP_HEALTH); OXDUMP(BP_MAXHEALTH);
    #undef OXDUMP

    // Полный runtime-sweep всех известных TypeInfo — 11 классов ×
    // ox_findAscii+ox_scanClassByName по writable/anon памяти. При стабильной
    // шапке это чистый лаг; включается только под OX_DEEP_DIAG (при апдейте
    // libil2cpp.so, когда действительно нужны свежие RVA).
#if OX_DEEP_DIAG
    if (il2cpp_base) ox_sweepAllTypeInfos(true);
    else OXLOGW("[sweep] пропущен: il2cpp_base ещё не готова");
#else
    OXLOGI("[sweep] пропущен (OX_DEEP_DIAG=0). Включить: -DOX_DEEP_DIAG=1");
#endif

    OXLOGI("STARTUP DIAGNOSTICS завершён");
}

// UPDATE 2026/07/31: SIGSEGV/SIGBUS handler.
// Причина: на Android 16 (API 36) private SurfaceFlinger символы, которые
// dlsym'ит ANativeWindowCreator, часто возвращают null или указывают в
// удалённую .so — вызов ловит SIGSEGV до вывода первого printf. Без хендлера
// процесс просто исчезает, лог обрывается на последней успешной строке.
// Хендлер печатает адрес фолта + короткий backtrace через glibc-совместимую
// функцию unw_step (или fallback — просто фрейм-указатели), потом
// _exit(139). Восстанавливать процесс НЕ пытаемся — там уже несогласованное
// состояние ImGui/EGL.
// bionic не имеет execinfo.h/backtrace — печатаем regs + fp-walk вручную.
#include <signal.h>
#include <ucontext.h>
static void ox_signal_handler(int sig, siginfo_t *info, void *ucontext_v) {
    OXLOGE("!!!!!!!!!! ФАТАЛЬНЫЙ СИГНАЛ %d !!!!!!!!!!", sig);
    OXLOGE("si_code=%d si_addr=0x%llx", info->si_code, (unsigned long long)info->si_addr);
    if (ucontext_v) {
        ucontext_t *uc = (ucontext_t *)ucontext_v;
#if defined(__aarch64__)
        OXLOGE("PC=0x%llx  LR=0x%llx  SP=0x%llx  FP=0x%llx",
               (unsigned long long)uc->uc_mcontext.pc,
               (unsigned long long)uc->uc_mcontext.regs[30],
               (unsigned long long)uc->uc_mcontext.sp,
               (unsigned long long)uc->uc_mcontext.regs[29]);
        for (int i = 0; i < 30; i += 4) {
            OXLOGE("X%d=0x%llx  X%d=0x%llx  X%d=0x%llx  X%d=0x%llx",
                   i,   (unsigned long long)uc->uc_mcontext.regs[i],
                   i+1, (unsigned long long)uc->uc_mcontext.regs[i+1],
                   i+2, (unsigned long long)uc->uc_mcontext.regs[i+2],
                   i+3, (unsigned long long)uc->uc_mcontext.regs[i+3]);
        }
#endif
    }
    // Frame-pointer walk (AArch64: FP=x29, каждый фрейм: [FP]=next_fp, [FP+8]=LR).
#if defined(__aarch64__)
    if (ucontext_v) {
        ucontext_t *uc = (ucontext_t *)ucontext_v;
        uint64_t fp = uc->uc_mcontext.regs[29];
        uint64_t lr = uc->uc_mcontext.regs[30];
        Dl_info dl;
        if (dladdr((void*)lr, &dl) && dl.dli_fname) {
            OXLOGE("  #0 (LR): 0x%llx  %s+0x%llx  (%s+0x%llx)",
                   (unsigned long long)lr,
                   dl.dli_sname ? dl.dli_sname : "?",
                   (unsigned long long)((char*)lr - (char*)dl.dli_saddr),
                   dl.dli_fname,
                   (unsigned long long)((char*)lr - (char*)dl.dli_fbase));
        }
        for (int i = 1; i < 20 && fp != 0; i++) {
            uint64_t next_fp, ret_lr;
            // fp может быть уже мусорной — оборачиваем в try (в реальности просто читаем)
            next_fp = *(uint64_t*)(fp);
            ret_lr  = *(uint64_t*)(fp + 8);
            Dl_info di;
            if (dladdr((void*)ret_lr, &di) && di.dli_fname) {
                OXLOGE("  #%d: 0x%llx  %s+0x%llx  (%s+0x%llx)",
                       i, (unsigned long long)ret_lr,
                       di.dli_sname ? di.dli_sname : "?",
                       (unsigned long long)((char*)ret_lr - (char*)di.dli_saddr),
                       di.dli_fname,
                       (unsigned long long)((char*)ret_lr - (char*)di.dli_fbase));
            } else {
                OXLOGE("  #%d: LR=0x%llx  (unresolved)", i, (unsigned long long)ret_lr);
            }
            if (next_fp <= fp || (next_fp - fp) > 0x10000) break;
            fp = next_fp;
        }
    }
#endif
    oxlog::shutdown();
    _exit(128 + sig);
}

static void ox_install_signal_handlers() {
    struct sigaction sa = {};
    sa.sa_sigaction = ox_signal_handler;
    sa.sa_flags = SA_SIGINFO | SA_RESTART;
    sigemptyset(&sa.sa_mask);
    sigaction(SIGSEGV, &sa, nullptr);
    sigaction(SIGBUS,  &sa, nullptr);
    sigaction(SIGILL,  &sa, nullptr);
    sigaction(SIGFPE,  &sa, nullptr);
    sigaction(SIGABRT, &sa, nullptr);
}

int main(int argc, char *argv[]) {
    oxlog::init();
    ox_install_signal_handlers();
    oxlog::section("STARTUP");
    OXLOGI("Eclips Oxide запущен, uid=%d, pid=%d", (int)getuid(), (int)getpid());
    OXLOGI("SIGSEGV/SIGBUS/SIGILL/SIGFPE/SIGABRT handlers установлены");

    // UPDATE 2026/07/31: подробный boot-лог по запросу erafox.
    // Дампит все ключевые offsets/RVA/TDI сразу, чтобы можно было удалённо
    // диагностировать без включения debug-мода из меню.
    OXLOGI("========== ECLIPS OXIDE BUILD INFO ==========");
    OXLOGI("build:              %s %s", __DATE__, __TIME__);
    OXLOGI("target package:     %s", ox::PACKAGE);
    OXLOGI("target module:      %s", ox::MODULE);
    OXLOGI("expected md5:       libil2cpp 14666f83c1e3ef41d98fb8f319244125");
    OXLOGI("expected md5:       metadata  d3edbbb5055ec351cc2644dc9d3fb430");
    OXLOGI("build date OF DUMP: 2026-07-31 (arm64 slice)");
    OXLOGI("");
    OXLOGI("========== METADATA OFFSETS (updated) ==========");
    OXLOGI("STR (stringOffset):         0xE5FD4   (was 0xDC0EC)");
    OXLOGI("TD_OFF (typeDefinitions):   0x1533A04 (was 0x1517BA0)");
    OXLOGI("TD_COUNT:                   29697     (was 29486)");
    OXLOGI("TD_REC size:                82 bytes  (unchanged)");
    OXLOGI("XOR key:                    0x%08X (unchanged)", OX_META_XOR_KEY);
    OXLOGI("");
    OXLOGI("========== TDI (обновлено под 2026-07-31) ==========");
    OXLOGI("PLAYERMANAGER   TDI=%u  (was 8357)", OX_TDI_PLAYERMANAGER);
    OXLOGI("BUILDINGPIECE   TDI=%u  (was 8633)", OX_TDI_BUILDINGPIECE);
    OXLOGI("PLAYERVITALS    TDI=%u  (was 8030)", OX_TDI_PLAYERVITALS);
    OXLOGI("NETWORKCLIENT   TDI=%u  (was 23916)", OX_TDI_NETWORKCLIENT);
    OXLOGI("TYPEDEF_COUNT   =%u    (was 29486)", OX_TYPEDEF_COUNT);
    OXLOGI("");
    OXLOGI("========== TYPES_ARRAY (metadataRegistration.types) ==========");
    OXLOGI("IL2CPP_TYPES_RVA:           0x%llx (was 0xB75E020)",
           (unsigned long long)ox::IL2CPP_TYPES_RVA);
    OXLOGI("types_count:                105268    (was 104776)");
    OXLOGI("");
    OXLOGI("========== TYPEINFO byval-indexes ==========");
    OXLOGI("PLAYERMANAGER   idx=%d", ox::PLAYERMANAGER_TYPEINFO_TYPEIDX);
    OXLOGI("BUILDINGPIECE   idx=%d", ox::BUILDINGPIECE_TYPEINFO_TYPEIDX);
    OXLOGI("PLAYERVITALS    idx=%d", ox::PLAYERVITALS_TYPEINFO_TYPEIDX);
    OXLOGI("RAYCASTMANAGER  idx=%d", ox::RAYCASTMANAGER_TYPEINFO_TYPEIDX);
    OXLOGI("MOUSELOOK       idx=%d", ox::MOUSELOOK_TYPEINFO_TYPEIDX);
    OXLOGI("CAMERA          idx=%d", ox::CAMERA_TYPEINFO_TYPEIDX);
    OXLOGI("ENTITYVITALS    idx=%d", ox::ENTITYVITALS_TYPEINFO_TYPEIDX);
    OXLOGI("GENERICVITALS   idx=%d", ox::GENERICVITALS_TYPEINFO_TYPEIDX);
    OXLOGI("NETWORKCLIENT   idx=%d", ox::NETWORKCLIENT_TYPEINFO_TYPEIDX);
    OXLOGI("");
    OXLOGI("========== METADATA NAME OFFSETS (name-scan fallback) ==========");
    OXLOGI("PlayerManager   @0x%llx", (unsigned long long)OX_META_NAME_OFF_PLAYERMANAGER);
    OXLOGI("BuildingPiece   @0x%llx", (unsigned long long)OX_META_NAME_OFF_BUILDINGPIECE);
    OXLOGI("PlayerVitals    @0x%llx", (unsigned long long)OX_META_NAME_OFF_PLAYERVITALS);
    OXLOGI("");
    OXLOGI("========== FAST-SEED RVA (NOT UPDATED — expect fallback) ==========");
    OXLOGI("OX_META_MC_RVA:              0x%llx (stale, from 2026-07-25)", (unsigned long long)OX_META_MC_RVA);
    OXLOGI("OX_META_BASE_PTR_RVA:        0x%llx", (unsigned long long)OX_META_BASE_PTR_RVA);
    OXLOGI("OX_META_HEADER_PTR_RVA:      0x%llx", (unsigned long long)OX_META_HEADER_PTR_RVA);
    OXLOGI("OX_META_STRIDE_RVA:          0x%llx", (unsigned long long)OX_META_STRIDE_RVA);
    OXLOGI("OX_S_TYPEINFO_TABLE_RVA:     0x%llx", (unsigned long long)OX_S_TYPEINFO_TABLE_RVA);
    OXLOGI("Если fast-seed вернёт null → сработает name-scan (медленнее, но рабочий)");
    OXLOGI("");
    OXLOGI("========== LOG SETTINGS ==========");
    OXLOGI("oxlog::enabled  = %d", (int)oxlog::enabled);
    OXLOGI("oxlog::verbose  = %d (первые %d кадров пишем hex-дампы)",
           (int)oxlog::verbose, 300 /*FULL_LOG_FRAMES*/);
    OXLOGI("log directory   = %s", oxlog::activeDir());
    OXLOGI("log file        = %s", "eclips_oxide_YYYYMMDD_HHMMSS.log");
    OXLOGI("logcat tag      = EclipsOxide  (adb logcat -s EclipsOxide)");
    OXLOGI("=============================================");

	// Предпочитаем ГЛАВНЫЙ процесс (где замаплен libil2cpp.so), а не сервисный.
	game_pid = getGameProcessID(ox::PACKAGE, ox::MODULE);
	if (game_pid <= 0) game_pid = getProcessID(ox::PACKAGE); // fallback: любой совпавший
	if (game_pid <= 0) {
		OXLOGW("Игра пока не запущена: %s", ox::PACKAGE);
		printf("Waiting for Oxide to start: %s\n", ox::PACKAGE);
		fflush(stdout);
		while (main_thread_flag && game_pid <= 0) {
			sleep(1);
			game_pid = getGameProcessID(ox::PACKAGE, ox::MODULE);
			if (game_pid <= 0) game_pid = getProcessID(ox::PACKAGE);
		}
		if (!main_thread_flag) return -1;
		OXLOGI("Игра найдена после ожидания, pid=%d", game_pid);
	}
	OXLOGI("PID игры '%s' = %d (%s libil2cpp)", ox::PACKAGE, game_pid,
	       pidHasModule(game_pid, ox::MODULE) ? "есть" : "пока нет");

    screen_config();
    ::abs_ScreenX = (displayInfo.height > displayInfo.width ? displayInfo.height : displayInfo.width);
    ::abs_ScreenY = (displayInfo.height < displayInfo.width ? displayInfo.height : displayInfo.width);
    OXLOGI("Экран: raw %dx%d, ориентация=%d -> abs %dx%d",
           displayInfo.width, displayInfo.height, displayInfo.orientation,
           ::abs_ScreenX, ::abs_ScreenY);
    
    ::native_window_screen_x = (displayInfo.height > displayInfo.width ? displayInfo.height : displayInfo.width);
    ::native_window_screen_y = (displayInfo.height < displayInfo.width ? displayInfo.height : displayInfo.width);
    
    // UPDATE 2026/07/31: подробный лог ПЕРЕД GUI init — если крашнется в
    // ANativeWindowCreator (private SurfaceFlinger API, ломается на Android 16),
    // хотя бы будет видно куда дошли.
    OXLOGI("========== GUI INIT ==========");
    OXLOGI("native_window_screen: %dx%d", (int)native_window_screen_x, (int)native_window_screen_y);
    OXLOGI("orientation: %d", (int)displayInfo.orientation);
    OXLOGI("вызываю initGUI_draw(...) — если далее ЛОГА НЕТ, значит крашнуло в");
    OXLOGI("ANativeWindowCreator::Create (dlsym'ы private SurfaceFlinger). На");
    OXLOGI("Android 16 (API 36) многие эти символы уже блокированы SELinux/APEX.");
    OXLOGI("Fixes: (a) обновить ANativeWindowCreator под libgui.so от Android 16,");
    OXLOGI("       (b) собрать под USE_VULKAN и через VkSurfaceKHR обойти SF,");
    OXLOGI("       (c) запустить в BlueStacks 5 (там Android 11 — работает).");
    if (!initGUI_draw(native_window_screen_x, native_window_screen_y, true)) {
        OXLOGE("Не удалось создать окно или инициализировать ImGui/EGL");
        OXLOGE("Скорее всего ANativeWindowCreator::Create вернул null-символ через dlsym.");
        OXLOGE("Проверь /sdcard/Download/EclipsOxide/*.log до этого места и addr2line на бинарнике.");
        fprintf(stderr, "ERROR: overlay initialization failed (window, EGL, or ImGui)\n");
        return -1;
    }
    OXLOGI("initGUI_draw ok — окно, EGL, ImGui поднялись");
    
    if (!InitLua()) {
        printf("Failed to init Lua\n");
    }

	// RVA из script.json отсчитываются от базы модуля = самый нижний маппинг (ELF header).
	// Пробуем сразу; если игра ещё не подгрузила либу — база до-резолвится в цикле (ox_ensureBase).
	oxlog::section("MODULE BASE");
	il2cpp_base = get_module_base_real(ox::MODULE);
	OXLOGI("%s стартовая база = 0x%llx%s", ox::MODULE,
	       (unsigned long long)il2cpp_base,
	       il2cpp_base ? "" : " (пока не загруж��н — дождёмся в цикле)");
	if (!il2cpp_base) dump_maps_matching("il2cpp", 12);

    // Логи, dump метадаты и всё что чит пишет наружу — в одну папку.
    OXLOGI("Артефакты в: %s", oxlog::activeDir());

    Touch_Init(displayInfo.width, displayInfo.height, displayInfo.orientation, true);

    // Полный стартовый диагностический дамп + TypeInfo auto-resolve вынесены в
    // фоновый поток, чтобы главный цикл рендера запустился с первого кадра, а
    // меню появилось сразу — до этой правки клиент подвисал минуты на сканах
    // памяти (см. лог erafox: обрывался на "TypeInfo fallback из хедера: ...").
    //
    // Второе издание: после первой полной диагностики поток НЕ выходит, а спит
    // 20 сек и повторяет auto-resolve пока хоть один класс не нашёлся. Это
    // покрывает кейс «чит запущен раньше входа в матч»: в лобби IL2Cpp lazy-load
    // ещё не тронул PlayerManager, строк в памяти нет — но как только игрок
    // зайдёт в матч и Unity создаст класс, следующий проход через 20 сек его
    // подхватит, чит не надо перезапускать. Максимум 45 попыток ≈ 15 мин.
    if (!g_startupThreadStarted.exchange(true)) {
        std::thread([](){
            g_startupInProgress = true;
            ox_setStartupStatus("startup diagnostics...");
            OXLOGI("[startup] фоновая диагностика стартовала (thread)");

            // UPDATE 2026/07/31 v15: МАКСИМАЛЬНО агрессивный старт по требованию.
            // - g_startupInProgress ставим в false СРАЗУ, чтобы UpdatePlayerCache
            //   мог начать работу как только классы появятся — не ждёт нас.
            // - первые 20 попыток БЕЗ паузы (packed retry) — если классы уже готовы
            //   (обычно в лобби/матче), поймаем за ~200-500 мс всё.
            // - 20-100 попыток — по 100 мс (10 попыток в секунду).
            // - 100+ — по 500 мс.
            // Резолвер (ox_fastSeedTypeInfoFromHeader → ox_resolveKlassRobust) сам
            // делает кэш при успехе, повторные проходы дешёвые.
            ox_setStartupStatus("resolving classes...");
            g_startupInProgress = false;   // разрешаем UpdatePlayerCache работать сразу
            const int MAX_TRIES = 6000;    // long-tail retry — 30 мин если надо
            for (int i = 0; i < MAX_TRIES; ++i) {
                if (!main_thread_flag) { OXLOGI("[startup] прерван"); break; }
                if (ox_fastSeedTypeInfoFromHeader()) {
                    OXLOGI("[startup] РЕЗОЛВ OK на попытке #%d (PM=0x%llx BP=0x%llx)",
                           i,
                           (unsigned long long)g_playerManagerKlass,
                           (unsigned long long)g_buildingPieceKlass);
                    ox_setStartupStatus("ready");
                    g_startupInProgress = false;
                    g_startupDone = true;
                    return;
                }
                if (i > 0 && i % 100 == 0) {
                    OXLOGI("[startup] жду Class::Init: %d попыток", i);
                }
                // Cadence: жёстко без пауз первые 20, потом 100мс, потом 500мс.
                if (i < 20)      { /* без паузы */ }
                else if (i < 100) usleep(100 * 1000);
                else              usleep(500 * 1000);
            }
            OXLOGW("[startup] fast-seed не сработал за %d попыток. Классы не найдены.", MAX_TRIES);
            ox_setStartupStatus("failed (Class::Init не прогнан)");
            g_startupInProgress = false;
            g_startupDone = true;
            return;
            // === СТАРАЯ scan-based ветка отключена: убивает игру ===
            /*
            ox_setScanDeadline(90);
            ox_logStartupDiagnostics();
            ox_clearScanDeadline();
            g_startupInProgress = false;

            // Если TypeInfo сразу нашлись — работа окончена.
            if (g_playerManagerKlass || g_buildingPieceKlass) {
                ox_setStartupStatus("ready");
                g_startupDone = true;
                OXLOGI("[startup] TypeInfo найдены с первого прохода");
                return;
            }

            // Иначе входим в цикл повторных попыток. UpdatePlayerCache
            // продолжает работать (мы вышли из g_startupInProgress),
            // просто до успеха он видит g_playerManagerKlass=0 и не пытается
            // читать статики. Меню при этом полностью функционально.
            const int MAX_RETRIES = 45;
            const int SLEEP_SEC   = 20;
            for (int attempt = 1; attempt <= MAX_RETRIES; ++attempt) {
                if (!main_thread_flag) { OXLOGI("[startup] main остановлен, retry-loop выходит"); break; }
                for (int i = 0; i < SLEEP_SEC && main_thread_flag; ++i) sleep(1);
                if (!main_thread_flag) break;

                char buf[96];
                snprintf(buf, sizeof(buf), "retry TypeInfo (%d/%d)...", attempt, MAX_RETRIES);
                ox_setStartupStatus(buf);
                OXLOGI("[startup] retry #%d/%d (жду входа в матч)", attempt, MAX_RETRIES);

                g_startupInProgress = true;
                ox_setScanDeadline(60);
                ox_autoResolveTypeInfos(false);   // full=false — тихий лог, без hex-дампов
                ox_clearScanDeadline();
                g_startupInProgress = false;

                if (g_playerManagerKlass || g_buildingPieceKlass) {
                    ox_setStartupStatus("ready (found on retry)");
                    g_startupDone = true;
                    OXLOGI("[startup] TypeInfo найдены на retry #%d: PM=0x%llx BP=0x%llx",
                           attempt,
                           (unsigned long long)g_playerManagerKlass,
                           (unsigned long long)g_buildingPieceKlass);
                    return;
                }
            }
            // Все попытки исчерпаны — сдаёмся, но клиент продолжает работать
            // (меню, dump кнопка). Пользователь может пере-запустить чит уже
            // из матча.
            ox_setStartupStatus("no match yet (retry exhausted)");
            g_startupDone = true;
            OXLOGW("[startup] %d попыток исчерпано — TypeInfo так и не нашлись. "
                   "Зайди в матч и перезапусти чит.", MAX_RETRIES);
            */
            // === конец отключённой scan-based ветки ===
        }).detach();
    }

    while (main_thread_flag) {
        // --- Вотчдог: игра закрыта (процесс игры мёртв) → снести оверлей и выйти ---
        //  kill(pid,0) == -1 && errno==ESRCH означает «процесс больше не существует».
        //  Респавн игру НЕ убивает (pid тот же), так что ложных выходов нет — только
        //  реальное закрытие игры. Проверяем раз в ~15 кадров (дёшево).
        {
            static int s_wdCounter = 0;
            if (++s_wdCounter >= 15) {
                s_wdCounter = 0;
                if (game_pid > 0 && kill(game_pid, 0) != 0 && errno == ESRCH) {
                    OXLOGW("[watchdog] процесс игры pid=%d мёртв — закрываю оверлей и выхожу", game_pid);
                    main_thread_flag = false;
                    break;   // выход из цикла → shutdown() уничтожит окно → return 0 → процесс завершится
                }
            }
        }
        drawBegin();
        Layout_tick_UI();
        
        ExecuteLuaScripts();
        
        // обновляем кэш только раз в N кадров (интервал регулируется в меню)
        bool cacheUpdatedThisFrame = false;
        // Bug D FIX (respawn drift): если локальный PM протух между обновлениями
        // кэша (респавн + новый PM), форсируем refresh чтобы не строить камеру
        // из мусорной памяти старого умершего PM.
        bool localStale = g_localPlayer && !ox_localPlayerStillValid();
        if (localStale) {
            OXLOGI("[respawn] локальный PM протух между кадрами — форсирую cache refresh");
            g_localPlayer = 0;
            g_localTeamName.clear();
            cache_needs_update = true;
        }
        if (cache_needs_update || (ImGui::GetFrameCount() - last_cache_frame > g_cacheInterval)) {
            UpdatePlayerCache();
            last_cache_frame = ImGui::GetFrameCount();
            // UPDATE 2026/07/31 v16: НАСТОЯЩИЙ ФИКС "боксы застряли на спавне".
            // РАНЬШЕ: cacheUpdatedThisFrame=true ставилось всегда после UpdatePlayerCache,
            // даже если тот сразу вернулся (klass не готов / plist пуст). Тогда
            // refreshPositions=false → позиции игроков НЕ перечитывались каждый
            // кадр → бокс рисовался на СТАРОЙ позиции (например точке спавна где
            // сработал первый рендер). Ровно симптом пользователя.
            // ТЕПЕРЬ: помечаем только если кэш РЕАЛЬНО обновился (cache_needs_update
            // сбрасывается в false в конце удачного UpdatePlayerCache). Иначе
            // refreshPositions=true → пере-читаем ox_readPos(player.address)
            // каждый кадр → бокс идёт за игроком.
            cacheUpdatedThisFrame = !cache_needs_update;
        }

        // LOS-кэш построек — раз в BUILDING_CACHE_INTERVAL кадров (тяжёлый скан
        // статических полей BuildingPiece.saveList). Нужен и для ESP (цвет), и
        // для aimbot (фильтрация через стену).
        if (aimCheckWalls || espColorByVisibility) {
            ox_updateBuildingCache(oxlog::shouldLogFull());
        }
        
        // рисуем ESP из кэша
        if (espdraw || aimm) {
            std::lock_guard<std::mutex> lock(player_data_mutex);
            ImGui::PushFont(verdana);

            // Камеру пересчитываем КАЖДЫЙ кадр из живого трансформа локального
            // игрока — боксы мгновенно следуют за поворотом камеры (0 задержки).
            CameraView liveCam; liveCam.valid = false;
            // Признак смерти нужен и ниже, в блоке чтения матрицы: тот
            // выполняется ПОСЛЕ этой проверки и иначе тут же вернул бы
            // g_camVPValid=true, прочитав камеру трупа.
            bool localDeadThisFrame = false;
            if (g_localPlayer) {
                liveCam = ox_buildCameraFromPlayer(g_localPlayer, false);
                // Страховка: если углы выбранного PM застыли дольше 3 секунд —
                // это труп, а замены в списке нет. Рисовать по замороженному
                // базису нельзя: боксы «прилипнут» к экрану и поедут за
                // камерой. Лучше не показать ничего, чем показать неверно.
                // Прямой признак смерти вместо косвенного (замороженные углы):
                // PM.respawning выставляется игрой на время смерти/респавна, а
                // HP<=0 закрывает случай, когда флаг ещё не поднялся. В режиме
                // наблюдателя углы MouseLook продолжают крутиться, поэтому
                // детектор по заморозке молчал — и ESP летал после КАЖДОЙ
                // смерти, пока список игроков не пересобирался сам.
                // Только PM.respawning. Проверку «HP<=0» убрал: VITALS_HEALTH
                // (0x88) — это m_MaxHealth, а не текущее здоровье (в логах у
                // всех ровно 100). Текущее HP синкается и отдельным полем в
                // дампе не значится, так что та ветка была мёртвой.
                bool localDead = rpm<uint8_t>(g_localPlayer + ox::PM_RESPAWNING) != 0;
                localDeadThisFrame = localDead;
                if (localDead) {
                    static double s_lastDeadLog = 0.0;
                    double nd = (double)ImGui::GetTime();
                    if (nd - s_lastDeadLog > 3.0) {
                        s_lastDeadLog = nd;
                        OXLOGI("[respawn] локальный игрок мёртв/респавнится — ESP скрыт, ждём нового PM");
                    }
                    liveCam.valid = false;
                    // Гасим и матричный путь тоже. Иначе смерть отключает
                    // только угловую проекцию, а матрица (которая читается из
                    // камеры трупа и уже не обновляется) продолжает рисовать
                    // застывшие боксы — тот самый «ESP остаётся при повороте».
                    g_camVPValid  = false;
                    g_camPosValid = false;
                    cache_needs_update = true;   // форсируем пере-выбор владельца
                }

                if (liveCam.valid && ox_lookFrozen(g_localPlayer, (double)ImGui::GetTime(), 3.0f)) {
                    static double s_lastWarn = 0.0;
                    double nw = (double)ImGui::GetTime();
                    if (nw - s_lastWarn > 5.0) {
                        s_lastWarn = nw;
                        OXLOGW("[camera] базис заморожен (PM=0x%llx) — ESP скрыт до респавна",
                               (unsigned long long)g_localPlayer);
                    }
                    liveCam.valid = false;
                    cache_needs_update = true;   // подтолкнуть пере-выбор
                }
            }
            // ── VP-матрица этого кадра, прямо из нативной камеры ──────────
            // Первый успешный заход ищет смещения по подписи и кэширует их.
            // Если не нашлись — g_camVPValid остаётся false и весь ESP молча
            // работает по старому угловому пути.
            // Матрицу ищем НЕ дожидаясь liveCam.valid: нативная камера живёт
            // раньше, чем собирается наш реконструированный базис. Раньше
            // условие требовало liveCam.valid, из-за чего поиск стартовал
            // только через ~18 секунд после захода — всё это время ESP шёл по
            // угловому пути и «плавал».
            {
                static int      s_missStreak = 0;  // подряд неудачных перечиток
                static uint64_t s_lastPm     = 0;  // чей PM обслуживали в прошлый кадр
                static uint64_t s_lastCam    = 0;  // и какая была нативная камера

                // ── СМЕРТЬ/РЕСПАВН ────────────────────────────────────────
                // После смерти g_localPlayer какое-то время указывает на PM
                // трупа. Из него ox_getNativeCamera достаёт КАМЕРУ ТРУПА, и
                // матрица читается из чужого объекта — ESP «улетает». Старый
                // детектор ловил замороженные углы MouseLook, но в режиме
                // наблюдателя углы продолжают меняться, поэтому он молчал.
                // Здесь ловим сам факт подмены: сменился PM или сменился
                // указатель камеры => немедленно выбрасываем кэш.
                uint64_t nativeCam = 0;
                if (espMatrixW2S && g_localPlayer && !localDeadThisFrame)
                    nativeCam = ox_getNativeCamera(g_localPlayer);

                // Кэш смещений матриц привязан к КАМЕРЕ, а не к игроку.
                // Раньше сюда входила и смена g_localPlayer — а он скакал
                // 0 -> PM -> 0 по несколько раз в секунду из-за карусели выше,
                // и каждый скачок стирал уже найденные смещения. Поиск
                // стартовал заново и снова стирался, матрица не доживала до
                // применения. Теперь сбрасываем ТОЛЬКО когда сменился сам
                // указатель нативной камеры — это и есть настоящий признак
                // того, что мы смотрим на другой объект.
                bool camChanged = (nativeCam && s_lastCam && nativeCam != s_lastCam);
                if (camChanged) {
                    // Гистерезис ниже НЕ должен переживать смену владельца —
                    // иначе он же и удержит протухшую VP на несколько кадров.
                    g_camVPValid  = false;
                    g_camPosValid = false;
                    s_missStreak  = 999;
                    g_camViewMatOff = -1;      // переискать на новой камере
                    g_camProjMatOff = -1;
                    g_camNativeCached = 0;
                    cache_needs_update = true;
                    OXLOGI("[respawn] нативная камера сменилась 0x%llx -> 0x%llx, кэш матрицы сброшен",
                           (unsigned long long)s_lastCam,
                           (unsigned long long)nativeCam);
                }
                s_lastPm  = g_localPlayer;
                if (nativeCam) s_lastCam = nativeCam;

                bool got = false;
                if (nativeCam) {
                    if (g_camViewMatOff == -1 || nativeCam != g_camNativeCached)
                        ox_findCameraMatrices(nativeCam);
                    got = ox_readViewProjection(nativeCam, &g_camVP);

                    // ── ЗАСТЫВШАЯ МАТРИЦА ─────────────────────────────────
                    // Камера трупа продолжает отдавать ГЕОМЕТРИЧЕСКИ ВАЛИДНУЮ
                    // матрицу — просто она больше не обновляется. Проверки
                    // подписи её пропускают, и мы честно проецируем по мёртвым
                    // данным: боксы застывают на экране и едут вместе с ним.
                    //
                    // Ловим это по самой матрице: если её содержимое не
                    // изменилось ни на бит дольше секунды, значит движок в неё
                    // не пишет. Живая камера меняется каждый кадр — даже когда
                    // стоишь на месте, там дышит FOV и микродрожание.
                    if (got) {
                        static OxMat4 s_prevVP{};
                        static double s_lastVpChange = 0.0;
                        static bool   s_seeded = false;
                        double nowV = (double)ImGui::GetTime();
                        bool same = s_seeded &&
                                    memcmp(&s_prevVP, &g_camVP, sizeof(OxMat4)) == 0;
                        if (!same) { s_prevVP = g_camVP; s_lastVpChange = nowV; s_seeded = true; }
                        if (s_seeded && (nowV - s_lastVpChange) > 1.0) {
                            static double s_lastFrozenLog = 0.0;
                            if (nowV - s_lastFrozenLog > 3.0) {
                                s_lastFrozenLog = nowV;
                                OXLOGW("[cam] матрица не менялась %.1fс — камера мертва, ESP скрыт",
                                       nowV - s_lastVpChange);
                            }
                            got = false;                 // считаем камеру мёртвой
                            cache_needs_update = true;   // подтолкнуть пере-выбор PM
                        }
                    }
                }
                if (got) {
                    s_missStreak = 0;
                    g_camVPValid = true;
                } else if (g_camVPValid && ++s_missStreak <= 2) {
                    // Гистерезис ужат с 8 кадров до 2. Восемь кадров — это
                    // ~130 мс отрисовки по ПРОТУХШЕЙ матрице: за это время
                    // камера успевает заметно повернуться, и боксы уезжают
                    // вместе с экраном. Два кадра гасят разовый промах (кадр
                    // поймали в момент, когда движок пишет матрицу), но не
                    // дают залипнуть на мёртвой камере.
                } else {
                    g_camVPValid = false;
                    g_camPosValid = false;
                }
                if (localDeadThisFrame) {   // мёртв — ни одного источника
                    g_camVPValid  = false;
                    g_camPosValid = false;
                }
            }

            // Диагностика раз в 2 сек. Обёрнута целиком, а не только вывод:
            // внутри реальные чтения памяти игры (ox_getNativeCamera, обход
            // кэша, повторный ox_readModelAnchors) — макрос OXLOG их бы не
            // убрал, они выполнялись бы впустую каждые две секунды.
#ifdef OX_ENABLE_LOG
            {
                static double s_lastDiag = 0.0;
                double nowD = (double)ImGui::GetTime();
                if (nowD - s_lastDiag > 2.0 && g_localPlayer) {
                    s_lastDiag = nowD;
                    int anchored = 0;
                    for (const auto& pl : cached_players)
                        if (pl.usedModelAnchor) anchored++;
                    // nativeCam=0 сразу показывает, что до объекта камеры мы
                    // вообще не дошли (PM пустой / цепочка рвётся), а не что
                    // поиск шёл и не нашёл. Без этого «viewOff=-1» выглядел
                    // одинаково в обоих случаях.
                    uint64_t dbgCam = g_localPlayer ? ox_getNativeCamera(g_localPlayer) : 0;
                    // Подтверждение, что владелец камеры — действительно НАШ
                    // игрок, а не чужой: читаем флаг прямо у выбранного PM.
                    int dbgFlag = -1;
                    if (g_localPlayer) {
                        uint64_t ni = rpm<uint64_t>(g_localPlayer + ox::NB_NET_IDENTITY);
                        if (ox_isPtr(ni)) dbgFlag = rpm<uint8_t>(ni + ox::NI_IS_LOCAL_PLAYER) ? 1 : 0;
                    }
                    OXLOGI("[w2s] matrix=%d cam=%d dead=%d isLocal=%d | viewOff=%d projOff=%d | pm=0x%llx nativeCam=0x%llx | anchors=%d/%d",
                           (int)g_camVPValid, (int)liveCam.valid, (int)localDeadThisFrame,
                           dbgFlag, g_camViewMatOff, g_camProjMatOff,
                           (unsigned long long)g_localPlayer,
                           (unsigned long long)dbgCam,
                           anchored, (int)cached_players.size());

                    // Если ни одного якоря — разбираем ПЕРВУЮ живую цель
                    // по шагам, чтобы точно знать где обрыв.
                    if (anchored == 0 && !cached_players.empty()) {
                        for (const auto& pl : cached_players) {
                            if (!ox_isPtr(pl.address)) continue;
                            OxModelAnchors dbg = ox_readModelAnchors(pl.address);
                            uint64_t rawRef = rpm<uint64_t>(pl.address + ox::PM_KCC_REFERENCE);
                            OXLOGI("[anchor] pm=0x%llx ref=0x%llx kcc=0x%llx stage=%d "
                                   "headTr=0x%llx cached=0x%llx mat=0x%llx cap=%.2f dy=%.2f dxz=%.2f",
                                   (unsigned long long)pl.address,
                                   (unsigned long long)rawRef,
                                   (unsigned long long)dbg.kccPtr,
                                   dbg.failStage,
                                   (unsigned long long)dbg.headTr,
                                   (unsigned long long)dbg.headCached,
                                   (unsigned long long)dbg.headMatrix,
                                   dbg.capsuleH, dbg.lastDy, dbg.lastDxz);
                            break;
                        }
                    }
                }
            }
#endif

            int positionInterval = g_positionInterval < 1 ? 1 : g_positionInterval;
            bool refreshPositions = !cacheUpdatedThisFrame &&
                                    (ImGui::GetFrameCount() % positionInterval == 0);

            if (aimm && aimDrawFov) {
                getDrawList()->AddCircle(ImVec2(abs_ScreenX * 0.5f, abs_ScreenY * 0.5f),
                                         aimFovPixels, IM_COL32(255, 255, 255, 140), 96, 1.5f);
            }

            for (auto& player : cached_players) {
                // UPDATE 2026/07/31 v24: МГНОВЕННОЕ удаление бокса при смерти.
                // Раньше мёртвый игрок отсеивался только на следующем тяжёлом
                // скане (до ~10 кадров) → бокс висел «ещё секунду». Теперь HP
                // перечитывается КАЖДЫЙ кадр прямо здесь; hp<=0 / невалид → скип
                // немедленно. Дёшево (одно чтение vitals->hp).
                if (ox_isPtr(player.address)) {
                    float liveHp = ox_readHP(player.address, false);
                    if (!isfinite(liveHp) || liveHp <= 0.f) continue;   // мёртв → не рисуем
                }
                // W2S считаем из СВЕЖЕЙ камеры и СВЕЖЕЙ мировой позиции.
                bool visB = false, visT = false;
                ImVec2 w2sBottom, w2sTop;
                Vector3 livePos = player.position;
                // Рисуем ТОЛЬКО при живом источнике проекции: либо свежая
                // VP-матрица, либо валидный угловой базис. Иначе — пропуск
                // (см. ветку ниже): любые старые координаты приклеиваются к
                // экрану и едут вместе с поворотом камеры.
                if (liveCam.valid || g_camVPValid) {
                    // Перечитываем позицию игрока КАЖДЫЙ кадр (дёшево: пара чтений
                    // трансформа), чтобы бокс идеально держался на бегущем игроке
                    // без отставания от тяжёлого скана UpdatePlayerCache.
                    if (refreshPositions && ox_isPtr(player.address)) {
                        Vector3 refreshed = ox_readPos(player.address, false);
                        if (refreshed != Vector3::Zero()) player.position = refreshed;
                    }
                    livePos = player.position;
                    player.distance = Vector3::Distance(liveCam.pos, livePos);
                    // Скелет читаем только когда он включён и цель не слишком
                    // далеко — на дистанции кости всё равно сливаются в пиксель,
                    // а чтения стоят трафика к процессу игры.
                    // ── Якоря модели: голова и ноги ИЗ ОТРИСОВЫВАЕМОЙ модели ──
                    // Пока espModelAnchor включён, бокс строится по фактическим
                    // габаритам (KCC.head + Motor.LastInterpolatedPosition), а не
                    // по серверному тику с ручным вертикальным оффсетом. Если
                    // цепочка не прочиталась — молча откатываемся на старый путь.
                    OxModelAnchors anch;
                    if (espModelAnchor && player.distance < 400.f)
                        anch = ox_readModelAnchors(player.address);

                    Vector3 skelFeet = anch.valid
                                     ? anch.feet
                                     : livePos + Vector3(0.f, ox_boxYOffset(), 0.f);

                    if (skeleton && player.distance < 220.f) {
                        ox_readSkeleton(player.address, skelFeet, player);
#ifdef OX_ENABLE_LOG
                        // Раз в 3 сек показываем, читается ли скелет вообще —
                        // иначе «не рисуется» неотличимо от «не включён».
                        static double s_lastSkelLog = 0.0;
                        double ns = (double)ImGui::GetTime();
                        if (ns - s_lastSkelLog > 3.0) {
                            s_lastSkelLog = ns;
                            OXLOGI("[skel] pm=0x%llx data=%d head=(%.2f %.2f %.2f) feet=(%.2f %.2f %.2f) d=%.1f",
                                   (unsigned long long)player.address,
                                   (int)player.hasSkeletonData,
                                   player.headPos.x, player.headPos.y, player.headPos.z,
                                   skelFeet.x, skelFeet.y, skelFeet.z,
                                   player.distance);
                        }
#endif
                    } else {
                        player.hasSkeletonData = false;
                    }

                    // Проекция: матричная если VP прочиталась, иначе угловая.
                    // Обе ветки дают одинаковые screen-координаты, разница в
                    // точности — матрица учитывает всё, что движок делает с
                    // камерой (шейк, отдача, нестандартный ADS-projection).
                    auto project = [&](const Vector3& wp, bool* vis) -> ImVec2 {
                        if (g_camVPValid) {
                            ImVec2 sp;
                            if (ox_w2sMatrix(g_camVP, wp, (float)abs_ScreenX,
                                             (float)abs_ScreenY, &sp)) {
                                const float M = 64.f;
                                *vis = (sp.x >= -M && sp.x <= abs_ScreenX + M &&
                                        sp.y >= -M && sp.y <= abs_ScreenY + M);
                                return sp;
                            }
                            *vis = false;
                            return ImVec2(-1.f, -1.f);
                        }
                        // Угловой путь оставлен только как запасной. Если
                        // матрица не поднялась, но базис есть — рисуем по нему.
                        return w2s_angular(wp, liveCam, vis);
                    };

                    if (anch.valid) {
                        // Фактические габариты: низ = ноги, верх = голова плюс
                        // небольшой запас на макушку (head — это точка глаз/шеи).
                        player.usedModelAnchor = true;
                        player.anchorFeet = anch.feet;
                        player.anchorHead = anch.head;
                        player.anchorCrouching = anch.crouching;
                        // Скорость от моторa точнее численной производной по
                        // позициям: она не шумит на низком тикрейте.
                        if (anch.velocity.x != 0.f || anch.velocity.y != 0.f ||
                            anch.velocity.z != 0.f)
                            player.motorVelocity = anch.velocity;
                        w2sBottom = project(anch.feet, &visB);
                        w2sTop    = project(anch.head + Vector3(0.f, 0.18f, 0.f), &visT);
                    } else {
                        player.usedModelAnchor = false;
                        Vector3 anchorPos = livePos + Vector3(0.f, ox_boxYOffset(), 0.f);
                        w2sBottom = project(anchorPos - Vector3(0, ox::BOX_FOOT, 0), &visB);
                        w2sTop    = project(anchorPos + Vector3(0, ox::BOX_HEAD, 0), &visT);
                    }
                } else {
                    // КАМЕРЫ НЕТ — НИЧЕГО НЕ РИСУЕМ.
                    //
                    // Здесь раньше подставлялись ЭКРАННЫЕ координаты прошлого
                    // кадра из кэша. Они посчитаны для старого положения
                    // камеры и статичны: поворачиваешь экран — боксы остаются
                    // висеть там же и «плавают» вместе с поворотом. Ровно тот
                    // симптом, что после смерти ESP не уходит за край экрана.
                    //
                    // Пустой экран честнее приклеенных боксов: они не просто
                    // бесполезны, они показывают врагов не там, где те есть.
                    continue;
                }
                if (!visB && !visT) continue;

                // --- LOS-чек для этого игрока (на свежей камере и позиции) ---
                // Дешёвая проверка по кэшу построек: один ray на цель в кадр.
                // FIX: луч к ГРУДИ (feet+1.3), а не к ногам — иначе низкая стена/
                // фундамент у ног ложно красит видимого игрока синим. Считаем
                // видимым, если открыта хотя бы грудь ИЛИ голова.
                if (espColorByVisibility || aimCheckWalls) {
                    if (liveCam.valid) {
                        // Луч к настоящей груди/голове модели, когда якоря есть.
                        Vector3 chest, head;
                        if (player.usedModelAnchor) {
                            head  = player.anchorHead;
                            chest = Vector3(player.anchorFeet.x,
                                            player.anchorFeet.y + (head.y - player.anchorFeet.y) * 0.72f,
                                            player.anchorFeet.z);
                        } else {
                            Vector3 losBase = livePos + Vector3(0.f, ox_boxYOffset(), 0.f);
                            chest = losBase + Vector3(0.f, 1.30f, 0.f);
                            head  = losBase + Vector3(0.f, ox::BOX_HEAD, 0.f);
                        }
                        bool vis = ox_isTargetVisible(liveCam.pos, chest) ||
                                   ox_isTargetVisible(liveCam.pos, head);
                        player.losBlocked = !vis;
                    } else {
                        player.losBlocked = false;
                    }
                } else {
                    player.losBlocked = false;
                }

                // ================= АВТОРСКИЙ ESP (@xohyw) =================
                // Единый фирменный стиль: угловые скобки-боксы, вертикальный
                // хилбар со скруглением/градиентом, аккуратные подписи с тенью.
                ImDrawList* dl = getDrawList();

                // Геометрия бокса из двух W2S-точек (голова/ноги).
                float projectedHeight = fabsf(w2sTop.y - w2sBottom.y);
                float halfW = projectedHeight * 0.25f;   // half width: 2D box ratio is 0.5 width to height
                float bx0 = (w2sTop.x < w2sBottom.x ? w2sTop.x : w2sBottom.x) - halfW;
                float bx1 = (w2sTop.x > w2sBottom.x ? w2sTop.x : w2sBottom.x) + halfW;
                float by0 = w2sTop.y;      // верх (голова)
                float by1 = w2sBottom.y;   // низ (ноги)
                if (by1 < by0) { float t = by0; by0 = by1; by1 = t; }
                float bw = bx1 - bx0, bh = by1 - by0;
                float cx = (bx0 + bx1) * 0.5f;

                // HP 0..100 и его цвет (зелёный->жёлтый->красный, синий если >100).
                float hp = ::clamp<float>((float)player.health, 0, 100);
                float ht = hp / 100.0f;
                // --- Цвет бокса по видимости (зелёный=видим, синий=за стеной) ---
                // Если espColorByVisibility включён — цвет переопределяется
                // поверх espboxcolor. Зелёный = цель в прямой видимости,
                // синий = путь от камеры перекрыт BuildingPiece. Аккуратно: HP-бар
                // и т.п. остаются со своими цветами — меняется только рамка/фон.
                ImU32 accent;
                if (espColorByVisibility && player.losBlocked) {
                    // Синий — за стеной
                    accent = IM_COL32(80, 150, 255, 255);
                } else if (espColorByVisibility) {
                    // Зелёный — видим напрямую
                    accent = IM_COL32(60, 230, 110, 255);
                } else {
                    accent = ImGui::ColorConvertFloat4ToU32(
                        ImVec4(espboxcolor[0], espboxcolor[1], espboxcolor[2], 1.0f));
                }
                // Цвет по дистанции (переопределяет всё остальное, если включён):
                // 0 m -> красный, radarRange/2 -> жёлтый, дальше -> синий.
                // Даёт мгновенное «кто рядом» без чтения цифр.
                if (espDistColor && player.distance > 0.f) {
                    float t = ::clamp<float>(player.distance / 120.f, 0.f, 1.f);
                    int r, g, b;
                    if (t < 0.5f) {           // красный -> жёлтый
                        float k = t * 2.f;
                        r = 255; g = (int)(60 + 195 * k); b = 55;
                    } else {                  // жёлтый -> синий
                        float k = (t - 0.5f) * 2.f;
                        r = (int)(255 - 175 * k); g = (int)(255 - 120 * k); b = (int)(55 + 200 * k);
                    }
                    accent = IM_COL32(r, g, b, 255);
                }
                ImU32 shadowC = IM_COL32(0, 0, 0, 170);
                ImColor hpFull(int(90 + 90 * (1 - ht)), int(200 * ht + 40), 70, 255);
                ImColor hpEmpty(210, 60, 55, 255);
                if (player.health > 100) { hpFull = ImColor(90, 160, 255, 255); hpEmpty = hpFull; }

                // Компоненты акцентного цвета (для свечения).
                int aR = (int)((accent >> 0) & 0xFF);
                int aG = (int)((accent >> 8) & 0xFF);
                int aB = (int)((accent >> 16) & 0xFF);
                ImU32 accentGlow = IM_COL32(aR, aG, aB, 60);

                // Хелпер: текст с мягкой тенью (читаемо��ть на любом фоне).
                auto text2 = [&](float tx, float ty, ImU32 col, const char* s) {
                    dl->AddText(ImVec2(tx + 1, ty + 1), shadowC, s);
                    dl->AddText(ImVec2(tx, ty), col, s);
                };
                // Хелпер: текст по центру на полупрозрачной «таблетке»-чипе.
                auto chip = [&](float cxp, float topY, ImU32 txtCol, ImU32 barCol, const char* s) {
                    ImVec2 ts = ImGui::CalcTextSize(s);
                    float padx = 6.f, pady = 2.f;
                    ImVec2 a(cxp - ts.x * 0.5f - padx, topY);
                    ImVec2 b(cxp + ts.x * 0.5f + padx, topY + ts.y + pady * 2);
                    dl->AddRectFilled(a, b, IM_COL32(10, 8, 18, 180), 4.f);
                    if (barCol) dl->AddRectFilled(a, ImVec2(a.x + 3, b.y), barCol, 4.f,
                                                  ImDrawFlags_RoundCornersLeft);
                    dl->AddText(ImVec2(cxp - ts.x * 0.5f, topY + pady), txtCol, s);
                    return b.y;
                };

                if (espbox) {
                    // Заливка с лёгкой вертикальной виньеткой (сверху прозрачнее).
                    if (espfill) {
                        int a = (int)(90.0f * espfillp / 100.0f);
                        dl->AddRectFilledMultiColor(ImVec2(bx0, by0), ImVec2(bx1, by1),
                            IM_COL32(aR, aG, aB, a / 4),  IM_COL32(aR, aG, aB, a / 4),
                            IM_COL32(aR, aG, aB, a),      IM_COL32(aR, aG, aB, a));
                    }
                    // Rounded frame or compact corner brackets with the same accent treatment.
                    float th = espstroke < 1.f ? 2.f : espstroke;
                    float rnd = (bw < bh ? bw : bh) * 0.22f;   // радиус скругления от меньшей стороны
                    ImVec2 a(bx0, by0), b(bx1, by1);
                    if (!espCornerBox) {
                        // v24: тоньше и чище — glow/тень ужаты (было +4/+2).
                        dl->AddRect(ImVec2(a.x-1, a.y-1), ImVec2(b.x+1, b.y+1), accentGlow, rnd, 0, th + 2.f);
                        dl->AddRect(a, b, shadowC, rnd, 0, th + 1.f);
                        dl->AddRect(a, b, accent, rnd, 0, th);
                    } else {
                        float corner = ::clamp<float>((bw < bh ? bw : bh) * espCornerLength, 12.f, 52.f);
                        const ImVec2 darkLines[] = {
                            ImVec2(a.x, a.y), ImVec2(a.x + corner, a.y), ImVec2(a.x, a.y), ImVec2(a.x, a.y + corner),
                            ImVec2(b.x, a.y), ImVec2(b.x - corner, a.y), ImVec2(b.x, a.y), ImVec2(b.x, a.y + corner),
                            ImVec2(a.x, b.y), ImVec2(a.x + corner, b.y), ImVec2(a.x, b.y), ImVec2(a.x, b.y - corner),
                            ImVec2(b.x, b.y), ImVec2(b.x - corner, b.y), ImVec2(b.x, b.y), ImVec2(b.x, b.y - corner),
                        };
                        for (int i = 0; i < IM_ARRAYSIZE(darkLines); i += 2) {
                            dl->AddLine(darkLines[i], darkLines[i + 1], shadowC, th + 3.f);
                            dl->AddLine(darkLines[i], darkLines[i + 1], accent, th);
                        }
                    }
                }

                // ── СКЕЛЕТ ──────────────────────────────────────────────
                if (skeleton && player.hasSkeletonData && liveCam.valid) {
                    // Тот же проектор, что и у бокса: иначе скелет и рамка
                    // разъезжаются, когда матрица есть, а скелет идёт углами.
                    auto W2S = [&](const Vector3 &w, bool *vis) -> ImVec2 {
                        if (g_camVPValid) {
                            ImVec2 sp;
                            if (ox_w2sMatrix(g_camVP, w, (float)abs_ScreenX,
                                             (float)abs_ScreenY, &sp)) {
                                const float M = 64.f;
                                *vis = (sp.x >= -M && sp.x <= abs_ScreenX + M &&
                                        sp.y >= -M && sp.y <= abs_ScreenY + M);
                                return sp;
                            }
                            *vis = false;
                            return ImVec2(-1.f, -1.f);
                        }
                        return w2s_angular(w, liveCam, vis);
                    };
                    struct Bone { const Vector3 *a, *b; };
                    const Bone bones[] = {
                        { &player.headPos,      &player.neckPos      },
                        { &player.neckPos,      &player.spine1Pos    },
                        { &player.spine1Pos,    &player.spine2Pos    },
                        { &player.neckPos,      &player.rshoulderPos },
                        { &player.neckPos,      &player.lshoulderPos },
                        { &player.rshoulderPos, &player.ruparmPos    },
                        { &player.ruparmPos,    &player.rlowarmPos   },
                        { &player.lshoulderPos, &player.luparmPos    },
                        { &player.luparmPos,    &player.llowarmPos   },
                        { &player.spine2Pos,    &player.rhipPos      },
                        { &player.spine2Pos,    &player.lhipPos      },
                        { &player.rhipPos,      &player.rkneePos     },
                        { &player.rkneePos,     &player.rfootPos     },
                        { &player.lhipPos,      &player.lkneePos     },
                        { &player.lkneePos,     &player.lfootPos     },
                    };
                    float sth = espstroke < 1.f ? 1.4f : espstroke * 0.75f;
                    for (const Bone &bn : bones) {
                        bool va = false, vb = false;
                        ImVec2 pa = W2S(*bn.a, &va);
                        ImVec2 pb = W2S(*bn.b, &vb);
                        if (!va || !vb) continue;
                        dl->AddLine(pa, pb, shadowC, sth + 2.0f);
                        dl->AddLine(pa, pb, accent, sth);
                    }
                    // Голова — кружок радиусом от проекции роста.
                    bool vh = false;
                    ImVec2 hp2 = W2S(player.headPos, &vh);
                    if (vh) {
                        bool vn = false;
                        ImVec2 np2 = W2S(player.neckPos, &vn);
                        float hr = vn ? fabsf(np2.y - hp2.y) * 0.85f : bh * 0.07f;
                        if (hr < 2.f) hr = 2.f;
                        if (hr > 60.f) hr = 60.f;
                        dl->AddCircle(hp2, hr, shadowC, 16, sth + 2.0f);
                        dl->AddCircle(hp2, hr, accent, 16, sth);
                    }
                }

                if (ESP3D && liveCam.valid) {
                    const float halfModelWidth = 0.30f;
                    const Vector3 offsets[8] = {
                        Vector3(-halfModelWidth, -ox::BOX_FOOT, -halfModelWidth),
                        Vector3( halfModelWidth, -ox::BOX_FOOT, -halfModelWidth),
                        Vector3( halfModelWidth, -ox::BOX_FOOT,  halfModelWidth),
                        Vector3(-halfModelWidth, -ox::BOX_FOOT,  halfModelWidth),
                        Vector3(-halfModelWidth,  ox::BOX_HEAD, -halfModelWidth),
                        Vector3( halfModelWidth,  ox::BOX_HEAD, -halfModelWidth),
                        Vector3( halfModelWidth,  ox::BOX_HEAD,  halfModelWidth),
                        Vector3(-halfModelWidth,  ox::BOX_HEAD,  halfModelWidth),
                    };
                    ImVec2 corners[8];
                    bool cornerVisible[8];
                    // База 3D-бокса — ноги модели, если якоря есть.
                    const Vector3 boxAnchor = player.usedModelAnchor
                        ? player.anchorFeet + Vector3(0.f, ox::BOX_FOOT, 0.f)
                        : livePos + Vector3(0.f, ox_boxYOffset(), 0.f);
                    for (int i = 0; i < 8; ++i) {
                        Vector3 wp = boxAnchor + offsets[i];
                        if (g_camVPValid) {
                            ImVec2 sp;
                            if (ox_w2sMatrix(g_camVP, wp, (float)abs_ScreenX,
                                             (float)abs_ScreenY, &sp)) {
                                const float M = 64.f;
                                cornerVisible[i] = (sp.x >= -M && sp.x <= abs_ScreenX + M &&
                                                    sp.y >= -M && sp.y <= abs_ScreenY + M);
                                corners[i] = sp;
                            } else {
                                cornerVisible[i] = false;
                                corners[i] = ImVec2(-1.f, -1.f);
                            }
                        } else {
                            corners[i] = w2s_angular(wp, liveCam, &cornerVisible[i]);
                        }
                    }

                    const int edges[][2] = {
                        {0, 1}, {1, 2}, {2, 3}, {3, 0},
                        {4, 5}, {5, 6}, {6, 7}, {7, 4},
                        {0, 4}, {1, 5}, {2, 6}, {3, 7},
                    };
                    const float lineWidth = espstroke < 1.f ? 1.f : espstroke;
                    for (const auto& edge : edges) {
                        if (cornerVisible[edge[0]] && cornerVisible[edge[1]])
                            dl->AddLine(corners[edge[0]], corners[edge[1]], accent, lineWidth);
                    }
                }

                if (esphealth && bh > 4.f) {
                    // Вертикальный хилбар слева от бокса со свечением заливки.
                    float bar = esphpsize < 3.f ? 5.f : esphpsize;
                    float hx1 = bx0 - 7.f;
                    float hx0 = hx1 - bar;
                    float r   = bar * 0.5f;
                    // фон-трек (тёмный, скруглённый)
                    dl->AddRectFilled(ImVec2(hx0 - 1.5f, by0 - 1.5f), ImVec2(hx1 + 1.5f, by1 + 1.5f),
                                      IM_COL32(6, 5, 12, 220), r + 1.f);
                    float fillTop = by1 - bh * ht;
                    // мягкое свечение вокруг заполнения (цветом текущего HP)
                    dl->AddRectFilled(ImVec2(hx0 - 2.5f, fillTop - 1.f), ImVec2(hx1 + 2.5f, by1 + 1.f),
                        IM_COL32((int)(hpFull.Value.x*255), (int)(hpFull.Value.y*255),
                                 (int)(hpFull.Value.z*255), 55), r + 1.f);
                    // само заполнение (градиент опционально)
                    if (esphpgradient) {
                        dl->AddRectFilledMultiColor(ImVec2(hx0, fillTop), ImVec2(hx1, by1),
                            hpFull, hpFull, hpEmpty, hpEmpty);
                    } else {
                        dl->AddRectFilled(ImVec2(hx0, fillTop), ImVec2(hx1, by1), hpFull, r);
                    }
                    // блик сверху заполнения
                    if (bh * ht > 4.f)
                        dl->AddRectFilled(ImVec2(hx0, fillTop), ImVec2(hx1, fillTop + 2.f),
                                          IM_COL32(255, 255, 255, 90), r, ImDrawFlags_RoundCornersTop);
                    // Число HP слева от бара. espHpNumber -> всегда, иначе
                    // старое поведение (только когда HP != 100).
                    if (espHpNumber || player.health != 100) {
                        char hs[16]; snprintf(hs, sizeof(hs), "%d", (int)hp);
                        ImVec2 s = ImGui::CalcTextSize(hs);
                        text2(hx0 - s.x - 4.f, fillTop - s.y * 0.5f, IM_COL32(255,255,255,255), hs);
                    }
                    // Броня — синим числом под HP, только если она есть.
                    if (espArmor && player.armor > 0) {
                        char as[16]; snprintf(as, sizeof(as), "%d", player.armor);
                        ImVec2 s = ImGui::CalcTextSize(as);
                        text2(hx0 - s.x - 4.f, by1 - s.y, IM_COL32(120, 190, 255, 255), as);
                    }
                }

                // Метки состояния над ником: спит / наблюдает / прайм.
                // Спящий = безопасная цель, наблюдатель = не в игре.
                float flagY = by0;
                if (espFlags) {
                    const char* ftxt = nullptr; ImU32 fcol = 0;
                    if (player.flagSleeping)        { ftxt = "SLEEP"; fcol = IM_COL32(150, 150, 165, 255); }
                    else if (player.flagSpectating) { ftxt = "SPEC";  fcol = IM_COL32(190, 140, 255, 255); }
                    else if (player.flagPrime)      { ftxt = "PRIME"; fcol = IM_COL32(255, 205, 90, 255); }
                    if (ftxt) {
                        ImVec2 fs = ImGui::CalcTextSize(ftxt);
                        float fy = by0 - fs.y - 7.f;
                        if (espname && !player.name.empty()) fy -= fs.y + 6.f;
                        chip(cx, fy, fcol, fcol, ftxt);
                        flagY = fy;
                    }
                }
                (void)flagY;

                if (espname && !player.name.empty()) {
                    ImVec2 s = ImGui::CalcTextSize(player.name.c_str());
                    // имя на чипе над боксом + акцентная полоска слева
                    chip(cx, by0 - s.y - 7.f, IM_COL32(255, 255, 255, 255), accent,
                         player.name.c_str());
                    // тонкая акцентная линия по ширине бокса — фирменная деталь
                    dl->AddLine(ImVec2(bx0, by0 - 2.f), ImVec2(bx1, by0 - 2.f), accentGlow, 2.f);
                }

                // Оружие и дистанция — чипами под боксом (стек вниз).
                float infoY = by1 + 4.f;
                if (espweapon && !player.weapon.empty()) {
                    infoY = chip(cx, infoY, IM_COL32(235, 235, 245, 255), 0, player.weapon.c_str()) + 2.f;
                }
                
                // --- Дистанция (чипом под оружием / боксом) ---
                if (espdist && player.distance > 0.f) {
                    char distStr[32];
                    snprintf(distStr, sizeof(distStr), "%.0f m", player.distance);
                    chip(cx, infoY, IM_COL32(170, 205, 235, 255), accent, distStr);
                }

                // --- ESP Lines / Tracers ---
                if (esplines_enabled) {
                    ImU32 lineCol = IM_COL32(
                        (int)(esplines_color[0] * 255),
                        (int)(esplines_color[1] * 255),
                        (int)(esplines_color[2] * 255),
                        220);
                    float sx = (float)abs_ScreenX;
                    float sy = (float)abs_ScreenY;
                    float cx_screen = sx * 0.5f;
                    float cy_screen = sy * 0.5f;
                    float originX, originY;
                    if (esplines_position == 0) {
                        // от нижнего центра экрана
                        originX = cx_screen;
                        originY = sy;
                    } else {
                        // от перекрестия (центр экрана)
                        originX = cx_screen;
                        originY = cy_screen;
                    }
                    // Берём одну W2S-точку целиком: ноги, либо голову у края кадра.
                    ImVec2 target = visB ? w2sBottom : w2sTop;
                    dl->AddLine(ImVec2(originX, originY), target, lineCol, esplines_thickness);
                    dl->AddCircleFilled(target, esplines_thickness + 1.5f, lineCol, 12);
                }

                // --- BULLET TRACER (v25): линия куда СМОТРИТ/целится враг ---
                // PlayerManager.lookAngle (0x1A8) — реплицируемый горизонтальный
                // угол взгляда. Рисуем от груди игрока луч ~18 м по этому азимуту:
                // видно кто куда целится / линию потенциального выстрела. Дёшево —
                // один float на игрока, никаких сканов памяти.
                if (esptracer && ox_isPtr(player.address)) {
                    float yawDeg = rpm<float>(player.address + ox::PM_LOOK_ANGLE);
                    if (isfinite(yawDeg)) {
                        const float DEG2RAD = 0.01745329252f;
                        float yr = yawDeg * DEG2RAD;
                        // Unity left-handed y-up: forward = (sin yaw, 0, cos yaw).
                        Vector3 fwd(sinf(yr), 0.f, cosf(yr));
                        // Старт — грудь (середина бокса), длина луча 18 м.
                        Vector3 chest = livePos + Vector3(0.f, ox_boxYOffset() + 1.1f, 0.f);
                        Vector3 tip   = chest + fwd * 18.0f;
                        bool vTip = false, vCh = false;
                        ImVec2 sCh, sTip;
                        if (g_camVPValid) {
                            ox_w2sMatrix(g_camVP, chest, (float)abs_ScreenX, (float)abs_ScreenY, &sCh);
                            vTip = ox_w2sMatrix(g_camVP, tip, (float)abs_ScreenX, (float)abs_ScreenY, &sTip);
                            vCh = true;
                        } else {
                            sCh  = w2s_angular(chest, liveCam, &vCh);
                            sTip = w2s_angular(tip,   liveCam, &vTip);
                        }
                        if (vCh && vTip) {
                            dl->AddLine(sCh, sTip, IM_COL32(255, 210, 60, 210), esplines_thickness);
                            dl->AddCircleFilled(sTip, esplines_thickness + 1.0f, IM_COL32(255,150,40,220), 10);
                        }
                    }
                }
            }

            ox_runAimbot(liveCam, cached_players);

            // Радар-миникарта 360°: рисуется поверх всего, после боксов.
            if (radarEnabled) ox_drawRadar(getDrawList(), liveCam, cached_players);

            ImGui::PopFont();
        }
        
        drawEnd();
        usleep(1000);
    }   
    
    CloseLua();
    shutdown();
    Touch_Close();
    return 0;
} 

// ============================================================================
//  GLASS UI — визуальный слой меню (dark-glass идиома "Trial Engine v4").
//  Только Dear ImGui-рисование. Ни одна привязка (&espdraw, &aimm, ...) и ни
//  один диапазон/дефолт не тронуты — это чистый рескин поверх тех же данных.
//  Портировано: iOS-тумблеры с пружиной, градиентные слайдеры со свечением
//  и live-значением, сегмент-контролы с едущей акцент-пилюлей, sidebar/bottom
//  навигация с анимированным индикатором, 5 акцент-тем, fade между вкладками,
//  мягкие тени, фрост-панели, watermark-чип, редизайн счётчика врагов.
// ============================================================================
// Масштаб UI под большой экран (стиль уже ×3 при init; Layout_tick_UI ставит
// 3.0f каждый кадр). Объявлен ДО namespace oxui — сборка токенов читает его.
static float g_uiScale = 1.0f;

// ============================================================================
//  RENDER PATH INSTRUMENTATION + ADAPTIVE QUALITY (perf, no visual change)
//
//  Всё в этом блоке — чистая оптимизация пути отрисовки меню. Ни один
//  game-facing глобал не читается/не пишется; геометрия, цвета, позиции и
//  состав виджетов не меняются (адаптив трогает ТОЛЬКО число слоёв эффектов).
// ============================================================================
namespace oxperf {

// ---- opt-in on-screen readout ----------------------------------------------
// Выключен по умолчанию. Включается ТОЛЬКО через env OX_UI_PERF_HUD=1 (читается
// один раз) — не пользовательская опция, в меню не появляется. Показывает
// vtx/idx/cmds/tex прошлого кадра маленькой строкой в правом-верхнем углу.
static bool ox_perfHudEnabled() {
    static int cached = -1;
    if (cached < 0) {
        const char* e = getenv("OX_UI_PERF_HUD");
        cached = (e && e[0] == '1') ? 1 : 0;
    }
    return cached != 0;
}

// Счётчики прошлого кадра (заполняются в конце кадра из GetDrawData()).
struct FrameStats { int vtx = 0, idx = 0, cmds = 0, texBinds = 0; };
static FrameStats g_lastStats;

// Считывает GetDrawData() ПОСЛЕ ImGui::Render(): суммарные вершины/индексы,
// число непустых draw-команд и число смен текстуры (батч-брейков). Также
// (по желанию) льёт строку в OXLOGI раз в ~2 секунды.
static void ox_captureFrameStats() {
    ImDrawData* dd = ImGui::GetDrawData();
    if (!dd) return;
    FrameStats s;
    s.vtx = dd->TotalVtxCount;
    s.idx = dd->TotalIdxCount;
    ImTextureID prev = (ImTextureID)(intptr_t)-1; bool first = true;
    for (int l = 0; l < dd->CmdListsCount; ++l) {
        const ImDrawList* cl = dd->CmdLists[l];
        for (int c = 0; c < cl->CmdBuffer.Size; ++c) {
            const ImDrawCmd& cmd = cl->CmdBuffer[c];
            if (cmd.UserCallback || cmd.ElemCount == 0) continue;
            s.cmds++;
            ImTextureID t = cmd.GetTexID();
            if (first || t != prev) { s.texBinds++; prev = t; first = false; }
        }
    }
    g_lastStats = s;
}

// ---- adaptive quality ------------------------------------------------------
// 0 = full effects, 1 = reduced glow/shadow, 2 = minimal. Выводится из
// сглаженного io.DeltaTime с гистерезисом (чтобы не осциллировать на границе).
//  вход в 1: сглаж. кадр > 22мс сустейн; вход в 2: > 33мс; возврат с запасом.
static float g_smoothFrameMs = 16.6f;   // EMA времени кадра
static int   g_quality = 0;

static void ox_updateQuality(float dtSeconds) {
    float ms = dtSeconds * 1000.0f;
    if (ms < 1.0f)  ms = 1.0f;           // защита от нулевого/битого dt
    if (ms > 200.0f) ms = 200.0f;        // hitch-кадр не задирает EMA до потолка
    // EMA ~0.5с постоянная времени при 60fps (alpha 0.03) — реагирует на
    // устойчивую просадку, игнорирует единичные всплески.
    g_smoothFrameMs += (ms - g_smoothFrameMs) * 0.03f;

    // Пороги с гистерезисом: подъём уровня раньше, спуск — с запасом.
    // up:   >22мс -> >=1,  >33мс -> 2
    // down: <17мс -> <=1,  <27мс -> <=1 (из 2)
    switch (g_quality) {
        case 0: if (g_smoothFrameMs > 22.0f) g_quality = 1; break;
        case 1:
            if (g_smoothFrameMs > 33.0f)      g_quality = 2;
            else if (g_smoothFrameMs < 17.0f) g_quality = 0;
            break;
        default: /* 2 */
            if (g_smoothFrameMs < 27.0f)      g_quality = 1;
            break;
    }
}

} // namespace oxperf

// Внутренний уровень качества эффектов (0 full / 1 reduced / 2 minimal).
// НЕ пользовательский. Меняет только фиделити эффектов (число слоёв свечения/
// тени, зерно, субдивизии градиента) — layout/геометрия/виджеты неизменны.
static int ox_uiQuality() { return oxperf::g_quality; }

// Считать статистику отрисовки прошлого кадра. Зовётся из drawEnd() ПОСЛЕ
// ImGui::Render() (draw.cpp). Дёшево: проход по CmdBuffer'ам, без аллокаций.
void ox_uiCaptureFrameStats() { oxperf::ox_captureFrameStats(); }

// ---- Хостинг расшифрованных oxorany-строк на всё время процесса -----------
// oxorany(...) возвращает указатель в буфер ВРЕМЕННОГО объекта — валиден только
// в пределах выражения. Чтобы «расшифровать один раз и переиспользовать
// указатель», делаем ОДНУ постоянную копию при первом вызове (static init).
// Никаких per-frame аллокаций: копия создаётся единожды за строку и живёт до
// конца процесса (как строковый литерал). Использование:
//   static const char* X = ox_persist(oxorany("..."));
static const char* ox_persist(const char* decryptedInExpr) {
    return strdup(decryptedInExpr);   // одноразовая копия на всё время процесса
}

namespace oxui {
    // Акцент-темы (a = ядро, b = свечение). Violet ≈ родная магента билда.
    struct AccentDef { const char* name; ImU32 a, b; };
    static const AccentDef kAccents[] = {
        { "Aurora", IM_COL32( 88,196,255,255), IM_COL32(120,120,255,255) },
        { "Violet", IM_COL32(224,100,220,255), IM_COL32(150, 96,240,255) },
        { "Mint",   IM_COL32( 60,230,180,255), IM_COL32( 70,200,255,255) },
        { "Ember",  IM_COL32(255,150, 74,255), IM_COL32(255, 92,120,255) },
        { "Rose",   IM_COL32(255,110,160,255), IM_COL32(255,150,120,255) },
    };
    static const int kAccentCount = (int)(sizeof(kAccents) / sizeof(kAccents[0]));

    struct Palette {
        ImU32 bg0, bg1;
        ImU32 panel, panelHi;
        ImU32 stroke;
        ImU32 text, textDim, textFaint;
        ImU32 accent, accentHi;
        ImU32 track;
        ImU32 good, warn, danger;
    };

    // Свободный акцент из color picker'а. Если g_accentTheme == -1 — палитра
    // берёт цвет отсюда (ImVec4 rgba 0..1), иначе из пресета kAccents.
    static ImVec4 g_customAccent = ImVec4(0.486f, 0.302f, 1.000f, 1.0f); // #7C4DFF

    static inline ImU32 Vec4ToU32(const ImVec4 &c) {
        return IM_COL32((int)(c.x * 255.f + 0.5f), (int)(c.y * 255.f + 0.5f),
                        (int)(c.z * 255.f + 0.5f), (int)(c.w * 255.f + 0.5f));
    }
    // ------------------------------------------------------------------------
    //  DESIGN TOKENS — единый источник визуальных констант меню.
    //
    //  Слои:
    //   * цветовая рампа — производится от активного акцента: движение color
    //     picker'а пересобирает ВСЁ (поверхности, свечения, textOnAccent);
    //   * типографика fs* — АБСОЛЮТНЫЕ px текущего кадра. База: rem =
    //     GetFontSize() × 0.75 × g_uiScale (24dp при штатном 32px OPPOSans на
    //     ×3-экране) — множители 1.35/0.95/0.72/0.62/0.5/0.42 ложатся на
    //     фактические размеры текста виджетов;
    //   * spacing sp1..sp6, радиусы r*, тач-габариты hitMin/rowH и
    //     компонентные метрики — в dp: на месте использования умножать на
    //     g_uiScale (или хелпер Px());
    //   * elev1..3 — пресеты мягкой тени (blur/spread в dp + альфа);
    //   * движение mFast/mBase/mSlow, springSoft/springSnappy — rate-константы
    //     для Anim()/Approach(): k = 1 − exp(−rate·dt), rate ≈ 1/τ
    //     (mFast = 1/0.06s, mBase = 1/0.12s, mSlow = 1/0.20s).
    //
    //  Пересборка: RebuildTokens() внутри MakePalette() — каждый кадр в начале
    //  Layout_tick_UI. Palette теперь ПРОЕКЦИЯ токенов: легаси-имена g_pal.*
    //  продолжают компилироваться и дают те же значения, что g_tk.*.
    // ------------------------------------------------------------------------

    // ---- изинги / движение ----
    static inline float Clamp01(float t) { return t < 0.f ? 0.f : (t > 1.f ? 1.f : t); }
    static inline float EaseOutCubic(float t) {
        t = Clamp01(t); float u = 1.0f - t; return 1.0f - u * u * u;
    }
    static inline float EaseInOutCubic(float t) {
        t = Clamp01(t);
        return t < 0.5f ? 4.0f * t * t * t : 1.0f - powf(-2.0f * t + 2.0f, 3.0f) * 0.5f;
    }
    // Overshoot-изинг: лёгкий «перелёт» с возвратом (кнопка тумблера).
    static inline float EaseOutBack(float t) {
        t = Clamp01(t);
        const float c1 = 1.70158f, c3 = c1 + 1.0f;
        float u = t - 1.0f;
        return 1.0f + c3 * u * u * u + c1 * u * u;
    }
    // Кадро-независимое экспоненциальное приближение cur -> target.
    // dt клампится к 50мс: подвисший кадр даёт большой шаг, но не телепорт.
    static inline float Approach(float cur, float target, float rate, float dt) {
        if (dt < 0.f) dt = 0.f; if (dt > 0.05f) dt = 0.05f;
        return cur + (target - cur) * (1.0f - expf(-rate * dt));
    }

    // ---- мелкие цветовые хелперы (нужны сборке токенов — объявлены до неё) --
    static inline ImU32 Fade(ImU32 c, float a) {
        ImVec4 v = ImGui::ColorConvertU32ToFloat4(c);
        v.w *= (a < 0.f ? 0.f : (a > 1.f ? 1.f : a));
        return ImGui::ColorConvertFloat4ToU32(v);
    }
    static inline ImU32 MixU32(ImU32 x, ImU32 y, float t) {
        t = (t < 0.f ? 0.f : (t > 1.f ? 1.f : t));
        ImVec4 a = ImGui::ColorConvertU32ToFloat4(x);
        ImVec4 b = ImGui::ColorConvertU32ToFloat4(y);
        return ImGui::ColorConvertFloat4ToU32(ImVec4(
            a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t,
            a.z + (b.z - a.z) * t, a.w + (b.w - a.w) * t));
    }
    // ---- кэш CalcTextSize для СТАТИЧЕСКИХ строк -----------------------------
    // Виджеты зовут CalcTextSize каждый кадр на неизменных лейблах. Шейпинг
    // (обход глифов) не бесплатен, особенно при полном диапазоне глифов шрифта.
    // Кэшируем ширину/высоту в ImGuiStorage окна, ключ = хеш(указатель строки +
    // размер шрифта). Указатель строки стабилен (это литерал/итог oxorany,
    // живущий весь процесс), а размер шрифта в ключе инвалидирует кэш при смене
    // масштаба. Только для строк, у которых указатель НЕ переиспользуется под
    // другой контент (лейблы, заголовки) — для форматированных буферов (buf[])
    // кэш НЕ применяется. Результат идентичен CalcTextSizeA.
    static inline ImVec2 CalcTextSizeCached(ImFont* f, float sz, const char* s) {
        ImGuiStorage* st = ImGui::GetStateStorage();
        // ключ: смешиваем адрес строки и квантованный размер шрифта.
        ImU32 fk = (ImU32)(sz * 16.0f + 0.5f);
        ImGuiID key = ImHashData(&s, sizeof(s));
        key = ImHashData(&fk, sizeof(fk), key);
        ImGuiID kx = key ^ 0x1u, ky = key ^ 0x2u;
        float cw = st->GetFloat(kx, -1.0f);
        if (cw >= 0.0f) return ImVec2(cw, st->GetFloat(ky, 0.0f));
        ImVec2 v = f->CalcTextSizeA(sz, FLT_MAX, 0.0f, s);
        st->SetFloat(kx, v.x);
        st->SetFloat(ky, v.y);
        return v;
    }

    // Кадро-независимое сглаживание, состояние — в storage окна. rate берётся
    // из токенов движения (g_tk.mFast / g_tk.springSnappy / ...).
    static float Anim(ImGuiID id, float target, float speed) {
        ImGuiStorage* st = ImGui::GetStateStorage();
        float cur = st->GetFloat(id, target);
        cur = Approach(cur, target, speed, ImGui::GetIO().DeltaTime);
        if (fabsf(target - cur) < 0.0009f) cur = target;
        st->SetFloat(id, cur);
        return cur;
    }

    // Асимметричное сглаживание: вход (рост значения) быстрым rate, выход —
    // медленным. Ощущение «fast-in / slow-out» для hover/press состояний:
    // подсветка вспыхивает мгновенно, гаснет заметно мягче.
    static float AnimAsym(ImGuiID id, float target, float rateIn, float rateOut) {
        ImGuiStorage* st = ImGui::GetStateStorage();
        float cur = st->GetFloat(id, target);
        cur = Approach(cur, target, target > cur ? rateIn : rateOut,
                       ImGui::GetIO().DeltaTime);
        if (fabsf(target - cur) < 0.0009f) cur = target;
        st->SetFloat(id, cur);
        return cur;
    }

    // ---- физическая пружина -------------------------------------------------
    // Позиция + скорость живут в storage (id, id+1). Полукритическое
    // демпфирование: ω = 32 рад/с, ζ ≈ 0.68 → ОДИН перелёт ~5–6%, установление
    // ~180мс, без видимого звона. Семи-неявный Эйлер с равными подшагами ≤8мс —
    // стабильно и кадро-независимо вплоть до dt = 50мс (кламп).
    //   v += (target - pos) * stiffness * h;  v *= exp(-damping * h);  pos += v * h;
    static const float kSpringStiff = 1024.0f;  // ω² (ω = 32 рад/с)
    static const float kSpringDamp  = 43.5f;    // 2ζω (ζ ≈ 0.68)
    static float Spring(ImGuiID id, float target, float stiffness, float damping) {
        ImGuiStorage* st = ImGui::GetStateStorage();
        float pos = st->GetFloat(id, target);
        float vel = st->GetFloat(id + 1, 0.0f);
        if (pos == target && vel == 0.0f) return pos;   // покой — ноль работы
        float dt = ImGui::GetIO().DeltaTime;
        if (dt < 0.0f) dt = 0.0f; if (dt > 0.05f) dt = 0.05f;
        int n = 1 + (int)(dt * 125.0f);                 // подшаги ≤8мс (≤7 шт)
        float h = dt / (float)n;
        float dmp = expf(-damping * h);
        for (int i = 0; i < n; ++i) {
            vel += (target - pos) * stiffness * h;
            vel *= dmp;
            pos += vel * h;
        }
        if (fabsf(target - pos) < 0.001f && fabsf(vel) < 0.02f) {
            pos = target; vel = 0.0f;                   // защёлка покоя
        }
        st->SetFloat(id, pos);
        st->SetFloat(id + 1, vel);
        return pos;
    }
    // Скорость пружины (для «дыхания» ширины плашки и т.п.).
    static inline float SpringVel(ImGuiID id) {
        return ImGui::GetStateStorage()->GetFloat(id + 1, 0.0f);
    }

    // ---- HSV-производные акцента (через ImGui::ColorConvertRGBtoHSV/HSVtoRGB)
    // accentHi: тот же тон, насыщенность ×0.82, value дожат к 1.0 (кламп).
    static inline ImU32 AccentLift(ImU32 accent) {
        ImVec4 c = ImGui::ColorConvertU32ToFloat4(accent);
        float h, s, v; ImGui::ColorConvertRGBtoHSV(c.x, c.y, c.z, h, s, v);
        s *= 0.82f;
        v += (1.0f - v) * 0.60f; if (v > 1.0f) v = 1.0f;
        float r, g, b; ImGui::ColorConvertHSVtoRGB(h, s, v, r, g, b);
        return ImGui::ColorConvertFloat4ToU32(ImVec4(r, g, b, c.w));
    }
    // accentPress: тот же тон/насыщенность, value ×0.78 (нажатое состояние).
    static inline ImU32 AccentPressed(ImU32 accent) {
        ImVec4 c = ImGui::ColorConvertU32ToFloat4(accent);
        float h, s, v; ImGui::ColorConvertRGBtoHSV(c.x, c.y, c.z, h, s, v);
        v *= 0.78f;
        float r, g, b; ImGui::ColorConvertHSVtoRGB(h, s, v, r, g, b);
        return ImGui::ColorConvertFloat4ToU32(ImVec4(r, g, b, c.w));
    }
    // Относительная люминанса (sRGB -> linear, коэффициенты WCAG).
    static inline float RelLuminance(ImU32 col) {
        ImVec4 c = ImGui::ColorConvertU32ToFloat4(col);
        auto lin = [](float u) {
            return u <= 0.04045f ? u / 12.92f : powf((u + 0.055f) / 1.055f, 2.4f);
        };
        return 0.2126f * lin(c.x) + 0.7152f * lin(c.y) + 0.0722f * lin(c.z);
    }
    // Текст на акценте: почти-чёрный либо почти-белый — что даёт больший
    // WCAG-контраст. L≈0.1925 — точка равного контраста этих двух чернил.
    static inline ImU32 PickTextOnAccent(ImU32 accent) {
        return RelLuminance(accent) >= 0.1925f ? IM_COL32(14, 12, 20, 255)
                                               : IM_COL32(245, 243, 250, 255);
    }
    // Более светлый вариант акцента (легаси-имя; теперь честный HSV-lift
    // вместо наивного поканального подъёма). Сигнатура сохранена — на неё
    // ссылается вкладка Settings (custom-свотч).
    static inline ImU32 Vec4ToU32Hi(const ImVec4 &c) { return AccentLift(Vec4ToU32(c)); }

    // ---- структура токенов ----
    struct Tokens {
        // Поверхности (3 уровня фона; тонированы ТОНОМ акцента).
        ImU32 bgDeep, bgBase, bgRaised;
        // Панели: белые альфа-слои поверх фона, 4 уровня «подъёма».
        ImU32 panel0, panel1, panel2, panel3;
        // Обводки.
        ImU32 strokeSoft, strokeBase, strokeStrong;
        // Текст.
        ImU32 textHi, textBase, textDim, textFaint, textOnAccent;
        // Акцент.
        ImU32 accent, accentHi, accentGlow, accentPress;
        // Семантика.
        ImU32 good, warn, danger, info;
        // Трек/заливка контролов.
        ImU32 trackBase, trackFill;
        // Чернила кнопок-«шайб» (тумблер/слайдер).
        ImU32 knobFill, knobShadow;

        // Типографика: АБСОЛЮТНЫЕ px кадра (rem = GetFontSize()·0.75·g_uiScale).
        float fsDisplay, fsHeading, fsBody, fsLabel, fsCaption, fsMicro;

        // Спейсинг (dp; умножать на g_uiScale / Px()).
        float sp1, sp2, sp3, sp4, sp5, sp6;

        // Радиусы (dp). Полная пилюля — хелпер RPill(heightPx).
        float rSm, rMd, rLg, rXl;

        // Линии (dp): strokeW — обводка контролов, dividerW — разделитель.
        float strokeW, dividerW;

        // Тени: пресеты высоты (blur/spread в dp, alpha 0..1) для SoftShadow.
        struct Elev { float blur, spread, alpha; };
        Elev elev1, elev2, elev3;

        // Движение: rate для Anim()/Approach() (k = 1 − exp(−rate·dt)).
        float mFast, mBase, mSlow;        // 1/0.06s, 1/0.12s, 1/0.20s
        float springSoft, springSnappy;   // мягкая/резкая пружина

        // Тач-габариты (dp): минимальная цель и высота ряда Toggle/Slider.
        float hitMin, rowH;

        // Компонентные метрики (dp) — чтобы виджеты не держали магию.
        float tglTrackW, tglTrackH, tglInset, glowPad;    // тумблер
        float sldTrackH, sldKnobR, sldKnobRHot, sldGlowPad; // слайдер
        float dotR, btnH, swatchSz, knobShadowDy;         // легенда/кнопка/свотч

        // Альфы состояний.
        float glowA;              // свечение акцента у контролов
        float ghostA, ghostHotA;  // заливка ghost-кнопки (idle/hover)
        float borderA, borderHotA;// обводка ghost-кнопки (idle/hover)
    };
    static Tokens g_tk;

    // dp -> px текущего кадра.
    static inline float Px(float dp) { return dp * g_uiScale; }
    // rPill: радиус полной пилюли от фактической высоты в px.
    static inline float RPill(float heightPx) { return heightPx * 0.5f; }

    // Пересборка токенов от активного акцента. Вызывается каждый кадр из
    // MakePalette() (начало Layout_tick_UI) — токены живут в g_tk.
    static void RebuildTokens(int accentIdx) {
        Tokens& t = g_tk;

        // ---- акцент: ядро + hi ----
        if (accentIdx < 0) {                       // -1 => пользовательский цвет
            t.accent   = Vec4ToU32(g_customAccent);
            t.accentHi = AccentLift(t.accent);     // HSV: s×0.82, v→1.0
        } else {
            int i = accentIdx >= kAccentCount ? kAccentCount - 1 : accentIdx;
            t.accent   = kAccents[i].a;
            t.accentHi = kAccents[i].b;            // кураторская двухтоновая пара
        }
        t.accentGlow   = Fade(t.accent, 0.24f);
        t.accentPress  = AccentPressed(t.accent);
        t.textOnAccent = PickTextOnAccent(t.accent);

        // ---- поверхности: тон акцента, тёмные value (глубина -> подъём) ----
        float ah, asat, aval;
        {
            ImVec4 a4 = ImGui::ColorConvertU32ToFloat4(t.accent);
            ImGui::ColorConvertRGBtoHSV(a4.x, a4.y, a4.z, ah, asat, aval);
        }
        auto surf = [&ah](float sat, float val) -> ImU32 {
            float r, g, b;
            ImGui::ColorConvertHSVtoRGB(ah, sat, val, r, g, b);
            return ImGui::ColorConvertFloat4ToU32(ImVec4(r, g, b, 1.0f));
        };
        t.bgDeep   = surf(0.46f, 0.062f);
        t.bgBase   = surf(0.42f, 0.110f);
        t.bgRaised = surf(0.38f, 0.152f);

        t.panel0 = IM_COL32(255, 255, 255,  8);
        t.panel1 = IM_COL32(255, 255, 255, 12);
        t.panel2 = IM_COL32(255, 255, 255, 22);
        t.panel3 = IM_COL32(255, 255, 255, 34);

        t.strokeSoft   = IM_COL32(255, 255, 255, 14);
        t.strokeBase   = IM_COL32(255, 255, 255, 26);
        t.strokeStrong = IM_COL32(255, 255, 255, 46);

        t.textHi    = IM_COL32(246, 244, 252, 255);
        t.textBase  = IM_COL32(238, 236, 247, 255);
        t.textDim   = IM_COL32(172, 166, 190, 255);
        t.textFaint = IM_COL32(124, 120, 142, 255);

        t.good   = IM_COL32( 74, 222, 150, 255);
        t.warn   = IM_COL32(255, 196,  84, 255);
        t.danger = IM_COL32(255,  96, 110, 255);
        t.info   = IM_COL32( 96, 168, 255, 255);

        t.trackBase = IM_COL32(255, 255, 255, 30);
        t.trackFill = t.accent;

        t.knobFill   = IM_COL32(255, 255, 255, 255);
        t.knobShadow = IM_COL32(0, 0, 0, 76);

        // ---- типографика (px кадра; уважает загруженный шрифт) ----
        const float rem = ImGui::GetFontSize() * 0.75f * g_uiScale;
        t.fsDisplay = rem * 1.35f;
        t.fsHeading = rem * 0.95f;
        t.fsBody    = rem * 0.72f;
        t.fsLabel   = rem * 0.62f;
        t.fsCaption = rem * 0.50f;
        t.fsMicro   = rem * 0.42f;

        // ---- спейсинг / радиусы / линии (dp) ----
        t.sp1 = 4.0f; t.sp2 = 8.0f; t.sp3 = 12.0f;
        t.sp4 = 16.0f; t.sp5 = 24.0f; t.sp6 = 32.0f;
        t.rSm = 8.0f; t.rMd = 12.0f; t.rLg = 16.0f; t.rXl = 22.0f;
        t.strokeW = 1.2f; t.dividerW = 1.0f;

        // ---- тени ----
        t.elev1 = { 8.0f, 0.0f, 0.30f };
        t.elev2 = { 14.0f, 2.0f, 0.42f };
        t.elev3 = { 22.0f, 4.0f, 0.55f };

        // ---- движение ----
        t.mFast = 1.0f / 0.06f;   // ≈16.7
        t.mBase = 1.0f / 0.12f;   // ≈8.3
        t.mSlow = 1.0f / 0.20f;   // 5.0
        t.springSoft   = 10.0f;
        t.springSnappy = 18.0f;

        // ---- тач-габариты ----
        t.hitMin = 44.0f;
        t.rowH   = 52.0f;

        // ---- компонентные метрики ----
        t.tglTrackW = 56.0f; t.tglTrackH = 30.0f; t.tglInset = 4.0f; t.glowPad = 3.0f;
        t.sldTrackH = 6.0f;  t.sldKnobR = 11.0f;  t.sldKnobRHot = 13.0f; t.sldGlowPad = 5.0f;
        t.dotR = 5.0f; t.btnH = 50.0f; t.swatchSz = 34.0f; t.knobShadowDy = 1.5f;
        t.glowA = 0.28f;
        t.ghostA = 0.18f;  t.ghostHotA = 0.30f;
        t.borderA = 0.55f; t.borderHotA = 0.95f;
    }

    // Палитра — совместимая ПРОЕКЦИЯ токенов: пересобирает g_tk и раскладывает
    // его поля по легаси-именам. Все существующие ссылки g_pal.* остаются
    // валидными и синхронны токенам по построению.
    static Palette MakePalette(int accentIdx) {
        RebuildTokens(accentIdx);
        const Tokens& t = g_tk;
        Palette p;
        p.bg0       = t.bgBase;
        p.bg1       = t.bgDeep;
        p.panel     = t.panel1;
        p.panelHi   = t.panel2;
        p.stroke    = t.strokeBase;
        p.text      = t.textBase;
        p.textDim   = t.textDim;
        p.textFaint = t.textFaint;
        p.accent    = t.accent;
        p.accentHi  = t.accentHi;
        p.track     = t.trackBase;
        p.good      = t.good;
        p.warn      = t.warn;
        p.danger    = t.danger;
        return p;
    }

    // ---- Легаси-имена: часть кода вне меню могла бы на них ссылаться. Держим
    //      совместимую палитру (не используется новым рендером, но безопасно). --
    static const ImVec4 BG       = ImVec4(0.055f, 0.045f, 0.085f, 0.97f);
    static const ImVec4 PANEL    = ImVec4(0.090f, 0.075f, 0.130f, 0.86f);
    static const ImVec4 PANEL2   = ImVec4(0.140f, 0.115f, 0.200f, 0.92f);
    static const ImVec4 PANEL3   = ImVec4(0.200f, 0.165f, 0.280f, 0.96f);
    static const ImVec4 ACCENT   = ImVec4(0.880f, 0.380f, 0.870f, 1.00f);
    static const ImVec4 ACCENT_D = ImVec4(0.600f, 0.250f, 0.600f, 1.00f);
    static const ImVec4 DANGER   = ImVec4(0.920f, 0.300f, 0.360f, 1.00f);
    static const ImVec4 DANGER_D = ImVec4(0.700f, 0.210f, 0.260f, 1.00f);
    static const ImVec4 TEXT     = ImVec4(0.950f, 0.930f, 0.970f, 1.00f);
    static const ImVec4 TEXT_DIM = ImVec4(0.620f, 0.570f, 0.700f, 1.00f);

    // Мягкая тень под скруглённым прямоугольником (сырой вариант: size в px,
    // цвет с запечённой альфой). Сигнатура сохранена — есть внешние вызовы.
    //
    //  Perf: раньше — 7 концентрических скруглённых прямоугольников (7 полных
    //  тесселляций). Внешние кольца (t→1) почти прозрачны (alpha=(1−t)² даёт
    //  ~0.02 на 7-м шаге) — визуально неразличимы. Считаем ramp по фиксированной
    //  сетке от ВНЕШНЕГО кольца к внутреннему с равным «энергетическим» шагом,
    //  так что при меньшем числе колец мягкость края сохраняется.
    //  Число колец адаптивно: q0=6, q1=4, q2=3. На q0 практически идентично
    //  прежним 7 (внешнее кольцо было почти невидимым).
    static void SoftShadow(ImDrawList* dl, ImVec2 a, ImVec2 b, float rounding, float size, ImU32 col) {
        int steps;
        switch (ox_uiQuality()) { case 2: steps = 3; break; case 1: steps = 4; break; default: steps = 6; }
        const float dy = size * 0.35f;
        // t идёт по [1/steps .. 1]; альфа (1−t)² — та же кривая, что и раньше,
        // просто на более грубой сетке. Рисуем от внешнего (слабого) к
        // внутреннему (сильному), чтобы верхние слои перекрывали нижние.
        for (int i = steps; i >= 1; --i) {
            float t  = (float)i / (float)steps;
            float ex = size * t;
            float al = (1.0f - t) * (1.0f - t);
            dl->AddRectFilled(ImVec2(a.x - ex, a.y - ex + dy),
                              ImVec2(b.x + ex, b.y + ex + dy),
                              Fade(col, al), rounding + ex, 0);
        }
    }
    // Токеновый вариант: пресет высоты (g_tk.elev1/2/3) вместо сырых blur/alpha.
    static inline void SoftShadow(ImDrawList* dl, ImVec2 a, ImVec2 b, float rounding,
                                  const Tokens::Elev& e) {
        SoftShadow(dl, a, b, rounding, (e.blur + e.spread) * g_uiScale,
                   Fade(IM_COL32(0, 0, 0, 255), e.alpha));
    }

    // ------------------------------------------------------------------------
    //  PAGE STAGGER — каскад появления страницы options.
    //  Контейнер въезжает первым (fade + 12dp направленный слайд), секции
    //  догоняют с задержкой 40мс за шаг (первые 3 секции, дальше кап) — общий
    //  бюджет перехода ~220мс: задержка ≤120мс + локальный изинг 100мс.
    //  Реализация дешёвая:
    //  один сдвиг SetCursorPosY на секцию + пост-фейд альфы вершин спана.
    //  Счётчик секций сбрасывается каждый кадр; вне options-страницы (dl ==
    //  nullptr) хелперы — no-op, так что Section() безопасен где угодно.
    // ------------------------------------------------------------------------
    static void FadeDrawListRange(ImDrawList* dl, int vtx0, float k); // ниже
    struct PageMotion {
        double      t0      = -100.0;  // время смены вкладки (GetTime)
        float       dir     = 1.0f;    // +1 вниз по навигации, -1 вверх
        float       appear  = 1.0f;    // прогресс контейнера (для пост-фейда)
        int         section = 0;       // счётчик Section() текущего кадра
        ImDrawList* dl      = nullptr; // drawlist options-child (или nullptr)
        int         spanVtx0 = 0;      // старт вершин текущего спана
        float       spanK    = 1.0f;   // альфа текущего спана
    };
    static PageMotion g_pageMo;

    // Прогресс группы g (0 = контейнер): изинг 100мс после задержки 40мс*min(g,3).
    // Последняя группа: 120мс + 100мс = 220мс — жёсткий потолок перехода.
    static float PageStaggerK(int group) {
        float delay = 0.040f * (float)(group < 3 ? group : 3);
        float t = (float)(ImGui::GetTime() - g_pageMo.t0) - delay;
        return EaseOutCubic(Clamp01(t / 0.10f));
    }
    // Закрыть текущий спан: домножить альфу его вершин на spanK.
    static void PageStaggerCloseSpan() {
        if (!g_pageMo.dl) return;
        FadeDrawListRange(g_pageMo.dl, g_pageMo.spanVtx0, g_pageMo.spanK);
        g_pageMo.spanVtx0 = g_pageMo.dl->VtxBuffer.Size;
    }
    // Граница секции: закрывает предыдущий спан, начинает новый со своей
    // задержкой; вешает на курсор остаточный сдвиг (сходит в 0 к концу изинга,
    // покоящаяся геометрия не меняется).
    static void PageStaggerSection() {
        if (!g_pageMo.dl) return;
        PageStaggerCloseSpan();
        g_pageMo.section++;
        float k = PageStaggerK(g_pageMo.section);
        g_pageMo.spanK = k;
        if (k < 0.999f)
            ImGui::SetCursorPosY(ImGui::GetCursorPosY() +
                                 (1.0f - k) * Px(10.0f) * g_pageMo.dir);
    }
    // Конец страницы: закрыть хвостовой спан и отключить стаггер до след. кадра.
    static void PageStaggerFlush() {
        if (!g_pageMo.dl) return;
        PageStaggerCloseSpan();
        g_pageMo.dl = nullptr;
    }
}

// Активная палитра текущего кадра (ставится в начале Layout_tick_UI). Виджеты
// читают её вместо глобальных ImVec4-констант.
static oxui::Palette g_pal;

// Фоновая текстура меню (см. src/menu_bg.cpp).
extern ImTextureID oxGetMenuBg(int* outW, int* outH);

// Встроенные PNG-иконки (Trial Engine "paper"): декод + загрузка в GL один раз
// (реализация в src/menu_bg.cpp, рядом с фоном — тот же stb_image TU и активный
// GL-контекст в кадре). Затем — блит через ImDrawList::AddImage вместо векторных
// глифов. Только визуал: размеры слотов и цвет-тинты сохранены 1:1.
extern void oxLoadIcons();
extern ImTextureID g_iconTexESP;
extern ImTextureID g_iconTexAim;
extern ImTextureID g_iconTexCrosshair;
extern ImTextureID g_iconTexHud;
extern ImTextureID g_iconTexPalette;
extern ImTextureID g_iconTexHealth;
extern ImTextureID g_iconTexDistance;
extern ImTextureID g_iconTexShield;
extern ImTextureID g_iconTexTarget;
extern ImTextureID g_texPreviewDummy;
extern int         g_texPreviewDummyW;
extern int         g_texPreviewDummyH;
extern ImTextureID g_iconTexBrandBadge;
// Новый набор (menu_bg.cpp): иконки навигации + бренд-знак + плёночное зерно.
extern ImTextureID g_iconTexEye;
extern ImTextureID g_iconTexLens;
extern ImTextureID g_iconTexGear;
extern ImTextureID g_texBrandMark;
extern ImTextureID g_texGrain;

// Применяет премиум тёмный стиль ОДИН раз (размеры подобраны под большой экран).
static void oxApplyStyle() {
    static bool applied = false;
    if (applied) return;
    applied = true;
    ImGuiStyle& s = ImGui::GetStyle();
    s.WindowRounding    = 42.f;  s.ChildRounding    = 28.f;
    s.FrameRounding     = 16.f;  s.GrabRounding     = 16.f;
    s.PopupRounding     = 16.f;  s.ScrollbarRounding= 16.f;
    s.WindowBorderSize  = 0.f;   s.FrameBorderSize  = 0.f;   s.ChildBorderSize = 0.f;
    s.WindowPadding     = ImVec2(30, 30);
    s.FramePadding      = ImVec2(22, 16);
    s.ItemSpacing       = ImVec2(18, 16);
    s.ItemInnerSpacing  = ImVec2(12, 10);
    s.ScrollbarSize     = 22.f;  s.GrabMinSize      = 44.f;
    using namespace oxui;
    ImVec4* c = s.Colors;
    c[ImGuiCol_WindowBg]=BG; c[ImGuiCol_ChildBg]=PANEL; c[ImGuiCol_PopupBg]=PANEL;
    c[ImGuiCol_Text]=TEXT; c[ImGuiCol_TextDisabled]=TEXT_DIM;
    c[ImGuiCol_FrameBg]=PANEL2; c[ImGuiCol_FrameBgHovered]=PANEL3; c[ImGuiCol_FrameBgActive]=PANEL3;
    c[ImGuiCol_Button]=PANEL2; c[ImGuiCol_ButtonHovered]=ACCENT_D; c[ImGuiCol_ButtonActive]=ACCENT;
    c[ImGuiCol_CheckMark]=ACCENT; c[ImGuiCol_SliderGrab]=ACCENT; c[ImGuiCol_SliderGrabActive]=ACCENT_D;
    c[ImGuiCol_Header]=PANEL2; c[ImGuiCol_HeaderHovered]=ACCENT_D; c[ImGuiCol_HeaderActive]=ACCENT;
    c[ImGuiCol_Separator]=PANEL3; c[ImGuiCol_SeparatorHovered]=ACCENT_D; c[ImGuiCol_SeparatorActive]=ACCENT;
    c[ImGuiCol_ScrollbarBg]=ImVec4(0,0,0,0); c[ImGuiCol_ScrollbarGrab]=PANEL3;
    c[ImGuiCol_ScrollbarGrabHovered]=ACCENT_D; c[ImGuiCol_ScrollbarGrabActive]=ACCENT;
    c[ImGuiCol_Border]=ImVec4(0,0,0,0);
    c[ImGuiCol_TitleBg]=PANEL; c[ImGuiCol_TitleBgActive]=PANEL;
}

// ============================================================================
//  GLASS UI — виджеты (все рисуют вручную, без ImGui::Checkbox/SliderFloat вида)
//  Каждый принимает те же указатели/диапазоны, что и старый код, — привязки
//  и границы 1:1. Меняется только внешний вид.
// ============================================================================
namespace oxui {

// iOS-тумблер с пружиной на кнопке и свечением дорожки. true = значение сменилось.
static bool Toggle(const char* label, bool* v, const char* hint = nullptr) {
    // oxorany-литералы ID расшифровываются ОДИН раз (иначе — каждый кадр на
    // каждый тумблер: obfuscation-декрипт в hot-loop). Значения фиксированы.
    static const char* ID_T  = ox_persist(oxorany("##t"));
    static const char* ID_TH = ox_persist(oxorany("##th"));
    static const char* ID_TK = ox_persist(oxorany("##tk"));
    ImGuiWindow* win = ImGui::GetCurrentWindow();
    const float s = g_uiScale;
    const float rowH = g_tk.rowH * s;
    const float pad  = g_tk.sp4 * s;
    ImVec2 pos = ImGui::GetCursorScreenPos();
    float  w   = ImGui::GetContentRegionAvail().x;

    ImGui::PushID(label);
    bool clicked = ImGui::InvisibleButton(ID_T, ImVec2(w, rowH));
    // Off-screen early-out: строка вне видимого прямоугольника скролл-региона
    // ничего не рисует. InvisibleButton выше уже продвинул layout и занял ту же
    // высоту, поэтому раскладка/скролл идентичны; клипнутый item не hoverится и
    // не кликается, так что состояние (*v) неизменно и возврат = false.
    if (!ImGui::IsItemVisible()) { ImGui::PopID(); return false; }
    bool hov = ImGui::IsItemHovered();
    ImGuiID id = win->GetID(ID_T);
    ImDrawList* dl = ImGui::GetWindowDrawList();

    // hover: быстрый вход (mFast), мягкий выход (mBase)
    float hovA = AnimAsym(win->GetID(ID_TH), hov ? 1.0f : 0.0f,
                          g_tk.mFast, g_tk.mBase);
    if (hovA > 0.001f)
        dl->AddRectFilled(pos, ImVec2(pos.x + w, pos.y + rowH), Fade(g_pal.panelHi, hovA), g_tk.rMd * s);

    float trackW = g_tk.tglTrackW * s, trackH = g_tk.tglTrackH * s;
    float knobR  = trackH * 0.5f - g_tk.tglInset * s;

    // текст (клипуется, чтобы длинная строка не наезжала на переключатель)
    float textRight = pos.x + w - pad - trackW - g_tk.sp3 * s;
    dl->PushClipRect(ImVec2(pos.x + pad, pos.y), ImVec2(textRight, pos.y + rowH), true);
    ImFont* f = ImGui::GetFont();
    float lblSz = g_tk.fsBody;
    float ty = hint ? pos.y + rowH * 0.5f - lblSz : pos.y + rowH * 0.5f - lblSz * 0.5f;
    dl->AddText(f, lblSz, ImVec2(pos.x + pad, ty), g_pal.text, label);
    if (hint)
        dl->AddText(f, g_tk.fsCaption, ImVec2(pos.x + pad, ty + lblSz * 1.15f), g_pal.textFaint, hint);
    dl->PopClipRect();

    ImVec2 tp(pos.x + w - pad - trackW, pos.y + rowH * 0.5f - trackH * 0.5f);
    if (clicked) *v = !*v;
    // Кнопка — настоящая пружина (pos+vel в storage): единичный перелёт ~6%,
    // установление ~180мс, симметрично в обе стороны. Кроссфейд дорожки идёт
    // ЧУТЬ медленнее и по другой кривой — рассинхрон и делает тумблер «физичным».
    float knobT = Spring(win->GetID(ID_TK), *v ? 1.0f : 0.0f,
                         kSpringStiff, kSpringDamp);
    if (knobT < -0.08f) knobT = -0.08f; if (knobT > 1.08f) knobT = 1.08f;
    float on = Anim(id, *v ? 1.0f : 0.0f, g_tk.mBase * 1.5f);   // цвет/свечение
    ImU32 track = MixU32(g_tk.trackBase, g_tk.trackFill, on);
    float gp = g_tk.glowPad * s;
    if (on > 0.01f)
        dl->AddRectFilled(ImVec2(tp.x - gp, tp.y - gp),
                          ImVec2(tp.x + trackW + gp, tp.y + trackH + gp),
                          Fade(g_pal.accentHi, g_tk.glowA * on), RPill(trackH + 2.0f * gp));
    dl->AddRectFilled(tp, ImVec2(tp.x + trackW, tp.y + trackH), track, RPill(trackH));
    float kx = tp.x + trackH * 0.5f + knobT * (trackW - trackH);
    ImVec2 kc(kx, tp.y + trackH * 0.5f);
    dl->AddCircleFilled(ImVec2(kc.x, kc.y + g_tk.knobShadowDy * s), knobR, g_tk.knobShadow);
    dl->AddCircleFilled(kc, knobR, g_tk.knobFill);

    ImGui::PopID();
    return clicked;
}

// Градиентный слайдер float со свечёной кнопкой и live-значением справа.
static bool SliderF(const char* label, float* v, float lo, float hi, const char* fmt) {
    static const char* ID_S   = ox_persist(oxorany("##s"));
    static const char* ID_SKR = ox_persist(oxorany("##skr"));
    static const char* ID_SGL = ox_persist(oxorany("##sgl"));
    const float s = g_uiScale;
    const float rowH = g_tk.rowH * s;
    const float pad  = g_tk.sp4 * s;
    ImVec2 pos = ImGui::GetCursorScreenPos();
    float  w   = ImGui::GetContentRegionAvail().x;

    ImGui::PushID(label);
    ImGui::InvisibleButton(ID_S, ImVec2(w, rowH));
    // Off-screen early-out (layout уже занят InvisibleButton; клипнутый слайдер
    // неактивен, значение не меняется → changed=false).
    if (!ImGui::IsItemVisible()) { ImGui::PopID(); return false; }
    bool active = ImGui::IsItemActive();
    bool hov    = ImGui::IsItemHovered();
    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImFont* f = ImGui::GetFont();

    float th = g_tk.sldTrackH * s;
    float barY = pos.y + rowH - (g_tk.sp4 * s + th * 0.5f);
    float bx0 = pos.x + pad, bx1 = pos.x + w - pad;
    float barW = bx1 - bx0;

    bool changed = false;
    if (active && barW > 1.0f) {
        float mx = (ImGui::GetIO().MousePos.x - bx0) / barW;
        mx = mx < 0.f ? 0.f : (mx > 1.f ? 1.f : mx);
        float nv = lo + mx * (hi - lo);
        if (nv != *v) { *v = nv; changed = true; }
    }
    float t = (hi > lo) ? (*v - lo) / (hi - lo) : 0.0f;
    t = t < 0.f ? 0.f : (t > 1.f ? 1.f : t);

    float topY = pos.y + g_tk.sp1 * s;
    dl->AddText(f, g_tk.fsBody, ImVec2(bx0, topY), g_pal.text, label);
    char buf[64]; snprintf(buf, sizeof(buf), fmt, *v);
    ImVec2 vsz = f->CalcTextSizeA(g_tk.fsLabel, FLT_MAX, 0, buf);
    dl->AddText(f, g_tk.fsLabel, ImVec2(bx1 - vsz.x, topY + (g_tk.fsBody - g_tk.fsLabel) * 0.5f),
                g_pal.accent, buf);

    dl->AddRectFilled(ImVec2(bx0, barY - th * 0.5f), ImVec2(bx1, barY + th * 0.5f), g_tk.trackBase, th);
    float fx = bx0 + barW * t;
    dl->AddRectFilledMultiColor(ImVec2(bx0, barY - th * 0.5f), ImVec2(fx, barY + th * 0.5f),
                                g_tk.trackFill, g_pal.accentHi, g_pal.accentHi, g_tk.trackFill);
    // Позиция кнопки при драге — 1:1 с пальцем (*v пишется прямо из MousePos,
    // без сглаживания). Анимируются только «горячесть» (радиус) и свечение.
    ImGuiWindow* win = ImGui::GetCurrentWindow();
    float hotK = AnimAsym(win->GetID(ID_SKR), (hov || active) ? 1.0f : 0.0f,
                          g_tk.mFast, g_tk.mBase);                    // масштаб кнопки
    float grabK = AnimAsym(win->GetID(ID_SGL), active ? 1.0f : 0.0f,
                           25.0f, 14.0f);        // кольцо: атака ~40мс, спад ~200мс
    float kr = (g_tk.sldKnobR + (g_tk.sldKnobRHot - g_tk.sldKnobR) * hotK) * s;
    ImVec2 kc(fx, barY);
    dl->AddCircleFilled(kc, kr + g_tk.sldGlowPad * s * (1.0f + 0.5f * grabK),
                        Fade(g_pal.accentHi, g_tk.glowA + 0.22f * grabK));
    dl->AddCircleFilled(ImVec2(kc.x, kc.y + g_tk.knobShadowDy * s), kr, g_tk.knobShadow);
    dl->AddCircleFilled(kc, kr, g_tk.knobFill);
    dl->AddCircleFilled(kc, kr * 0.42f, g_pal.accent);

    ImGui::PopID();
    return changed;
}

// Слайдер int (переиспользует float-версию, чтобы сохранить внешний вид и границы).
static bool SliderI(const char* label, int* v, int lo, int hi) {
    float fv = (float)*v;
    // формат без дробей — целочисленный вид
    bool ch = SliderF(label, &fv, (float)lo, (float)hi, "%.0f");
    int nv = (int)(fv + (fv >= 0 ? 0.5f : -0.5f));
    if (nv < lo) nv = lo; if (nv > hi) nv = hi;
    if (nv != *v) { *v = nv; return true; }
    return ch;
}

// Сегмент-контрол с едущей акцент-пилюлей. true = выбор сменился.
static bool Segmented(const char* label, int* v, const char* const items[], int count) {
    static const char* ID_SEG    = ox_persist(oxorany("seg"));
    static const char* ID_SEGBTN = ox_persist(oxorany("##seg"));
    static const char* ID_SEGPOS = ox_persist(oxorany("##segpos"));
    ImGuiWindow* win = ImGui::GetCurrentWindow();
    const float s = g_uiScale;
    const float pad = g_tk.sp4 * s;
    ImVec2 pos = ImGui::GetCursorScreenPos();
    float w = ImGui::GetContentRegionAvail().x;
    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImFont* f = ImGui::GetFont();

    // Видимость всей группы (лейбл + контрол). Layout ниже (Dummy +
    // InvisibleButton) выполняется всегда — при vis=false только пропускаем
    // рисование. Хранит идентичные раскладку/скролл/ID.
    float grpH = (label && label[0] ? g_tk.fsLabel + g_tk.sp3 * s : 0.0f) + g_tk.hitMin * s;
    bool vis = ImGui::IsRectVisible(pos, ImVec2(pos.x + w, pos.y + grpH));

    if (label && label[0]) {
        if (vis) dl->AddText(f, g_tk.fsLabel, ImVec2(pos.x + pad, pos.y), g_pal.text, label);
        ImGui::Dummy(ImVec2(0, g_tk.fsLabel + g_tk.sp3 * s));
        pos = ImGui::GetCursorScreenPos();
    }

    float segH = g_tk.hitMin * s;
    float x0 = pos.x + pad, x1 = pos.x + w - pad;
    float cellW = (x1 - x0) / (float)count;

    ImGui::PushID(label ? label : ID_SEG);
    bool clicked = ImGui::InvisibleButton(ID_SEGBTN, ImVec2(w, segH));
    if (!vis) { ImGui::PopID(); return false; }
    dl->AddRectFilled(ImVec2(x0, pos.y), ImVec2(x1, pos.y + segH), g_pal.panel, RPill(segH));
    dl->AddRect(ImVec2(x0, pos.y), ImVec2(x1, pos.y + segH), g_pal.stroke, RPill(segH), 0,
                g_tk.strokeW * s);

    bool changed = false;
    if (clicked) {
        float mx = ImGui::GetIO().MousePos.x - x0;
        int idx = (int)(mx / cellW); if (idx < 0) idx = 0; if (idx > count - 1) idx = count - 1;
        if (idx != *v) { *v = idx; changed = true; }
    }
    ImGuiID id = win->GetID(ID_SEGPOS);
    // пилюля едет пружиной (лёгкий перелёт), экскурсия клампится внутрь рамки
    float cur = Spring(id, (float)*v, kSpringStiff, kSpringDamp);
    if (cur < -0.03f) cur = -0.03f;
    if (cur > (float)(count - 1) + 0.03f) cur = (float)(count - 1) + 0.03f;
    float px = x0 + cur * cellW;
    float inset = g_tk.sp1 * s;   // инсет акцент-пилюли
    ImVec2 pa(px + inset, pos.y + inset), pb(px + cellW - inset, pos.y + segH - inset);
    dl->AddRectFilled(ImVec2(pa.x - 1, pa.y - 1), ImVec2(pb.x + 1, pb.y + 1),
                      Fade(g_pal.accentHi, g_tk.glowA), RPill(segH - 2.0f * inset));
    dl->AddRectFilledMultiColor(pa, pb, g_pal.accent, g_pal.accentHi, g_pal.accentHi, g_pal.accent);

    for (int i = 0; i < count; ++i) {
        ImVec2 sz = CalcTextSizeCached(f, g_tk.fsLabel, items[i]);   // статичные ярлыки
        float cellCx = x0 + (i + 0.5f) * cellW;
        bool sel = (i == *v);
        dl->AddText(f, g_tk.fsLabel, ImVec2(cellCx - sz.x * 0.5f, pos.y + segH * 0.5f - sz.y * 0.5f),
                    sel ? g_tk.textOnAccent : g_pal.textDim, items[i]);
    }
    ImGui::PopID();
    return changed;
}

// Заголовок-секция: мелкий caps-лейбл + тонкая линия справа.
static void Section(const char* text) {
    const float s = g_uiScale;
    PageStaggerSection();   // каскад страницы: секция стартует с задержкой (всегда)
    ImGui::Dummy(ImVec2(0, g_tk.sp2 * s));
    ImVec2 pos = ImGui::GetCursorScreenPos();
    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImFont* f = ImGui::GetFont();
    float sz = g_tk.fsCaption;
    ImVec2 tsz = CalcTextSizeCached(f, sz, text);   // статичный заголовок секции
    // Off-screen: пропускаем рисование, layout (Dummy'и) сохраняется 1:1.
    bool vis = ImGui::IsRectVisible(pos, ImVec2(pos.x + ImGui::GetContentRegionAvail().x, pos.y + tsz.y));
    if (vis) {
        dl->AddText(f, sz, ImVec2(pos.x + g_tk.sp4 * s, pos.y), g_pal.textFaint, text);
        dl->AddLine(ImVec2(pos.x + g_tk.sp4 * s + tsz.x + g_tk.sp3 * s, pos.y + tsz.y * 0.5f),
                    ImVec2(pos.x + ImGui::GetContentRegionAvail().x - g_tk.sp4 * s, pos.y + tsz.y * 0.5f),
                    g_tk.strokeBase, g_tk.dividerW * s);
    }
    ImGui::Dummy(ImVec2(0, tsz.y + g_tk.sp3 * s));
}

// Строка-подсказка (заменяет прежние TextColored(TEXT_DIM, ...)); клип по ширине.
static void Hint(const char* text) {
    const float s = g_uiScale;
    ImVec2 pos = ImGui::GetCursorScreenPos();
    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImFont* f = ImGui::GetFont();
    float w = ImGui::GetContentRegionAvail().x;
    float sz = g_tk.fsCaption;
    bool vis = ImGui::IsRectVisible(pos, ImVec2(pos.x + w, pos.y + sz + g_tk.sp1 * s));
    ImGui::Dummy(ImVec2(0, sz + g_tk.sp1 * s));
    if (vis)
        dl->AddText(f, sz, ImVec2(pos.x + g_tk.sp4 * s, pos.y + g_tk.sp1 * 0.5f * s), g_pal.textFaint,
                    text, nullptr, w - (g_tk.sp4 + g_tk.sp2) * s);
}

// Два цветовых свотча-точки (Visible / Behind wall) — компактная легенда.
static void LegendDot(ImU32 col, const char* text, bool sameLine) {
    const float s = g_uiScale;
    if (sameLine) ImGui::SameLine();
    ImVec2 pos = ImGui::GetCursorScreenPos();
    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImFont* f = ImGui::GetFont();
    float sz = g_tk.fsCaption;
    ImVec2 tsz = CalcTextSizeCached(f, sz, text);   // статичная подпись легенды
    float r = g_tk.dotR * s;
    bool vis = ImGui::IsRectVisible(pos, ImVec2(pos.x + g_tk.sp4 * s + r * 2 + g_tk.sp3 * s + tsz.x,
                                                pos.y + tsz.y + g_tk.sp1 * s));
    if (vis) {
        dl->AddCircleFilled(ImVec2(pos.x + g_tk.sp4 * s + r, pos.y + tsz.y * 0.5f + g_tk.sp1 * 0.5f * s), r, col);
        dl->AddText(f, sz, ImVec2(pos.x + g_tk.sp4 * s + r * 2 + g_tk.sp2 * s, pos.y + g_tk.sp1 * 0.5f * s),
                    g_pal.textDim, text);
    }
    ImGui::Dummy(ImVec2(g_tk.sp4 * s + r * 2 + g_tk.sp3 * s + tsz.x, tsz.y + g_tk.sp1 * s));
}

// Кнопка-действие (например «Exit»). tone: 0 danger, 1 accent.
static bool ActionButton(const char* label, int tone) {
    static const char* ID_ACT = ox_persist(oxorany("##act"));
    static const char* ID_AH  = ox_persist(oxorany("##ah"));
    static const char* ID_AP  = ox_persist(oxorany("##ap"));
    const float s = g_uiScale;
    ImVec2 pos = ImGui::GetCursorScreenPos();
    float w = ImGui::GetContentRegionAvail().x;
    float h = g_tk.btnH * s;
    ImGui::PushID(label);
    bool clicked = ImGui::InvisibleButton(ID_ACT, ImVec2(w, h));
    if (!ImGui::IsItemVisible()) { ImGui::PopID(); return false; }
    bool hov = ImGui::IsItemHovered();
    bool held = ImGui::IsItemActive();
    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImFont* f = ImGui::GetFont();
    ImGuiWindow* win = ImGui::GetCurrentWindow();
    // hover/press: быстрый вход, мягкий выход; press с атакой ~40мс
    float hovA   = AnimAsym(win->GetID(ID_AH), (hov || held) ? 1.0f : 0.0f,
                            g_tk.mFast, g_tk.mBase);
    float pressA = AnimAsym(win->GetID(ID_AP), held ? 1.0f : 0.0f,
                            25.0f, g_tk.mBase);
    ImU32 base = (tone == 0) ? g_tk.danger : g_tk.accent;
    dl->AddRectFilled(pos, ImVec2(pos.x + w, pos.y + h),
                      Fade(base, g_tk.ghostA + (g_tk.ghostHotA - g_tk.ghostA) * hovA
                                 + 0.10f * pressA), g_tk.rMd * s);
    dl->AddRect(pos, ImVec2(pos.x + w, pos.y + h),
                Fade(base, g_tk.borderA + (g_tk.borderHotA - g_tk.borderA) * hovA),
                g_tk.rMd * s, 0, g_tk.strokeW * s * (1.0f + 0.4f * pressA));
    ImVec2 tsz = CalcTextSizeCached(f, g_tk.fsBody, label);   // статичный лейбл кнопки
    dl->AddText(f, g_tk.fsBody, ImVec2(pos.x + w * 0.5f - tsz.x * 0.5f, pos.y + h * 0.5f - tsz.y * 0.5f),
                base, label);
    ImGui::PopID();
    return clicked;
}

// ColorEdit-обёртка: маленький свотч, тап открывает штатный пикер (popup).
static void ColorSwatch(const char* label, float col[3]) {
    static const char* ID_SWROW = ox_persist(oxorany("##swrow"));
    static const char* ID_SWPOP = ox_persist(oxorany("##swpop"));
    static const char* ID_SWH   = ox_persist(oxorany("##swh"));
    static const char* ID_PICK  = ox_persist(oxorany("##pick"));
    const float s = g_uiScale;
    ImVec2 pos = ImGui::GetCursorScreenPos();
    float w = ImGui::GetContentRegionAvail().x;
    float rowH = g_tk.hitMin * s;
    float sw = g_tk.swatchSz * s;
    ImGui::PushID(label);
    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImFont* f = ImGui::GetFont();
    // весь ряд — кликабельная зона, открывающая пикер (крупная тач-цель)
    bool clicked = ImGui::InvisibleButton(ID_SWROW, ImVec2(w, rowH));
    // Off-screen early-out: строка вне видимости не рисует свотч. Но если popup
    // пикера уже открыт (BeginPopup ниже), его нужно поддержать всегда — иначе
    // прокрутка родителя закрыла бы открытый выбор цвета. Обычно popup закрыт,
    // так что клипнутая строка выходит здесь без рисования.
    bool popupOpen = ImGui::IsPopupOpen(ID_SWPOP);
    if (!ImGui::IsItemVisible() && !popupOpen) { ImGui::PopID(); return; }
    if (clicked) ImGui::OpenPopup(ID_SWPOP);
    // hover-подсветка ряда: fast-in / slow-out, в покое невидима
    float hovA = AnimAsym(ImGui::GetCurrentWindow()->GetID(ID_SWH),
                          ImGui::IsItemHovered() ? 1.0f : 0.0f, g_tk.mFast, g_tk.mBase);
    if (hovA > 0.001f)
        dl->AddRectFilled(pos, ImVec2(pos.x + w, pos.y + rowH),
                          Fade(g_pal.panelHi, hovA), g_tk.rMd * s);
    dl->AddText(f, g_tk.fsBody, ImVec2(pos.x + g_tk.sp4 * s, pos.y + rowH * 0.5f - g_tk.fsBody * 0.5f),
                g_pal.text, label);
    ImVec2 sa(pos.x + w - g_tk.sp4 * s - sw, pos.y + rowH * 0.5f - sw * 0.5f);
    ImVec2 sb(sa.x + sw, sa.y + sw);
    ImU32 cc = IM_COL32((int)(col[0] * 255), (int)(col[1] * 255), (int)(col[2] * 255), 255);
    dl->AddRectFilled(sa, sb, cc, g_tk.rSm * s);
    dl->AddRect(sa, sb, g_pal.stroke, g_tk.rSm * s, 0, g_tk.strokeW * s);
    // popup якорим у свотча
    ImGui::SetNextWindowPos(ImVec2(sa.x, sb.y + g_tk.sp2 * s), ImGuiCond_Appearing, ImVec2(0, 0));
    if (ImGui::BeginPopup(ID_SWPOP)) {
        ImGui::ColorPicker3(ID_PICK, col,
            ImGuiColorEditFlags_NoSidePreview | ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoLabel);
        ImGui::EndPopup();
    }
    ImGui::PopID();
}

} // namespace oxui

// ============================================================================
//  CLICK BAR - толстая горизонтальная полоска в левом верхнем углу экрана.
//  Тап по ней открывает/закрывает меню. Обводка в текущем акцентном цвете
//  (меняется живьём через color picker в Settings). Счётчик врагов убран.
// ============================================================================
static void oxDrawClickBar(const ImVec2& ds) {
    using namespace oxui;
    (void)ds;
    // oxorany-литералы клик-бара расшифровываются ОДИН раз (клик-бар рисуется
    // КАЖДЫЙ кадр, даже с закрытым меню — раньше это был per-frame decrypt всех
    // восьми строк). Значения фиксированы, поэтому static const char* безопасен.
    static const char* ID_WIN    = ox_persist(oxorany("##oxclickbar"));
    static const char* ID_HIT    = ox_persist(oxorany("##cbhit"));
    static const char* ID_PRESS  = ox_persist(oxorany("##cbpress"));
    static const char* ID_PRESST = ox_persist(oxorany("##cbpresst"));
    static const char* ID_HOV    = ox_persist(oxorany("##cbhov"));
    static const char* ID_CHEV   = ox_persist(oxorany("##cbchev"));
    static const char* TXT_BRAND = ox_persist(oxorany("Eclips Oxide"));
    static const char* TXT_NEW   = ox_persist(oxorany(" NEW"));
    const float s = g_uiScale;
    const float W = 168.f * s, H = 36.f * s;
    const float MARGIN = 18.f * s;
    float x = MARGIN, y = MARGIN;

    ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0, 0, 0, 0));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
    ImGui::SetNextWindowPos(ImVec2(x, y), ImGuiCond_Always);
    ImGui::SetNextWindowSize(ImVec2(W + 40.f * s, H + 40.f * s), ImGuiCond_Always);
    ImGui::Begin(ID_WIN, nullptr,
        ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize |
        ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoScrollbar |
        ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoBackground |
        ImGuiWindowFlags_NoSavedSettings);

    ImVec2 p = ImGui::GetCursorScreenPos();
    ImGui::InvisibleButton(ID_HIT, ImVec2(W, H));
    bool clicked = ImGui::IsItemClicked();
    bool hov     = ImGui::IsItemHovered();
    if (clicked) g_menuOpen = !g_menuOpen;

    ImDrawList* dl  = ImGui::GetWindowDrawList();
    ImGuiWindow* win = ImGui::GetCurrentWindow();

    // Плавные анимации: press-всплеск + hover-подсветка + дыхание ауры.
    ImGuiStorage* stg = ImGui::GetStateStorage();
    // Press-вспышка в две фазы: атака ~40мс (rate 70), спад ~260мс (rate 9).
    // Цель-защёлка держит 1, пока вспышка не дошла до пика, затем отпускает.
    ImGuiID pressId    = win->GetID(ID_PRESS);
    ImGuiID pressTgtId = win->GetID(ID_PRESST);
    if (clicked) stg->SetInt(pressTgtId, 1);
    float press = AnimAsym(pressId, stg->GetInt(pressTgtId, 0) ? 1.0f : 0.0f,
                           70.0f, 9.0f);
    if (press > 0.95f) stg->SetInt(pressTgtId, 0);
    ImGuiID hovId = win->GetID(ID_HOV);
    float hovA = AnimAsym(hovId, hov ? 1.0f : 0.0f, g_tk.mFast, g_tk.mBase);
    float t = (float)ImGui::GetTime();
    // Органичное дыхание: сумма двух синусов 0.7 и 1.1 Гц (веса 0.62/0.38,
    // нормированы), фазовый сдвиг — чтобы пики не совпадали. Не метроном.
    float breathe = 0.5f + 0.5f * (0.62f * sinf(t * 4.398f) +
                                   0.38f * sinf(t * 6.912f + 1.7f));

    ImVec2 a(p.x, p.y), b(p.x + W, p.y + H);
    float rad = H * 0.5f;                     // pill-форма

    // Аура-свечение в акцентном цвете (дышит + всплеск на тап).
    // Perf: число колец адаптивно (q0=5 как раньше, q1=3, q2=2). Шаг растяжения
    // держим постоянным по внешней кромке (ex зависит от i/count), альфа
    // нормируется на count — суммарная яркость и радиус ауры визуально те же.
    // Тот же стеклянный материал, что и у панели меню, только в масштабе
    // пилюли: ореол -> подложка -> градиент света -> дымка -> кромка.
    // Клик-бар и меню обязаны читаться как одно изделие.
    float auraK = (0.30f + 0.13f * breathe + hovA * 0.30f + press * 0.55f) * glowIntensity;
    int auraN; switch (ox_uiQuality()) { case 2: auraN = 2; break; case 1: auraN = 4; break; default: auraN = 6; }
    for (int i = auraN; i >= 1; --i) {
        float f01 = (float)i / (float)auraN;                 // 1.0 внешнее .. ~0 внутр.
        float ex = (4.f + f01 * 26.f) * s * (1.0f + press * 0.35f);
        float al = (1.0f - f01 * 0.86f);
        dl->AddRectFilled(ImVec2(a.x - ex, a.y - ex + 2 * s), ImVec2(b.x + ex, b.y + ex + 2 * s),
                          Fade(g_pal.accentHi, 0.085f * al * auraK), rad + ex, 0);
    }

    SoftShadow(dl, a, b, rad, 14.f * s, IM_COL32(0, 0, 0, 150));
    // Холодная подложка — тот же тон, что у большой панели.
    dl->AddRectFilled(a, b, IM_COL32(13, 13, 22, 238), rad);
    // Свет сверху.
    dl->AddRectFilledMultiColor(a, ImVec2(b.x, a.y + H * 0.58f),
        IM_COL32(255, 255, 255, 26), IM_COL32(255, 255, 255, 26),
        IM_COL32(255, 255, 255, 0),  IM_COL32(255, 255, 255, 0));
    // Цветная дымка слева направо — источник у бренд-метки.
    {
        int aR = (int)((g_pal.accentHi >>  0) & 0xFF);
        int aG = (int)((g_pal.accentHi >>  8) & 0xFF);
        int aB = (int)((g_pal.accentHi >> 16) & 0xFF);
        int ha = (int)((40.f + hovA * 22.f) * glowIntensity); if (ha > 110) ha = 110;
        dl->AddRectFilledMultiColor(a, b,
            IM_COL32(aR, aG, aB, ha),     IM_COL32(aR, aG, aB, ha / 4),
            IM_COL32(aR, aG, aB, 0),      IM_COL32(aR, aG, aB, ha / 6));
    }
    // Матовость.
    if (g_texGrain && ox_uiQuality() < 2)
        dl->AddImageRounded(g_texGrain, a, b, ImVec2(0, 0),
            ImVec2(W / Px(96.0f), H / Px(96.0f)),
            IM_COL32(255, 255, 255, 12), rad);

    // Кромка: яркая по верхней дуге, обычная по контуру.
    dl->AddRect(a, b, Fade(g_pal.accent, 0.92f), rad, 0, (1.9f + press * 1.2f) * s);
    dl->PathArcTo(ImVec2(a.x + rad, a.y + rad), rad, 3.1415926f, 4.712389f, 10);
    dl->PathLineTo(ImVec2(b.x - rad, a.y));
    dl->PathStroke(IM_COL32(255, 255, 255, 52), 0, 1.3f * s);
    dl->AddRect(ImVec2(a.x - 2 * s, a.y - 2 * s), ImVec2(b.x + 2 * s, b.y + 2 * s),
                Fade(g_pal.accentHi, (0.30f + hovA * 0.25f) * glowIntensity), rad + 2 * s, 0, 1.1f * s);

    // Бренд-бейдж слева (встроенный PNG или векторный fallback)
    float bs = H * 0.52f;
    ImVec2 bc(a.x + H * 0.5f, a.y + H * 0.5f);
    dl->AddCircleFilled(bc, bs * 0.62f, Fade(g_pal.accent, 0.18f));
    if (g_iconTexBrandBadge) {
        dl->AddImage(g_iconTexBrandBadge, ImVec2(bc.x - bs * 0.5f, bc.y - bs * 0.5f),
                     ImVec2(bc.x + bs * 0.5f, bc.y + bs * 0.5f),
                     ImVec2(0, 0), ImVec2(1, 1), g_pal.accent);
    } else {
        // векторная молния
        float r = bs * 0.46f;
        ImVec2 bolt[5] = {
            ImVec2(bc.x + r * 0.24f, bc.y - r),
            ImVec2(bc.x - r * 0.42f, bc.y + r * 0.12f),
            ImVec2(bc.x - r * 0.02f, bc.y + r * 0.12f),
            ImVec2(bc.x - r * 0.24f, bc.y + r),
            ImVec2(bc.x + r * 0.46f, bc.y - r * 0.18f),
        };
        dl->AddConvexPolyFilled(bolt, 5, g_pal.accent);
    }

    // Текст: "Eclips Oxide" белый + "NEW" акцентный. Строки статичны — рисуем
    // прямо из расшифрованных один раз указателей, ширину кэшируем.
    ImFont* f = ImGui::GetFont();
    float ts = ImGui::GetFontSize() * 0.56f;
    ImVec2 s1 = CalcTextSizeCached(f, ts, TXT_BRAND);
    float tx = a.x + H * 0.94f;
    float ty = a.y + H * 0.5f - ts * 0.5f - 1.f * s;
    dl->AddText(f, ts, ImVec2(tx, ty), IM_COL32(240, 238, 248, 255), TXT_BRAND);
    dl->AddText(f, ts, ImVec2(tx + s1.x, ty), g_pal.accent, TXT_NEW);

    // Статус-точка справа: зелёная когда klass резолвлен, акцент когда ждём
    ImVec2 sc(b.x - H * 0.44f, a.y + H * 0.5f);
    bool ready = (g_playerManagerKlass != 0);
    ImU32 dotC = ready ? g_pal.good : g_pal.warn;
    float dotPulse = ready ? 1.0f : (0.45f + 0.55f * breathe);
    dl->AddCircleFilled(sc, 5.5f * s + 2.f * s * (1.f - dotPulse), Fade(dotC, 0.25f));
    dl->AddCircleFilled(sc, 3.6f * s, Fade(dotC, dotPulse));

    // шеврон-стрелка состояния меню (вниз = закрыто, вверх = открыто).
    // Переворот ЧЕРЕЗ разворот: оба отрезка строятся из угла 0..pi, угол идёт
    // по EaseInOutCubic; в середине крылья слегка сужаются (ребро «в профиль»),
    // а не линейная интерполяция концов через плоскую линию.
    ImGuiID chevId = win->GetID(ID_CHEV);
    float chev = Anim(chevId, g_menuOpen ? 1.0f : 0.0f, 9.0f);
    ImVec2 cv(b.x - H * 0.94f, a.y + H * 0.5f);
    float cw = 5.0f * s, ch = 3.2f * s;
    float ang  = 3.14159265f * EaseInOutCubic(chev);
    float dirY = cosf(ang);                          // +1 вниз, -1 вверх
    float cwE  = cw * (1.0f - 0.22f * sinf(ang));    // сужение в развороте
    dl->AddLine(ImVec2(cv.x - cwE, cv.y - ch * dirY), ImVec2(cv.x, cv.y + ch * dirY),
                Fade(g_pal.textDim, 0.9f), 1.8f * s);
    dl->AddLine(ImVec2(cv.x, cv.y + ch * dirY), ImVec2(cv.x + cwE, cv.y - ch * dirY),
                Fade(g_pal.textDim, 0.9f), 1.8f * s);

    g_window = ImGui::GetCurrentWindow();  // для orientation-хака в drawBegin
    ImGui::End();
    ImGui::PopStyleVar();
    ImGui::PopStyleColor();
}

// ============================================================================
//  ESP LIVE PREVIEW — рендерит ТОЧНО тот же код что и боевой ESP (@xohyw).
//  Все примитивы, радиусы, свечения, чипы, HP-бар, 3D-грани, тени — 1:1 с
//  боевым рендером. Меняешь любой тумблер/слайдер — превью меняется мгновенно
//  и выглядит буквально так же, как оно будет выглядеть в матче.
//  Рисуется В ЗАДАННЫЙ ПРЯМОУГОЛЬНИК внутри текущего окна (центральная
//  колонка меню в ландшафте, full-width ряд вкладки ESP в портрете).
// ============================================================================

// Единый рисователь ESP-оверлея. Используется и боевым рендером, и превью.
// bx0/by0/bx1/by1 — экранный бокс цели, hp 0..100, losBlocked — за стеной,
// name/weapon/dist — подписи (nullptr/0 = не рисовать), lineOrigin — точка
// старта трассера (для превью подменяем на низ панели).
static void ox_drawEspOverlay(ImDrawList* dl,
                              float bx0, float by0, float bx1, float by1,
                              float hp, bool losBlocked,
                              const char* name, const char* weapon, float dist,
                              const ImVec2* lineOrigin, float uiScaleFix)
{
    float bw = bx1 - bx0, bh = by1 - by0;
    float cx = (bx0 + bx1) * 0.5f;
    float ht = ::clamp<float>(hp, 0.f, 100.f) / 100.0f;

    // UPDATE 2026/07/31 v22: цвет по видимости — КРАСНЫЙ когда не видно (за
    // стеной), ЗЕЛЁНЫЙ когда виден. Раньше «не видно» красилось в синий.
    ImU32 accent;
    if (espColorByVisibility && losBlocked)      accent = IM_COL32(235, 55, 45, 255);   // не виден → красный
    else if (espColorByVisibility)               accent = IM_COL32(60, 230, 110, 255);  // виден → зелёный
    else accent = ImGui::ColorConvertFloat4ToU32(
             ImVec4(espboxcolor[0], espboxcolor[1], espboxcolor[2], 1.0f));

    ImU32 shadowC = IM_COL32(0, 0, 0, 170);
    ImColor hpFull(int(90 + 90 * (1 - ht)), int(200 * ht + 40), 70, 255);
    ImColor hpEmpty(210, 60, 55, 255);

    int aR = (int)((accent >> 0) & 0xFF);
    int aG = (int)((accent >> 8) & 0xFF);
    int aB = (int)((accent >> 16) & 0xFF);
    ImU32 accentGlow = IM_COL32(aR, aG, aB, 60);

    auto text2 = [&](float tx, float ty, ImU32 col, const char* s) {
        dl->AddText(ImVec2(tx + 1, ty + 1), shadowC, s);
        dl->AddText(ImVec2(tx, ty), col, s);
    };
    auto chip = [&](float cxp, float topY, ImU32 txtCol, ImU32 barCol, const char* s) {
        ImVec2 ts = ImGui::CalcTextSize(s);
        float padx = 6.f, pady = 2.f;
        ImVec2 a(cxp - ts.x * 0.5f - padx, topY);
        ImVec2 b(cxp + ts.x * 0.5f + padx, topY + ts.y + pady * 2);
        dl->AddRectFilled(a, b, IM_COL32(10, 8, 18, 180), 4.f);
        if (barCol) dl->AddRectFilled(a, ImVec2(a.x + 3, b.y), barCol, 4.f,
                                      ImDrawFlags_RoundCornersLeft);
        dl->AddText(ImVec2(cxp - ts.x * 0.5f, topY + pady), txtCol, s);
        return b.y;
    };

    if (espbox) {
        if (espfill) {
            int a8 = (int)(90.0f * espfillp / 100.0f);
            dl->AddRectFilledMultiColor(ImVec2(bx0, by0), ImVec2(bx1, by1),
                IM_COL32(aR, aG, aB, a8 / 4), IM_COL32(aR, aG, aB, a8 / 4),
                IM_COL32(aR, aG, aB, a8),     IM_COL32(aR, aG, aB, a8));
        }
        float th = espstroke < 1.f ? 2.f : espstroke;
        float rnd = (bw < bh ? bw : bh) * 0.22f;
        ImVec2 a(bx0, by0), b(bx1, by1);
        if (!espCornerBox) {
            dl->AddRect(ImVec2(a.x-1, a.y-1), ImVec2(b.x+1, b.y+1), accentGlow, rnd, 0, th + 4);
            dl->AddRect(a, b, shadowC, rnd, 0, th + 2);
            dl->AddRect(a, b, accent, rnd, 0, th);
        } else {
            float corner = ::clamp<float>((bw < bh ? bw : bh) * espCornerLength, 12.f, 52.f);
            const ImVec2 darkLines[] = {
                ImVec2(a.x, a.y), ImVec2(a.x + corner, a.y), ImVec2(a.x, a.y), ImVec2(a.x, a.y + corner),
                ImVec2(b.x, a.y), ImVec2(b.x - corner, a.y), ImVec2(b.x, a.y), ImVec2(b.x, a.y + corner),
                ImVec2(a.x, b.y), ImVec2(a.x + corner, b.y), ImVec2(a.x, b.y), ImVec2(a.x, b.y - corner),
                ImVec2(b.x, b.y), ImVec2(b.x - corner, b.y), ImVec2(b.x, b.y), ImVec2(b.x, b.y - corner),
            };
            for (int i = 0; i < IM_ARRAYSIZE(darkLines); i += 2) {
                dl->AddLine(darkLines[i], darkLines[i + 1], shadowC, th + 3.f);
                dl->AddLine(darkLines[i], darkLines[i + 1], accent, th);
            }
        }
    }

    // 3D-грани: в превью строим псевдо-объём (боевой путь берёт настоящий W2S).
    if (ESP3D) {
        float off = bw * 0.22f, lift = bh * 0.05f;
        float lw = espstroke < 1.f ? 1.f : espstroke;
        ImVec2 f0(bx0, by0), f1(bx1, by0), f2(bx1, by1), f3(bx0, by1);
        ImVec2 r0(bx0 + off, by0 - lift), r1(bx1 + off, by0 - lift);
        ImVec2 r2(bx1 + off, by1 - lift), r3(bx0 + off, by1 - lift);
        dl->AddLine(r0, r1, accent, lw); dl->AddLine(r1, r2, accent, lw);
        dl->AddLine(r2, r3, accent, lw); dl->AddLine(r3, r0, accent, lw);
        dl->AddLine(f0, r0, accent, lw); dl->AddLine(f1, r1, accent, lw);
        dl->AddLine(f2, r2, accent, lw); dl->AddLine(f3, r3, accent, lw);
    }

    if (esphealth && bh > 4.f) {
        float bar = esphpsize < 3.f ? 5.f : esphpsize;
        float hx1 = bx0 - 7.f;
        float hx0 = hx1 - bar;
        float r   = bar * 0.5f;
        dl->AddRectFilled(ImVec2(hx0 - 1.5f, by0 - 1.5f), ImVec2(hx1 + 1.5f, by1 + 1.5f),
                          IM_COL32(6, 5, 12, 220), r + 1.f);
        float fillTop = by1 - bh * ht;
        dl->AddRectFilled(ImVec2(hx0 - 2.5f, fillTop - 1.f), ImVec2(hx1 + 2.5f, by1 + 1.f),
            IM_COL32((int)(hpFull.Value.x*255), (int)(hpFull.Value.y*255),
                     (int)(hpFull.Value.z*255), 55), r + 1.f);
        if (esphpgradient) {
            dl->AddRectFilledMultiColor(ImVec2(hx0, fillTop), ImVec2(hx1, by1),
                hpFull, hpFull, hpEmpty, hpEmpty);
        } else {
            dl->AddRectFilled(ImVec2(hx0, fillTop), ImVec2(hx1, by1), hpFull, r);
        }
        if (bh * ht > 4.f)
            dl->AddRectFilled(ImVec2(hx0, fillTop), ImVec2(hx1, fillTop + 2.f),
                              IM_COL32(255, 255, 255, 90), r, ImDrawFlags_RoundCornersTop);
        if ((int)hp != 100) {
            char hs[16]; snprintf(hs, sizeof(hs), "%d", (int)hp);
            ImVec2 s2 = ImGui::CalcTextSize(hs);
            text2(hx0 - s2.x - 4.f, fillTop - s2.y * 0.5f, IM_COL32(255,255,255,255), hs);
        }
    }

    if (espname && name && name[0]) {
        ImVec2 s2 = ImGui::CalcTextSize(name);
        chip(cx, by0 - s2.y - 7.f, IM_COL32(255, 255, 255, 255), accent, name);
        dl->AddLine(ImVec2(bx0, by0 - 2.f), ImVec2(bx1, by0 - 2.f), accentGlow, 2.f);
    }

    float infoY = by1 + 4.f;
    if (espweapon && weapon && weapon[0])
        infoY = chip(cx, infoY, IM_COL32(235, 235, 245, 255), 0, weapon) + 2.f;
    if (espdist && dist > 0.f) {
        char distStr[32]; snprintf(distStr, sizeof(distStr), "%.0f m", dist);
        chip(cx, infoY, IM_COL32(170, 205, 235, 255), accent, distStr);
    }

    if (esplines_enabled && lineOrigin) {
        ImU32 lineCol = IM_COL32((int)(esplines_color[0] * 255),
                                 (int)(esplines_color[1] * 255),
                                 (int)(esplines_color[2] * 255), 220);
        ImVec2 target(cx, by1);
        dl->AddLine(*lineOrigin, target, lineCol, esplines_thickness);
        dl->AddCircleFilled(target, esplines_thickness + 1.5f, lineCol, 12);
    }
    (void)uiScaleFix;
}

// Панель LIVE PREVIEW в заданный rect текущего окна: заголовок, пол-сетка с
// перспективой, модель, боевой ESP-оверлей (ox_drawEspOverlay — 1:1) и нижний
// ряд метрик "42 m / VISIBLE". Никаких Begin/End — только ImDrawList.
static void oxDrawEspPreviewPane(ImDrawList* dl, ImVec2 a, ImVec2 b)
{
    using namespace oxui;
    // Строки превью — расшифровка один раз (панель рисуется каждый кадр меню).
    static const char* TXT_LIVEPREV = ox_persist(oxorany("LIVE PREVIEW"));
    static const char* TXT_42M      = ox_persist(oxorany("42 m"));
    static const char* TXT_VISIBLE  = ox_persist(oxorany("VISIBLE"));
    static const char* TXT_ENEMY    = ox_persist(oxorany("Enemy"));
    static const char* TXT_AK47     = ox_persist(oxorany("AK-47"));
    const float s = g_uiScale;
    float paneW = b.x - a.x, paneH = b.y - a.y;
    if (paneW < 60.0f * s || paneH < 90.0f * s) return;

    float r = g_tk.rLg * s;

    // Карточка панели: приподнятая поверхность + хэйрлайн-обводка.
    // Perf: раньше — два полных скруглённых fill (непрозрачный bgDeep + белый
    // panel1 alpha-over). Схлопнуто в ОДИН fill с предкомпозиченным цветом
    // (bgDeep ⊕ panel1). Результат по-пиксельно тот же (bgDeep непрозрачен,
    // panel1 = белый @ 12/255), но на одну тесселляцию скруглённого прямоуг.
    // меньше. panel1 = IM_COL32(255,255,255,12) => доля белого 12/255.
    SoftShadow(dl, a, b, r, g_tk.elev1);
    dl->AddRectFilled(a, b, MixU32(g_tk.bgDeep, IM_COL32(255, 255, 255, 255), 12.0f / 255.0f), r);
    dl->AddRect(a, b, g_tk.strokeBase, r, 0, g_tk.strokeW * s);

    ImFont* f = ImGui::GetFont();

    // Заголовок панели: иконка-глаз + caps-лейбл, хэйрлайн под ним.
    float titleH = Px(g_tk.sp6);
    {
        ImVec2 ec(a.x + Px(g_tk.sp4) + Px(8), a.y + titleH * 0.5f);
        ImTextureID eye = g_iconTexEye ? g_iconTexEye : g_iconTexESP;
        if (eye) {
            float half = Px(8);
            dl->AddImage(eye, ImVec2(ec.x - half, ec.y - half),
                         ImVec2(ec.x + half, ec.y + half), ImVec2(0, 0), ImVec2(1, 1),
                         g_tk.accent);
        }
        dl->AddText(f, g_tk.fsCaption,
                    ImVec2(ec.x + Px(8) + Px(g_tk.sp2), a.y + titleH * 0.5f - g_tk.fsCaption * 0.5f),
                    g_tk.textDim, TXT_LIVEPREV);
        dl->AddLine(ImVec2(a.x + Px(g_tk.sp3), a.y + titleH),
                    ImVec2(b.x - Px(g_tk.sp3), a.y + titleH),
                    g_tk.strokeSoft, g_tk.dividerW * s);
    }

    // Нижний ряд метрик: дистанция + статус видимости (цвет — от espdraw).
    float metricsH = Px(g_tk.sp6);
    float metTop = b.y - metricsH;
    {
        dl->AddLine(ImVec2(a.x + Px(g_tk.sp3), metTop), ImVec2(b.x - Px(g_tk.sp3), metTop),
                    g_tk.strokeSoft, g_tk.dividerW * s);
        float cy = metTop + metricsH * 0.5f;
        dl->AddText(f, g_tk.fsLabel,
                    ImVec2(a.x + Px(g_tk.sp4), cy - g_tk.fsLabel * 0.5f),
                    g_tk.textHi, TXT_42M);
        ImU32 stC = espdraw ? g_tk.good : g_tk.textFaint;
        const char* stTxt = TXT_VISIBLE;
        ImVec2 stSz = CalcTextSizeCached(f, g_tk.fsCaption, stTxt);
        float stX = b.x - Px(g_tk.sp4) - stSz.x;
        dl->AddText(f, g_tk.fsCaption, ImVec2(stX, cy - g_tk.fsCaption * 0.5f), stC, stTxt);
        dl->AddCircleFilled(ImVec2(stX - Px(g_tk.sp2) - Px(3), cy), Px(3), stC);
    }

    // Сцена: пол-сетка с перспективой между заголовком и метриками.
    float sceneTop = a.y + titleH + Px(g_tk.sp2);
    float sceneBot = metTop - Px(g_tk.sp2);
    float sceneH   = sceneBot - sceneTop;
    if (sceneH < 40.0f * s) return;
    float floorY   = sceneBot - sceneH * 0.06f;
    // Пол-сетка с перспективой. Число линий — субдивизии градиента; на
    // reduced/minimal прореживаем (q0: 7 гор / 7 верт, q1: 5/5, q2: 4/3).
    // Крайние k=0..1 и общий размах сохраняются — сетка та же, реже штрихи.
    int hLines, vHalf;
    switch (ox_uiQuality()) {
        case 2:  hLines = 4; vHalf = 1; break;
        case 1:  hLines = 5; vHalf = 2; break;
        default: hLines = 7; vHalf = 3; break;
    }
    for (int i = 0; i < hLines; ++i) {
        float k  = (float)i / (float)(hLines - 1);
        float gy = floorY - sceneH * 0.30f * (1.0f - k) * (1.0f - k);
        float ins = paneW * 0.10f + paneW * 0.26f * (1.0f - k);
        dl->AddLine(ImVec2(a.x + ins, gy), ImVec2(b.x - ins, gy),
                    IM_COL32(255, 255, 255, (int)(6 + 10 * k)), 1.0f);
    }
    for (int i = -vHalf; i <= vHalf; ++i) {
        float xTop = a.x + paneW * 0.5f + i * paneW * 0.045f;
        float xBot = a.x + paneW * 0.5f + i * paneW * 0.135f;
        dl->AddLine(ImVec2(xTop, floorY - sceneH * 0.30f), ImVec2(xBot, floorY),
                    IM_COL32(255, 255, 255, 8), 1.0f);
    }

    // Модель, вписанная по высоте сцены
    float mH  = sceneH * 0.94f;
    float mTop = floorY - mH;
    float aspect = (g_texPreviewDummyW > 0 && g_texPreviewDummyH > 0)
                 ? (float)g_texPreviewDummyW / (float)g_texPreviewDummyH : 0.667f;
    float mW = mH * aspect;
    float mcx = a.x + paneW * 0.5f;
    ImVec2 m0(mcx - mW * 0.5f, mTop), m1(mcx + mW * 0.5f, floorY);
    // мягкая тень под ногами
    dl->AddRectFilled(ImVec2(mcx - mW * 0.34f, floorY - 3.0f * s),
                      ImVec2(mcx + mW * 0.34f, floorY + 3.0f * s),
                      IM_COL32(0, 0, 0, 90), 6.0f * s);
    if (g_texPreviewDummy)
        dl->AddImage(g_texPreviewDummy, m0, m1, ImVec2(0,0), ImVec2(1,1), IM_COL32(255,255,255,255));

    // Бокс ровно по силуэту модели — те же пропорции что боевой ESP
    float boxH = mH * 0.99f;
    float boxW = boxH * 0.5f;             // боевой ratio: halfW = height*0.25 => w = h*0.5
    float ebx0 = mcx - boxW * 0.5f, ebx1 = mcx + boxW * 0.5f;
    float eby0 = floorY - boxH,     eby1 = floorY;

    ImVec2 lineOrigin(mcx, sceneBot);
    ox_drawEspOverlay(dl, ebx0, eby0, ebx1, eby1,
                      72.0f, false, TXT_ENEMY, TXT_AK47, 42.0f,
                      esplines_enabled ? &lineOrigin : nullptr, s);
}

// Full-width ряд превью ВНУТРИ скролл-региона вкладки ESP — портретный режим.
// Тонкая обёртка над oxDrawEspPreviewPane: резервирует место через Dummy.
static void oxDrawEspPreviewInline() {
    using namespace oxui;
    const float s = g_uiScale;
    float pad = Px(g_tk.sp4);
    float availW = ImGui::GetContentRegionAvail().x - pad * 2.0f;
    if (availW < 80.0f * s) return;
    float paneH = 240.0f * s;

    ImVec2 p = ImGui::GetCursorScreenPos();
    oxDrawEspPreviewPane(ImGui::GetWindowDrawList(),
                         ImVec2(p.x + pad, p.y + Px(g_tk.sp2)),
                         ImVec2(p.x + pad + availW, p.y + Px(g_tk.sp2) + paneH));
    ImGui::Dummy(ImVec2(0, paneH + Px(g_tk.sp2) + Px(g_tk.sp3)));
}

// ---- Содержимое вкладок (тот же набор привязок/границ, новый вид) ----
// Perf: все oxorany-строки вкладок расшифровываются ОДИН раз (первый вызов
// вкладки), затем используются как стабильные указатели каждый кадр. Раньше
// каждый лейбл проходил obfuscation-decrypt при каждом кадре активной вкладки.
// Стабильный указатель ЕЩЁ И улучшает кэш CalcTextSizeCached (ключ по адресу).
static void oxTabESP() {
    using namespace oxui;
    static const char* L_OVERLAY = ox_persist(oxorany("OVERLAY"));
    static const char* L_ENESP   = ox_persist(oxorany("Enable ESP"));
    static const char* L_HIDET   = ox_persist(oxorany("Hide teammates"));
    static const char* L_HIDETH  = ox_persist(oxorany("By teamName SyncVar + game isTeammate flag."));
    static const char* L_COLVIS  = ox_persist(oxorany("Color by visibility"));
    static const char* L_COLVISH = ox_persist(oxorany("Reads BuildingPiece.saveList (walls)"));
    static const char* L_VISIBLE = ox_persist(oxorany("Visible"));
    static const char* L_BEHIND  = ox_persist(oxorany("Behind wall"));
    static const char* L_BOX     = ox_persist(oxorany("BOX"));
    static const char* L_BOXT    = ox_persist(oxorany("Box"));
    static const char* L_STROKE  = ox_persist(oxorany("Stroke"));
    static const char* L_CORNER  = ox_persist(oxorany("Corner box"));
    static const char* L_CORNERL = ox_persist(oxorany("Corner length"));
    static const char* L_FILLED  = ox_persist(oxorany("Filled"));
    static const char* L_FILLV   = ox_persist(oxorany("Fill value"));
    static const char* L_FILLG   = ox_persist(oxorany("Fill gradient"));
    static const char* L_BOXCOL  = ox_persist(oxorany("Box color"));
    static const char* L_BOXY    = ox_persist(oxorany("Vertical offset"));
    static const char* L_BOXYH   = ox_persist(oxorany("Move box up/down onto the target"));
    static const char* L_INFO    = ox_persist(oxorany("INFO"));
    static const char* L_HPBAR   = ox_persist(oxorany("Health bar"));
    static const char* L_BARSTK  = ox_persist(oxorany("Bar stroke"));
    static const char* L_HPGRAD  = ox_persist(oxorany("HP gradient"));
    static const char* L_DIST    = ox_persist(oxorany("Distance"));
    static const char* L_NAME    = ox_persist(oxorany("Name"));
    static const char* L_WEAPON  = ox_persist(oxorany("Weapon"));
    static const char* L_3DBOX   = ox_persist(oxorany("3D box"));
    static const char* L_SKEL    = ox_persist(oxorany("Skeleton"));
    static const char* L_SKELH   = ox_persist(oxorany("Real bones from the player model"));
    static const char* L_LINES   = ox_persist(oxorany("ESP lines"));
    static const char* L_LINETH  = ox_persist(oxorany("Line thickness"));
    static const char* L_LINECOL = ox_persist(oxorany("Line color"));
    static const char* L_LINEORI = ox_persist(oxorany("Line origin"));
    static const char* L_ANCHOR  = ox_persist(oxorany("Bind to model"));
    static const char* L_ANCHORH = ox_persist(oxorany("Box from real bones, not the server tick."));
    static const char* L_MATRIX  = ox_persist(oxorany("Camera matrix W2S"));
    static const char* L_MATRIXH = ox_persist(oxorany("Uses the engine view/projection matrix."));
    static const char* L_HPNUM   = ox_persist(oxorany("HP as number"));
    static const char* L_HPNUMH  = ox_persist(oxorany("Always show the number, not only below 100."));
    static const char* L_ARMOR   = ox_persist(oxorany("Armor"));
    static const char* L_ARMORH  = ox_persist(oxorany("GenericVitals protection value under the HP bar."));
    static const char* L_FLAGS   = ox_persist(oxorany("State tags"));
    static const char* L_FLAGSH  = ox_persist(oxorany("SLEEP / SPEC / PRIME chip above the name."));
    static const char* L_DCOLOR  = ox_persist(oxorany("Color by distance"));
    static const char* L_DCOLORH = ox_persist(oxorany("Close = red, mid = yellow, far = blue."));
    static const char* L_RADAR   = ox_persist(oxorany("RADAR"));
    static const char* L_RADARE  = ox_persist(oxorany("Enable radar"));
    static const char* L_RADAREH = ox_persist(oxorany("360 minimap, view direction points up."));
    static const char* L_RADARR  = ox_persist(oxorany("Range (m)"));
    static const char* L_RADARS  = ox_persist(oxorany("Size (px)"));
    static const char* L_RADARX  = ox_persist(oxorany("Position X"));
    static const char* L_RADARY  = ox_persist(oxorany("Position Y"));
    static const char* L_RADARA  = ox_persist(oxorany("Background opacity"));
    static const char* L_RANGE   = ox_persist(oxorany("RANGE"));
    static const char* L_MAXDIST = ox_persist(oxorany("Max distance (m)"));
    static const char* origins[] = { "Bottom center", "Crosshair" };
    // Превью здесь больше не вызывается: в ландшафте оно живёт в центральной
    // колонке меню, в портрете Layout_tick_UI рисует его рядом над этой вкладкой.
    Section(L_OVERLAY);
    Toggle(L_ENESP, &espdraw);
    // Источник геометрии и проекции. Оба по умолчанию включены; выключать
    // имеет смысл только для сравнения со старым поведением.
    Toggle(L_ANCHOR, &espModelAnchor, L_ANCHORH);
    Toggle(L_MATRIX, &espMatrixW2S, L_MATRIXH);

    Section(L_BOX);
    Toggle(L_BOXT, &espbox);
    if (espbox) {
        // Вертикальная привязка. При матричной проекции она НЕ применяется
        // (там низ бокса = позиция ног, оффсет не нужен), при угловой —
        // применяется как раньше. Слайдер оставляем видимым, чтобы можно было
        // докрутить, если матрица не нашлась и включился старый путь.
        SliderF(L_BOXY, &espBoxYOffset, -2.50f, 1.00f, "%.2f");
        Hint(L_BOXYH);
        SliderF(L_STROKE, &espstroke, 0.0f, 5.0f, "%.2f");
        Toggle(L_CORNER, &espCornerBox);
        if (espCornerBox)
            SliderF(L_CORNERL, &espCornerLength, 0.16f, 0.45f, "%.2f");
        Toggle(L_FILLED, &espfill);
        if (espfill) {
            SliderF(L_FILLV, &espfillp, 20, 80, "%.0f");
            Toggle(L_FILLG, &espgradient);
        }
        // Цвет бокса доступен только если не включена окраска по видимости —
        // иначе он переопределяется зелёным/синим.
        if (!espColorByVisibility)
            ColorSwatch(L_BOXCOL, espboxcolor);
    }

    Section(L_INFO);
    Toggle(L_HPBAR, &esphealth);
    if (esphealth) {
        SliderF(L_BARSTK, &esphpsize, 0.0f, 10.0f, "%.1f");
        Toggle(L_HPGRAD, &esphpgradient);
        Toggle(L_HPNUM, &espHpNumber, L_HPNUMH);
        Toggle(L_ARMOR, &espArmor, L_ARMORH);
    }
    Toggle(L_DIST, &espdist);
    Toggle(L_DCOLOR, &espDistColor, L_DCOLORH);
    Toggle(L_NAME,     &espname);
    Toggle(L_WEAPON,   &espweapon);
    Toggle(L_FLAGS,    &espFlags, L_FLAGSH);
    Toggle(L_3DBOX,   &ESP3D);
    // UPDATE 2026/07/31 v20: скелет ВОЗВРАЩЁН в меню. Раньше был снят т.к.
    // KCC.head не отдавал трансформ, но теперь ox_readSkeleton строит скелет
    // от движущегося якоря (feet=lastTickPosition) + голова из капсулы, а тело
    // достраивается пропорционально. Работает для remote-игроков.
    Toggle(L_SKEL,    &skeleton, L_SKELH);
    // UPDATE 2026/07/31 v21: скрытие тимейтов ВОЗВРАЩЕНО. Рабочий источник —
    // PlayerManager.teamName (SyncVar @0x280, реплицируется на всех клиентов) +
    // готовый флаг игры nicklabel.isTeammate. Три старых источника (TCa.team,
    // TeammateStates, membersList) были пусты — теперь не используются.
    Toggle(L_HIDET,   &espHideTeammates, L_HIDETH);
    Toggle(L_LINES, &esplines_enabled);
    if (esplines_enabled) {
        SliderF(L_LINETH, &esplines_thickness, 1.0f, 6.0f, "%.1f");
        ColorSwatch(L_LINECOL, esplines_color);
        Segmented(L_LINEORI, &esplines_position, origins, IM_ARRAYSIZE(origins));
    }
    Section(L_RADAR);
    Toggle(L_RADARE, &radarEnabled, L_RADAREH);
    if (radarEnabled) {
        SliderF(L_RADARR, &radarRange, 30.0f, 500.0f, "%.0f");
        SliderF(L_RADARS, &radarSize, 110.0f, 400.0f, "%.0f");
        SliderF(L_RADARX, &radarPos[0], 0.0f, 1600.0f, "%.0f");
        SliderF(L_RADARY, &radarPos[1], 0.0f, 900.0f, "%.0f");
        SliderF(L_RADARA, &radarAlpha, 0.05f, 1.0f, "%.2f");
    }

    Section(L_RANGE);
    SliderF(L_MAXDIST, &espMaxDistance, 0.0f, 10000.0f, "%.0f");
}

static void oxTabAim() {
    using namespace oxui;
    static const char* L_AIMBOT  = ox_persist(oxorany("AIMBOT"));
    static const char* L_ENAIM   = ox_persist(oxorany("Enable aimbot"));
    static const char* L_ADS     = ox_persist(oxorany("Only when aiming (ADS)"));
    static const char* L_ADSH    = ox_persist(oxorany("Aims only while scoped (live FOV zoom)."));
    static const char* L_TUNING  = ox_persist(oxorany("TUNING"));
    static const char* L_AIMFOV  = ox_persist(oxorany("Aim FOV (px)"));
    static const char* L_SMOOTH  = ox_persist(oxorany("Smoothing"));
    static const char* L_AIMDIST = ox_persist(oxorany("Max distance (m)"));
    static const char* L_TARGET  = ox_persist(oxorany("Target point"));
    static const char* L_SMOOTHH = ox_persist(oxorany("Smoothing 1 = instant target adjustment."));
    static const char* L_SAFETY  = ox_persist(oxorany("SAFETY"));
    static const char* L_CROUCH  = ox_persist(oxorany("Crouch-safe aim"));
    static const char* L_CROUCHH = ox_persist(oxorany("Crouch state not readable - manual."));
    static const char* L_CROUCHD = ox_persist(oxorany("Crouch drop (m)"));
    static const char* L_WALLS   = ox_persist(oxorany("Check walls"));
    static const char* L_WALLSH  = ox_persist(oxorany("BuildingPiece.saveList AABB raycast"));
    static const char* L_IGNTM   = ox_persist(oxorany("Ignore teammates"));
    static const char* L_IGNTMH  = ox_persist(oxorany("Skip players sharing team with local."));
    static const char* L_PREDICT = ox_persist(oxorany("PREDICTION"));
    static const char* L_MOVPRED = ox_persist(oxorany("Movement prediction"));
    static const char* L_PROJSPD = ox_persist(oxorany("Projectile speed (m/s)"));
    static const char* L_LATENCY = ox_persist(oxorany("Latency (ms)"));
    static const char* L_LEAD    = ox_persist(oxorany("Max lead time (s)"));
    static const char* L_PROJGRAV= ox_persist(oxorany("Bullet drop (m/s2)"));
    static const char* L_FOVCIRC = ox_persist(oxorany("Show FOV circle"));
    static const char* L_TRIG    = ox_persist(oxorany("Activation"));
    static const char* L_TRIGH   = ox_persist(oxorany("When the aimbot engages the target."));
    static const char* L_VISO    = ox_persist(oxorany("Visible only"));
    static const char* L_VISOH   = ox_persist(oxorany("Skip targets behind walls (building LOS)."));
    static const char* bones[] = { "Head", "Neck", "Body" };
    static const char* triggers[] = { "Always", "Scope", "Fire", "Scope+Fire" };
    Section(L_AIMBOT);
    Toggle(L_ENAIM, &aimm);
    if (!aimm) return;

    // v22: выбор режима активации — Always / Scope(ADS) / Fire / Scope+Fire.
    Segmented(L_TRIG, &aimTriggerMode, triggers, IM_ARRAYSIZE(triggers));
    Hint(L_TRIGH);

    Section(L_TUNING);
    SliderF(L_AIMFOV, &aimFovPixels, 20.0f, 600.0f, "%.0f");
    SliderF(L_SMOOTH, &aimSmooth, 1.0f, 20.0f, "%.1f");
    SliderF(L_AIMDIST, &aimMaxDistance, 0.0f, 1000.0f, "%.0f");
    Segmented(L_TARGET, &aimcurbone, bones, IM_ARRAYSIZE(bones));
    Hint(L_SMOOTHH);

    // v22: фильтры цели — видимость (LOS через стены) + игнор тимейтов.
    Section(L_SAFETY);
    Toggle(L_VISO,  &aimCheckWalls, L_VISOH);       // аим только по видимым
    Toggle(L_IGNTM, &aimIgnoreTeammates, L_IGNTMH); // не наводиться на своих

    Section(L_PREDICT);
    Toggle(L_MOVPRED, &aimPrediction);
    if (aimPrediction) {
        SliderF(L_PROJSPD, &aimProjectileSpeed, 20.0f, 1000.0f, "%.0f");
        SliderF(L_LATENCY, &aimLatencyMs, 0.0f, 250.0f, "%.0f");
        SliderF(L_LEAD, &aimMaxLeadTime, 0.05f, 0.75f, "%.2f");
        SliderF(L_PROJGRAV, &aimProjectileGravity, 0.0f, 30.0f, "%.1f");
    }
    Toggle(L_FOVCIRC, &aimDrawFov);
}

static void oxTabCamera() {
    using namespace oxui;
    static const char* L_CAM     = ox_persist(oxorany("CAMERA / W2S"));
    static const char* L_CAMH    = ox_persist(oxorany("Basis from look angles. FOV read live from game (vertical, ADS-aware)."));
    static const char* L_INVP    = ox_persist(oxorany("Invert pitch"));
    static const char* L_INVY    = ox_persist(oxorany("Invert yaw"));
    static const char* L_FALLBK  = ox_persist(oxorany("FALLBACK"));
    static const char* L_FALLBKH = ox_persist(oxorany("Used only if live FOV unavailable."));
    static const char* L_HFOV    = ox_persist(oxorany("Fallback H-FOV"));
    Section(L_CAM);
    Hint(L_CAMH);
    Toggle(L_INVP, &camInvertPitch);
    Toggle(L_INVY,   &camInvertYaw);
    Section(L_FALLBK);
    // Ползунок FOV теперь — ТОЛЬКО аварийный fallback (если FPManager не отдал
    // живой FOV в этот кадр). В норме проекция использует реальный верт. FOV игры.
    Hint(L_FALLBKH);
    SliderF(L_HFOV, &camFov, 60.0f, 120.0f, "%.1f");
}

static void oxTabSettings() {
    using namespace oxui;
    static const char* L_APPEAR  = ox_persist(oxorany("APPEARANCE"));
    static const char* ID_ACCS   = ox_persist(oxorany("accents"));
    static const char* ID_SW     = ox_persist(oxorany("##sw"));
    static const char* L_MENUCOL = ox_persist(oxorany("MENU COLOR"));
    static const char* L_MENUCLH = ox_persist(oxorany("Pick any color. Applies live to menu + click bar."));
    static const char* ID_ACCPK  = ox_persist(oxorany("accentpick"));
    static const char* ID_ACCPKR = ox_persist(oxorany("##accentPicker"));
    static const char* L_UIOPAC  = ox_persist(oxorany("UI opacity"));
    static const char* L_GLOW    = ox_persist(oxorany("Glow intensity"));
    static const char* L_GLOWH   = ox_persist(oxorany("Drives the halo, inner haze and edge light at once."));
    static const char* L_PERF    = ox_persist(oxorany("PERFORMANCE"));
    static const char* L_HSCAN   = ox_persist(oxorany("Heavy scan interval"));
    static const char* L_POSINT  = ox_persist(oxorany("Position interval"));
    static const char* L_PERFH   = ox_persist(oxorany("Default 10/2 reduces reads; camera projection stays per-frame."));
    static const char* L_SESSION = ox_persist(oxorany("SESSION"));
    static const char* L_EXIT    = ox_persist(oxorany("Exit"));
    static const char* L_UNLOAD  = ox_persist(oxorany("Unload"));
    Section(L_APPEAR);
    // Акцент-темы: полоса из свотчей. Меняет только цвет UI (визуал).
    {
        const float s = g_uiScale;
        ImVec2 pos = ImGui::GetCursorScreenPos();
        float w = ImGui::GetContentRegionAvail().x;
        float sw = 46.0f * s, sgap = 14.0f * s;
        ImDrawList* dl = ImGui::GetWindowDrawList();
        ImGui::PushID(ID_ACCS);
        if (ImGui::InvisibleButton(ID_SW, ImVec2(w, sw))) {
            float mx = ImGui::GetIO().MousePos.x - (pos.x + 16.0f * s);
            int idx = (int)(mx / (sw + sgap));
            if (idx >= 0 && idx < kAccentCount) g_accentTheme = idx;
        }
        for (int i = 0; i < kAccentCount; ++i) {
            ImVec2 a(pos.x + 16.0f * s + i * (sw + sgap), pos.y);
            ImVec2 b(a.x + sw, a.y + sw);
            bool sel = (i == g_accentTheme);
            if (sel)
                dl->AddRectFilled(ImVec2(a.x - 3 * s, a.y - 3 * s), ImVec2(b.x + 3 * s, b.y + 3 * s),
                                  Fade(kAccents[i].b, 0.35f), 13.0f * s);
            dl->AddRectFilledMultiColor(a, b, kAccents[i].a, kAccents[i].b, kAccents[i].b, kAccents[i].a);
            dl->AddRect(a, b, sel ? IM_COL32(255, 255, 255, 255) : g_pal.stroke,
                        11.0f * s, 0, sel ? 2.5f * s : 1.2f * s);
            if (sel) dl->AddCircleFilled(ImVec2(b.x - 10 * s, a.y + 10 * s), 3.6f * s, IM_COL32(255, 255, 255, 255));
        }
        // Шестой слот — CUSTOM. Активен когда g_accentTheme == -1.
        {
            ImVec2 a(pos.x + 16.0f * s + kAccentCount * (sw + sgap), pos.y);
            ImVec2 b(a.x + sw, a.y + sw);
            bool sel = (g_accentTheme < 0);
            if (sel)
                dl->AddRectFilled(ImVec2(a.x - 3 * s, a.y - 3 * s), ImVec2(b.x + 3 * s, b.y + 3 * s),
                                  Fade(Vec4ToU32Hi(g_customAccent), 0.35f), 13.0f * s);
            dl->AddRectFilledMultiColor(a, b, Vec4ToU32(g_customAccent), Vec4ToU32Hi(g_customAccent),
                                        Vec4ToU32Hi(g_customAccent), Vec4ToU32(g_customAccent));
            dl->AddRect(a, b, sel ? IM_COL32(255, 255, 255, 255) : g_pal.stroke,
                        11.0f * s, 0, sel ? 2.5f * s : 1.2f * s);
            // мини-«капля» чтобы отличать custom-слот
            ImVec2 dc(a.x + sw * 0.5f, a.y + sw * 0.5f);
            dl->AddCircle(dc, sw * 0.22f, IM_COL32(255, 255, 255, 190), 20, 1.6f * s);
            dl->AddCircleFilled(dc, sw * 0.09f, IM_COL32(255, 255, 255, 220));
        }
        ImGui::PopID();
        ImGui::Dummy(ImVec2(0, sw + 12.0f * s));
        // клик по custom-слоту (обрабатываем отдельно, чтобы попадать в его bbox)
        {
            float cx0 = pos.x + 16.0f * s + kAccentCount * (sw + sgap);
            ImVec2 mp = ImGui::GetIO().MousePos;
            if (ImGui::IsMouseClicked(0) && mp.x >= cx0 && mp.x <= cx0 + sw &&
                mp.y >= pos.y && mp.y <= pos.y + sw) {
                g_accentTheme = -1;
            }
        }
    }

    // ---- Live color picker: полный HSV-выбор акцента ----
    {
        const float ps = g_uiScale;
        Section(L_MENUCOL);
        Hint(L_MENUCLH);
        ImGui::PushID(ID_ACCPK);
        ImGui::PushItemWidth(ImGui::GetContentRegionAvail().x - 24.0f * ps);
        ImGui::SetCursorPosX(ImGui::GetCursorPosX() + 16.0f * ps);
        if (ImGui::ColorPicker3(ID_ACCPKR, (float*)&g_customAccent,
                                ImGuiColorEditFlags_NoSidePreview |
                                ImGuiColorEditFlags_NoSmallPreview |
                                ImGuiColorEditFlags_NoAlpha |
                                ImGuiColorEditFlags_DisplayHSV |
                                ImGuiColorEditFlags_PickerHueBar)) {
            g_accentTheme = -1;   // любое движение пикера => custom-режим
        }
        ImGui::PopItemWidth();
        ImGui::PopID();
        ImGui::Dummy(ImVec2(0, 10.0f * ps));
    }

    // Сила подсветки + живой образец материала. Образец показывает ровно те
    // же слои, что и большая панель, поэтому цвет и свет подбираются по нему,
    // а не вслепую по значению ползунка.
    SliderF(L_GLOW, &glowIntensity, 0.0f, 2.0f, "%.2f");
    Hint(L_GLOWH);
    {
        const float ps2 = g_uiScale;
        ImVec2 gp = ImGui::GetCursorScreenPos();
        float gw = ImGui::GetContentRegionAvail().x - 32.0f * ps2;
        float gh = 62.0f * ps2;
        ImDrawList* gdl = ImGui::GetWindowDrawList();
        ImVec2 ga(gp.x + 16.0f * ps2, gp.y);
        ImVec2 gb(ga.x + gw, ga.y + gh);
        float grr = 16.0f * ps2;

        // Ореол
        for (int i = 5; i >= 1; --i) {
            float f01 = (float)i / 5.0f;
            float ex  = (3.f + f01 * 20.f) * ps2;
            gdl->AddRectFilled(ImVec2(ga.x - ex, ga.y - ex), ImVec2(gb.x + ex, gb.y + ex),
                               Fade(g_pal.accentHi, (1.0f - f01 * 0.85f) * 0.07f * glowIntensity),
                               grr + ex, 0);
        }
        // Подложка + свет сверху + дымка + зерно + кромка
        gdl->AddRectFilled(ga, gb, IM_COL32(13, 13, 22, 236), grr);
        gdl->AddRectFilledMultiColor(ga, ImVec2(gb.x, ga.y + gh * 0.60f),
            IM_COL32(255, 255, 255, 24), IM_COL32(255, 255, 255, 24),
            IM_COL32(255, 255, 255, 0),  IM_COL32(255, 255, 255, 0));
        {
            int aR = (int)((g_pal.accentHi >>  0) & 0xFF);
            int aG = (int)((g_pal.accentHi >>  8) & 0xFF);
            int aB = (int)((g_pal.accentHi >> 16) & 0xFF);
            int ha = (int)(38.f * glowIntensity); if (ha > 100) ha = 100;
            gdl->AddRectFilledMultiColor(ga, gb,
                IM_COL32(aR, aG, aB, ha),  IM_COL32(aR, aG, aB, ha / 4),
                IM_COL32(aR, aG, aB, 0),   IM_COL32(aR, aG, aB, ha / 6));
        }
        if (g_texGrain)
            gdl->AddImageRounded(g_texGrain, ga, gb, ImVec2(0, 0),
                ImVec2(gw / Px(96.0f), gh / Px(96.0f)),
                IM_COL32(255, 255, 255, 12), grr);
        gdl->AddRect(ga, gb, Fade(g_pal.accent, 0.55f), grr, 0, 1.5f * ps2);
        gdl->PathArcTo(ImVec2(ga.x + grr, ga.y + grr), grr, 3.1415926f, 4.712389f, 10);
        gdl->PathLineTo(ImVec2(gb.x - grr, ga.y));
        gdl->PathStroke(IM_COL32(255, 255, 255, 50), 0, 1.2f * ps2);

        // Бренд-метка внутри образца — так виден и тон глифа.
        if (g_texBrandMark) {
            float bs2 = gh * 0.46f;
            ImVec2 bc2(ga.x + gh * 0.55f, ga.y + gh * 0.5f);
            gdl->AddImage(g_texBrandMark,
                          ImVec2(bc2.x - bs2 * 0.5f, bc2.y - bs2 * 0.5f),
                          ImVec2(bc2.x + bs2 * 0.5f, bc2.y + bs2 * 0.5f),
                          ImVec2(0, 0), ImVec2(1, 1), g_pal.accent);
        }
        ImGui::Dummy(ImVec2(0, gh + 14.0f * ps2));
    }

    static float opacity = 1.0f;
    SliderF(L_UIOPAC, &opacity, 0.35f, 1.0f, "%.2f");
    ImGui::GetStyle().Alpha = opacity;

    Section(L_PERF);
    SliderI(L_HSCAN, &g_cacheInterval, 4, 30);
    SliderI(L_POSINT, &g_positionInterval, 1, 4);
    Hint(L_PERFH);

    Section(L_SESSION);
    if (ActionButton(L_EXIT, 0)) main_thread_flag = false;
    ImGui::Dummy(ImVec2(0, 8.0f * g_uiScale));
    if (ActionButton(L_UNLOAD, 0)) exit(0);
}

// Векторные глифы вкладок (порт идиомы Trial Engine). i: 0 ESP(глаз),
// 1 Aim(прицел), 2 Camera(объектив/глобус), 3 Settings(шестерня).
namespace oxui {
static void TabGlyph(ImDrawList* d, ImVec2 c, int i, ImU32 col, float k) {
    if (i == 0) {                 // глаз
        d->AddEllipse(ImVec2(c.x, c.y), 9 * k, 6 * k, col, 0, 24, 1.8f * k);
        d->AddCircleFilled(ImVec2(c.x, c.y), 2.7f * k, col);
    } else if (i == 1) {          // прицел
        d->AddCircle(c, 8 * k, col, 28, 1.8f * k);
        d->AddCircle(c, 3 * k, col, 16, 1.8f * k);
        d->AddLine(ImVec2(c.x, c.y - 11 * k), ImVec2(c.x, c.y - 5 * k), col, 1.8f * k);
        d->AddLine(ImVec2(c.x, c.y + 5 * k), ImVec2(c.x, c.y + 11 * k), col, 1.8f * k);
        d->AddLine(ImVec2(c.x - 11 * k, c.y), ImVec2(c.x - 5 * k, c.y), col, 1.8f * k);
        d->AddLine(ImVec2(c.x + 5 * k, c.y), ImVec2(c.x + 11 * k, c.y), col, 1.8f * k);
    } else if (i == 2) {          // объектив (камера)
        d->AddCircle(c, 8 * k, col, 28, 1.8f * k);
        d->AddEllipse(ImVec2(c.x, c.y), 3.4f * k, 8 * k, col, 0, 20, 1.6f * k);
        d->AddLine(ImVec2(c.x - 8 * k, c.y), ImVec2(c.x + 8 * k, c.y), col, 1.6f * k);
    } else {                      // шестерня
        d->AddCircle(c, 7 * k, col, 28, 1.8f * k);
        d->AddCircle(c, 2.7f * k, col, 16, 1.8f * k);
        for (int j = 0; j < 8; ++j) {
            float ang = j * 3.14159f / 4.0f;
            d->AddLine(ImVec2(c.x + cosf(ang) * 7 * k, c.y + sinf(ang) * 7 * k),
                       ImVec2(c.x + cosf(ang) * 10 * k, c.y + sinf(ang) * 10 * k), col, 1.8f * k);
        }
    }
}
static const char* kTabNames[4] = { "ESP", "Aim", "Camera", "Settings" };
static const char* kTabSubs[4]  = {
    "Entity overlays", "Aim controls", "Camera / W2S", "Theme & performance" };
// Caps-имена для хлебной крошки шапки ("ESP / LIVE") + сабтайтлы под ней.
static const char* kTabNamesCaps[4] = { "ESP", "AIM", "CAMERA", "SETTINGS" };
static const char* kCrumbSubs[4]    = {
    "Realtime overlay preview", "Targeting and smoothing",
    "Projection and view", "Theme and performance" };

// Встроенная PNG-иконка вкладки i (0 ESP,1 Aim,2 Camera,3 Settings). Возвращает
// 0, если текстура ещё не загружена — тогда вызывающий откатывается на вектор.
static ImTextureID TabIconTex(int i) {
    switch (i) {
        case 0:  return g_iconTexESP;      // ESP  -> "esp" (eye-in-ring)
        case 1:  return g_iconTexAim;      // Aim  -> "aim" (target-in-ring)
        case 2:  return g_iconTexHud;      // Camera / W2S -> "hud"
        default: return g_iconTexPalette;  // Settings -> "palette"
    }
}

// Блит иконки вкладки: квадратный слот со стороной 2*k*10 (совпадает с габаритом
// векторного глифа, чей радиус ~10*k). Тинт = тот же акцент, что и у вектора,
// поэтому активное/неактивное состояние по-прежнему подсвечивается. Если текстуры
// нет — рисуем прежний векторный глиф (TabGlyph), поведение не меняется.
static void TabIcon(ImDrawList* d, ImVec2 c, int i, ImU32 col, float k) {
    ImTextureID tex = TabIconTex(i);
    if (!tex) { TabGlyph(d, c, i, col, k); return; }
    float half = 11.0f * k;   // радиус ~11*k у векторных глифов -> тот же размер слота
    d->AddImage(tex, ImVec2(c.x - half, c.y - half), ImVec2(c.x + half, c.y + half),
                ImVec2(0, 0), ImVec2(1, 1), col);
}

// Иконки НОВОЙ навигации (сайдбар/нижний бар): eye/target/lens/gear из
// menu_bg.cpp. Слот задаётся половиной стороны в px; fallback — вектор.
static ImTextureID NavIconTex(int i) {
    switch (i) {
        case 0:  return g_iconTexEye;
        case 1:  return g_iconTexTarget;
        case 2:  return g_iconTexLens;
        default: return g_iconTexGear;
    }
}
static void NavIcon(ImDrawList* d, ImVec2 c, int i, ImU32 col, float halfPx) {
    ImTextureID tex = NavIconTex(i);
    if (!tex) { TabGlyph(d, c, i, col, halfPx / 11.0f); return; }
    d->AddImage(tex, ImVec2(c.x - halfPx, c.y - halfPx), ImVec2(c.x + halfPx, c.y + halfPx),
                ImVec2(0, 0), ImVec2(1, 1), col);
}

// Пост-фейд: домножает альфу вершин drawlist'а начиная с vtx0. Нужен анимации
// открытия меню — хром и виджеты рисуются сырыми IM_COL32 и не слушают
// ImGuiStyleVar_Alpha, поэтому затухание применяется к готовым вершинам кадра.
static void FadeDrawListRange(ImDrawList* dl, int vtx0, float k) {
    if (!dl || k >= 0.999f) return;
    if (k < 0.0f) k = 0.0f;
    int n = dl->VtxBuffer.Size;
    for (int i = vtx0; i < n; ++i) {
        ImU32 c = dl->VtxBuffer.Data[i].col;
        ImU32 al = (ImU32)((float)((c >> IM_COL32_A_SHIFT) & 0xFF) * k);
        dl->VtxBuffer.Data[i].col =
            (c & ~((ImU32)0xFF << IM_COL32_A_SHIFT)) | (al << IM_COL32_A_SHIFT);
    }
}
} // namespace oxui

// Новое меню (ui_v3.cpp) полностью заменяет прежний слой отрисовки.
// Старый Layout_tick_UI оставлен ниже нетронутым — он больше не вызывается,
// но остаётся рабочим ориентиром на случай сравнения поведения.
extern void OxDrawUiV3();

void Layout_tick_UI() {
    OxDrawUiV3();
}

[[maybe_unused]] static void Layout_tick_UI_legacy() {
    using namespace oxui;
    // oxorany-литералы меню расшифровываются ОДИН раз. Раньше каждый из ~24
    // ID/строк проходил obfuscation-decrypt КАЖДЫЙ кадр, пока меню открыто
    // (и во время анимации закрытия). Указатели/текст фиксированы — static ок.
    static const char* ID_MENU      = ox_persist(oxorany("##oxmenu"));
    static const char* TXT_SEP      = ox_persist(oxorany("/"));
    static const char* TXT_LIVE     = ox_persist(oxorany("LIVE"));
    static const char* TXT_WORDMARK = ox_persist(oxorany("ECLIPS OXIDE"));
    static const char* TXT_NEW      = ox_persist(oxorany("NEW"));
    static const char* ID_NAVSIDE   = ox_persist(oxorany("navside"));
    static const char* ID_NAV       = ox_persist(oxorany("##nav"));
    static const char* ID_NAVHV     = ox_persist(oxorany("##navhv"));
    static const char* ID_NAVIND_L  = ox_persist(oxorany("navind_l"));
    static const char* TXT_STATUS   = ox_persist(oxorany("STATUS"));
    static const char* TXT_RESOLVED = ox_persist(oxorany("Resolved"));
    static const char* TXT_WAITING  = ox_persist(oxorany("Waiting"));
    static const char* TXT_ENEMY    = ox_persist(oxorany("enemy"));
    static const char* TXT_ENEMIES  = ox_persist(oxorany("enemies"));
    static const char* ID_NAVBAR    = ox_persist(oxorany("navbar"));
    static const char* ID_NAVIND_P  = ox_persist(oxorany("navind_p"));
    static const char* ID_CONTENT   = ox_persist(oxorany("##oxcontent"));
    static const char* ID_PAGEFADE  = ox_persist(oxorany("pagefade"));
    static const char* ID_DRAGY     = ox_persist(oxorany("dragy"));
    static const char* ID_DRAGV     = ox_persist(oxorany("dragv"));
    static const char* ID_DRAGA     = ox_persist(oxorany("draga"));
    static const char* ID_DRAGOVER  = ox_persist(oxorany("dragover"));
    static const char* ID_EDGEFADE  = ox_persist(oxorany("edgefade"));
    oxApplyStyle();
    // Загружаем встроенные PNG-иконки один раз (GL-контекст уже активен в кадре).
    oxLoadIcons();
    ImGuiIO& io = ImGui::GetIO();
    ImVec2 ds = io.DisplaySize;
    if (ds.x < 1 || ds.y < 1) ds = ImVec2(1280, 720);

    // Адаптивное качество эффектов: обновляем сглаженное время кадра ДО отрисовки
    // этого кадра (влияет на число слоёв свечения/тени/зерна — не на геометрию).
    oxperf::ox_updateQuality(io.DeltaTime);

    // Палитра + масштаб этого кадра. Стиль уже отмасштабирован ×3 при init;
    // держим наш s около 3, чтобы пальце-размеры совпадали с остальным UI.
    g_pal = MakePalette(g_accentTheme);
    g_uiScale = 2.55f;
    const float s = g_uiScale;

    bool portrait = ds.y > ds.x * 1.05f;

    // ---- Анимация открытия/закрытия: scale 0.96 -> 1.0 + fade 0 -> 1 со
    // скоростью g_tk.mSlow. g_menuOpen — единственный источник истины,
    // аниматор лишь догоняет его; при openK ~ 0 окно вообще не создаётся.
    static float s_openAnim = 0.0f;
    static bool  s_replayOpen = true;   // после закрытия каскад страницы играет заново
    // Асимметрия: открытие размеренное (mSlow, ~200мс), закрытие быстрее
    // (~140мс) — появление «дорогое», уход не задерживает игрока.
    s_openAnim = Approach(s_openAnim, g_menuOpen ? 1.0f : 0.0f,
                          g_menuOpen ? g_tk.mSlow : 7.2f, io.DeltaTime);
    float openK = EaseOutCubic(s_openAnim);
    if (openK <= 0.02f) s_replayOpen = true;

    // ---- Большое центрированное меню: ОДНО окно, внутри три колонки ----
    if (openK > 0.015f) {
        const float margin = 24.f;
        const float maxWidth = ds.x > margin * 2.f ? ds.x - margin * 2.f : ds.x;
        const float maxHeight = ds.y > margin * 2.f ? ds.y - margin * 2.f : ds.y;
        ImVec2 sz(portrait ? ds.x * 0.88f : ds.x * 0.78f, ds.y * 0.80f);
        if (sz.x < 640.f && maxWidth >= 640.f) sz.x = 640.f;
        if (sz.x > maxWidth) sz.x = maxWidth;
        if (sz.y > maxHeight) sz.y = maxHeight;
        // масштаб появления (окно растёт из центра — позиция с pivot 0.5/0.5)
        float scaleK = 0.96f + 0.04f * openK;
        sz.x *= scaleK; sz.y *= scaleK;

        ImGui::SetNextWindowPos(ImVec2(ds.x * 0.5f, ds.y * 0.5f), ImGuiCond_Always, ImVec2(0.5f, 0.5f));
        ImGui::SetNextWindowSize(sz, ImGuiCond_Always);
        // Пользовательская "UI opacity" (Settings пишет прямо в style.Alpha) —
        // домножаем на openK и восстанавливаем её запись после Pop.
        float preAlpha = ImGui::GetStyle().Alpha;
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
        ImGui::PushStyleVar(ImGuiStyleVar_Alpha, preAlpha * openK);
        ImGui::Begin(ID_MENU, nullptr,
            ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize |
            ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoMove |
            ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse |
            ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoSavedSettings);

        ImDrawList* dl = ImGui::GetWindowDrawList();
        int vtxMain0 = dl->VtxBuffer.Size;   // старт вершин кадра — для пост-фейда
        ImDrawList* dlOpt = nullptr;         // drawlist options-child'а (свой буфер)
        int vtxOpt0 = 0;
        ImVec2 wp = ImGui::GetWindowPos();
        ImVec2 wsz = ImGui::GetWindowSize();
        ImVec2 wmin = wp, wmax(wp.x + wsz.x, wp.y + wsz.y);
        const float RND = ::clamp<float>(wsz.y * 0.045f, 22.f, 42.f);
        ImFont* hf = ImGui::GetFont();

        // ════════════════════════════════════════════════════════════════════
        //  СТЕКЛО. Настоящего backdrop-blur в ImGui нет — под окном нам не
        //  доступен кадр игры. Убедительное матовое стекло собирается слоями,
        //  каждый из которых отвечает за отдельный физический эффект:
        //
        //    1. затемнение сцены      — стекло гасит то, что за ним
        //    2. холодная подложка     — не чёрная: у стекла есть свой оттенок
        //    3. вертикальный градиент — свет падает сверху
        //    4. цветная дымка         — подсветка проникает внутрь панели
        //    5. плёнка зерна          — матовость, «изморозь» на поверхности
        //    6. кромка сверху-слева   — преломление на грани, самая яркая линия
        //    7. внешний ореол         — свечение подсветки наружу
        //
        //  Все цветные слои берут g_tk.accent, поэтому ползунок подсветки
        //  меняет вообще всё стекло разом, а не только рамку.
        // ════════════════════════════════════════════════════════════════════
        dl->AddRectFilled(ImVec2(0, 0), ds, IM_COL32(4, 4, 9, 170));

        // Внешний ореол подсветки: несколько растянутых прямоугольников с
        // падающей альфой. Дышит медленно — стекло выглядит «живым».
        {
            float tGl = (float)ImGui::GetTime();
            float breath = 0.5f + 0.5f * sinf(tGl * 1.15f);
            int haloN; switch (ox_uiQuality()) { case 2: haloN = 2; break; case 1: haloN = 4; break; default: haloN = 7; }
            for (int i = haloN; i >= 1; --i) {
                float f01 = (float)i / (float)haloN;
                float ex  = (6.f + f01 * 40.f) * s;
                float al  = (1.0f - f01 * 0.88f) * (0.055f + 0.022f * breath) * glowIntensity;
                dl->AddRectFilled(ImVec2(wmin.x - ex, wmin.y - ex),
                                  ImVec2(wmax.x + ex, wmax.y + ex),
                                  Fade(g_tk.accentHi, al), RND + ex, 0);
            }
        }

        SoftShadow(dl, wmin, wmax, RND, g_tk.elev3);

        // Подложка: холодный сине-фиолетовый уход в тень, а не плоский чёрный.
        dl->AddRectFilled(wmin, wmax, IM_COL32(13, 13, 22, 232), RND);

        // Градиент «свет сверху»: верх заметно светлее низа.
        dl->AddRectFilledMultiColor(wmin, ImVec2(wmax.x, wmin.y + wsz.y * 0.62f),
            IM_COL32(255, 255, 255, 20), IM_COL32(255, 255, 255, 20),
            IM_COL32(255, 255, 255, 0),  IM_COL32(255, 255, 255, 0));

        // Цветная дымка подсветки внутри панели — из верхнего-левого угла,
        // как будто источник света стоит там же, где брендовая метка.
        {
            int aR = (int)((g_tk.accentHi >>  0) & 0xFF);
            int aG = (int)((g_tk.accentHi >>  8) & 0xFF);
            int aB = (int)((g_tk.accentHi >> 16) & 0xFF);
            int hazeA = (int)(34.f * glowIntensity);
            if (hazeA > 90) hazeA = 90;
            dl->AddRectFilledMultiColor(wmin, ImVec2(wmax.x, wmax.y),
                IM_COL32(aR, aG, aB, hazeA),
                IM_COL32(aR, aG, aB, hazeA / 3),
                IM_COL32(aR, aG, aB, 0),
                IM_COL32(aR, aG, aB, hazeA / 5));
        }

        // Матовость: тонкая плёнка зерна поверх цвета.
        if (g_texGrain && ox_uiQuality() < 2)
            dl->AddImageRounded(g_texGrain, wmin, wmax, ImVec2(0, 0),
                ImVec2(wsz.x / Px(96.0f), wsz.y / Px(96.0f)),
                IM_COL32(255, 255, 255, 13), RND);

        // Кромка. Верх и левый край — яркая светлая линия (преломление),
        // низ и правый — приглушённая. Это и создаёт «толщину» стекла.
        dl->AddRect(wmin, wmax, Fade(g_tk.accent, 0.50f), RND, 0, g_tk.strokeW * s);
        dl->PathArcTo(ImVec2(wmin.x + RND, wmin.y + RND), RND, 3.1415926f, 4.712389f, 12);
        dl->PathLineTo(ImVec2(wmax.x - RND, wmin.y));
        dl->PathStroke(IM_COL32(255, 255, 255, 46), 0, 1.4f * s);
        dl->PathArcTo(ImVec2(wmin.x + RND, wmin.y + RND), RND, 3.1415926f, 2.356194f, 12);
        dl->PathLineTo(ImVec2(wmin.x, wmax.y - RND));
        dl->PathStroke(IM_COL32(255, 255, 255, 30), 0, 1.2f * s);

        // ── хлебная крошка на всю ширину: "<TAB> / LIVE" + сабтайтл ─────────
        const float headerH = Px(g_tk.sp6 * 2.0f);
        {
            float tx = wmin.x + Px(g_tk.sp5);
            float blockH = g_tk.fsLabel + Px(g_tk.sp1) + g_tk.fsCaption;
            float ty = wmin.y + headerH * 0.5f - blockH * 0.5f;
            const char* crumb = kTabNamesCaps[g_activeTab];
            ImVec2 csz = CalcTextSizeCached(hf, g_tk.fsLabel, crumb);   // статич. имя вкладки
            dl->AddText(hf, g_tk.fsLabel, ImVec2(tx, ty), g_tk.textHi, crumb);
            ImVec2 ssz = CalcTextSizeCached(hf, g_tk.fsLabel, TXT_SEP);
            float sx = tx + csz.x + Px(g_tk.sp2);
            dl->AddText(hf, g_tk.fsLabel, ImVec2(sx, ty), g_tk.textFaint, TXT_SEP);
            dl->AddText(hf, g_tk.fsLabel, ImVec2(sx + ssz.x + Px(g_tk.sp2), ty),
                        g_tk.accent, TXT_LIVE);
            dl->AddText(hf, g_tk.fsCaption, ImVec2(tx, ty + g_tk.fsLabel + Px(g_tk.sp1)),
                        g_tk.textFaint, kCrumbSubs[g_activeTab]);
            dl->AddLine(ImVec2(wmin.x, wmin.y + headerH), ImVec2(wmax.x, wmin.y + headerH),
                        g_tk.strokeBase, g_tk.dividerW * s);
        }
        float bodyTop = wmin.y + headerH;

        // ── регион options-колонки (единственный скролл) — задаётся веткой ──
        ImVec2 optA, optB;

        if (!portrait) {
            // ── ландшафт: sidebar 188dp | preview 280dp | options = остаток ──
            float navW  = 170.0f * s;
            float prevW = 320.0f * s;
            float optW  = wsz.x - navW - prevW;
            const float minOpt = 150.0f * s;
            if (optW < minOpt) {               // деградация на узких экранах:
                float need = minOpt - optW;    // сначала ужимаем превью, потом сайдбар
                float give = prevW - 230.0f * s; if (give < 0.f) give = 0.f;
                float d = need < give ? need : give;
                prevW -= d; need -= d;
                if (need > 0.f) {
                    give = navW - 138.0f * s; if (give < 0.f) give = 0.f;
                    d = need < give ? need : give;
                    navW -= d;
                }
            }
            float sbX1 = wmin.x + navW;
            float pvX1 = sbX1 + prevW;

            // сайдбар чуть глубже фоном + вертикальные хэйрлайны между колонками
            dl->AddRectFilled(ImVec2(wmin.x, bodyTop), ImVec2(sbX1, wmax.y),
                              g_tk.panel0, RND, ImDrawFlags_RoundCornersBottomLeft);
            dl->AddLine(ImVec2(sbX1, bodyTop), ImVec2(sbX1, wmax.y),
                        g_tk.strokeBase, g_tk.dividerW * s);
            dl->AddLine(ImVec2(pvX1, bodyTop), ImVec2(pvX1, wmax.y),
                        g_tk.strokeBase, g_tk.dividerW * s);

            // ---- SIDEBAR: бренд / навигация / STATUS ----
            {
                float pad = Px(g_tk.sp4);

                // Бренд-знак 34dp (tint accent) + wordmark в две строки
                float markSz = Px(34.0f);
                ImVec2 ma(wmin.x + pad, bodyTop + pad);
                if (g_texBrandMark) {
                    dl->AddImage(g_texBrandMark, ma, ImVec2(ma.x + markSz, ma.y + markSz),
                                 ImVec2(0, 0), ImVec2(1, 1), g_tk.accent);
                } else if (g_iconTexBrandBadge) {
                    dl->AddImage(g_iconTexBrandBadge, ma, ImVec2(ma.x + markSz, ma.y + markSz),
                                 ImVec2(0, 0), ImVec2(1, 1), g_tk.accent);
                } else {
                    ImVec2 mc(ma.x + markSz * 0.5f, ma.y + markSz * 0.5f);
                    dl->AddCircle(mc, markSz * 0.46f, g_tk.accent, 32, Px(2.0f));
                    dl->AddCircleFilled(mc, markSz * 0.20f, g_tk.accentHi);
                }
                float wx = ma.x + markSz + Px(g_tk.sp3);
                float wy = ma.y + markSz * 0.5f
                         - (g_tk.fsBody + Px(g_tk.sp1) + g_tk.fsCaption) * 0.5f;
                // Wordmark одной строкой; на узком сайдбаре кегль дожимается по ширине.
                {
                    float wmSz = g_tk.fsBody;
                    ImVec2 wm1 = CalcTextSizeCached(hf, wmSz, TXT_WORDMARK);   // статич. wordmark
                    float wmMax = sbX1 - pad - wx;
                    if (wm1.x > wmMax && wm1.x > 1.0f) wmSz *= wmMax / wm1.x;
                    dl->AddText(hf, wmSz, ImVec2(wx, wy), g_tk.textHi, TXT_WORDMARK);
                    dl->AddText(hf, g_tk.fsCaption, ImVec2(wx, wy + g_tk.fsBody + Px(g_tk.sp1)),
                                g_tk.accent, TXT_NEW);
                }

                float divY = ma.y + markSz + Px(g_tk.sp3);
                dl->AddLine(ImVec2(wmin.x + pad, divY), ImVec2(sbX1 - pad, divY),
                            g_tk.strokeSoft, g_tk.dividerW * s);

                // Навигация: 4 ряда x rowH; активный — залитая плашка (едет
                // пружиной springSnappy) + сплошной акцентный бар у левой кромки.
                // Вертикальный бюджет: STATUS прижат к низу; если 4 полных ряда
                // rowH между брендом и статусом не помещаются (короткий экран),
                // ряды равномерно сжимаются — сайдбар никогда не скроллится.
                float statusLineH  = g_tk.fsCaption * 1.5f;
                float statusBlockH = statusLineH * 4.0f + Px(g_tk.sp2) + Px(g_tk.sp3);
                float navTop = divY + Px(g_tk.sp2);
                float navAvail = (wmax.y - statusBlockH - Px(g_tk.sp2)) - navTop;
                float rowHpx = Px(g_tk.rowH);
                if (rowHpx * 4.0f > navAvail) {
                    rowHpx = navAvail / 4.0f;
                    if (rowHpx < Px(20.0f)) rowHpx = Px(20.0f);
                }
                float iconHalf = Px(11.0f);
                if (iconHalf > rowHpx * 0.36f) iconHalf = rowHpx * 0.36f;
                float plX0 = wmin.x + Px(g_tk.sp3), plX1 = sbX1 - Px(g_tk.sp3);
                ImGui::SetCursorScreenPos(ImVec2(plX0, navTop));
                ImGui::PushID(ID_NAVSIDE);
                if (ImGui::InvisibleButton(ID_NAV, ImVec2(plX1 - plX0, rowHpx * 4.0f))) {
                    float my = io.MousePos.y - navTop;
                    int idx = (int)(my / rowHpx); if (idx < 0) idx = 0; if (idx > 3) idx = 3;
                    g_activeTab = idx;
                }
                bool navHov = ImGui::IsItemHovered();
                ImGui::PopID();

                float inset = Px(g_tk.sp1) * 0.5f;

                // hover-подсветка ряда под пальцем: fast-in / slow-out,
                // в покое невидима (рисуется ПОД активной плашкой)
                int hovRow = -1;
                if (navHov) {
                    hovRow = (int)((io.MousePos.y - navTop) / rowHpx);
                    if (hovRow < 0) hovRow = 0; if (hovRow > 3) hovRow = 3;
                }
                ImGuiID hvBase = ImGui::GetCurrentWindow()->GetID(ID_NAVHV);
                for (int i = 0; i < 4; ++i) {
                    float hA = AnimAsym(hvBase + (ImGuiID)i, (i == hovRow) ? 1.0f : 0.0f,
                                        g_tk.mFast, g_tk.mBase);
                    if (hA > 0.004f) {
                        ImVec2 ha(plX0, navTop + i * rowHpx + inset);
                        dl->AddRectFilled(ha, ImVec2(plX1, ha.y + rowHpx - inset * 2.0f),
                                          Fade(g_tk.panel2, hA * 0.7f), Px(g_tk.rMd));
                    }
                }

                // Активная плашка — пружина: лёгкий перелёт при прыжке через
                // несколько рядов. Ширина «выдыхает» ~2dp пока плашка движется
                // (питается модулем скорости пружины) и садится на место.
                ImGuiID plateId = ImGui::GetCurrentWindow()->GetID(ID_NAVIND_L);
                float curp = Spring(plateId, (float)g_activeTab, kSpringStiff, kSpringDamp);
                if (curp < -0.10f) curp = -0.10f; if (curp > 3.10f) curp = 3.10f;
                float widen = Px(2.0f) * Clamp01(fabsf(SpringVel(plateId)) * 0.12f);
                ImVec2 pa(plX0 - widen, navTop + curp * rowHpx + inset);
                ImVec2 pb(plX1 + widen, pa.y + rowHpx - inset * 2.0f);
                dl->AddRectFilled(pa, pb, Fade(g_tk.accent, 0.14f), Px(g_tk.rMd));
                float barIn = (pb.y - pa.y) * 0.22f;   // пропорционально высоте плашки
                dl->AddRectFilled(ImVec2(pa.x, pa.y + barIn),
                                  ImVec2(pa.x + Px(3.0f), pb.y - barIn),
                                  g_tk.accent, Px(1.5f));

                float navLbl = g_tk.fsBody;
                if (navLbl > rowHpx * 0.68f) navLbl = rowHpx * 0.68f;
                // Perf (batch): рисуем СНАЧАЛА все 4 иконки, ПОТОМ все 4 подписи.
                // Раньше порядок был icon,label,icon,label,... — 4 текстовых
                // (font-atlas) команды перемежались с иконками и не сливались.
                // Теперь 4 подписи идут подряд одной font-текстурой → ImGui
                // мёржит их в одну команду. Пиксели идентичны (позиции те же).
                for (int i = 0; i < 4; ++i) {
                    float rcy = navTop + i * rowHpx + rowHpx * 0.5f;
                    bool sel = (i == g_activeTab);
                    NavIcon(dl, ImVec2(plX0 + Px(g_tk.sp4) + iconHalf, rcy), i,
                            sel ? g_tk.accent : g_tk.textFaint, iconHalf);
                }
                for (int i = 0; i < 4; ++i) {
                    float rcy = navTop + i * rowHpx + rowHpx * 0.5f;
                    bool sel = (i == g_activeTab);
                    dl->AddText(hf, navLbl,
                                ImVec2(plX0 + Px(g_tk.sp4) + iconHalf * 2.0f + Px(g_tk.sp3),
                                       rcy - navLbl * 0.5f),
                                sel ? g_tk.textHi : g_tk.textDim, kTabNames[i]);
                }

                // STATUS-блок у низа: klass / враги / FPS (только чтение глобалей)
                {
                    float lineH = statusLineH;
                    float yFps = wmax.y - Px(g_tk.sp3) - lineH;
                    float yEn  = yFps - lineH;
                    float yRes = yEn - lineH;
                    float yCap = yRes - lineH;
                    float yDiv = yCap - Px(g_tk.sp2);
                    dl->AddLine(ImVec2(wmin.x + pad, yDiv), ImVec2(sbX1 - pad, yDiv),
                                g_tk.strokeSoft, g_tk.dividerW * s);
                    dl->AddText(hf, g_tk.fsCaption, ImVec2(wmin.x + pad, yCap),
                                g_tk.textFaint, TXT_STATUS);

                    bool ready = (g_playerManagerKlass != 0);
                    ImU32 dotC = ready ? g_tk.good : g_tk.warn;
                    float dr = Px(3.0f);
                    dl->AddCircleFilled(ImVec2(wmin.x + pad + dr, yRes + lineH * 0.5f), dr, dotC);
                    dl->AddText(hf, g_tk.fsCaption,
                                ImVec2(wmin.x + pad + dr * 2.0f + Px(g_tk.sp2),
                                       yRes + (lineH - g_tk.fsCaption) * 0.5f),
                                g_tk.textDim, ready ? TXT_RESOLVED : TXT_WAITING);

                    char enb[32];
                    snprintf(enb, sizeof(enb), "%d %s", g_enemyCount,
                             g_enemyCount == 1 ? TXT_ENEMY : TXT_ENEMIES);
                    dl->AddText(hf, g_tk.fsCaption,
                                ImVec2(wmin.x + pad, yEn + (lineH - g_tk.fsCaption) * 0.5f),
                                g_tk.textDim, enb);

                    char fpb[24];
                    snprintf(fpb, sizeof(fpb), "%.0f FPS", io.Framerate);
                    dl->AddText(hf, g_tk.fsCaption,
                                ImVec2(wmin.x + pad, yFps + (lineH - g_tk.fsCaption) * 0.5f),
                                g_tk.textDim, fpb);
                }
            }

            // ---- PREVIEW: центральная колонка, без скролла, центр по вертикали
            {
                float pad = Px(g_tk.sp4);
                float availH = wmax.y - bodyTop - pad * 2.0f;
                float paneH = availH < Px(520.0f) ? availH : Px(520.0f);
                float py0 = bodyTop + pad + (availH - paneH) * 0.5f;
                oxDrawEspPreviewPane(dl, ImVec2(sbX1 + pad, py0),
                                     ImVec2(pvX1 - pad, py0 + paneH));
            }

            optA = ImVec2(pvX1, bodyTop);
            optB = ImVec2(wmax.x, wmax.y);
        } else {
            // ── портрет: options на всю ширину, нижний таб-бар из 4 ячеек ────
            float navH = Px(64.0f);
            float y0 = wmax.y - navH;
            optA = ImVec2(wmin.x, bodyTop);
            optB = ImVec2(wmax.x, y0);

            dl->AddLine(ImVec2(wmin.x, y0), ImVec2(wmax.x, y0),
                        g_tk.strokeBase, g_tk.dividerW * s);
            float cellW = (wmax.x - wmin.x) / 4.0f;
            ImGui::SetCursorScreenPos(ImVec2(wmin.x, y0));
            ImGui::PushID(ID_NAVBAR);
            if (ImGui::InvisibleButton(ID_NAV, ImVec2(wmax.x - wmin.x, navH))) {
                float mx = io.MousePos.x - wmin.x;
                int idx = (int)(mx / cellW); if (idx < 0) idx = 0; if (idx > 3) idx = 3;
                g_activeTab = idx;
            }
            ImGui::PopID();
            // индикатор — пружина + лёгкое расширение в полёте (как плашка сайдбара)
            ImGuiID indId = ImGui::GetCurrentWindow()->GetID(ID_NAVIND_P);
            float curp = Spring(indId, (float)g_activeTab, kSpringStiff, kSpringDamp);
            if (curp < -0.10f) curp = -0.10f; if (curp > 3.10f) curp = 3.10f;
            float iwiden = Px(2.0f) * Clamp01(fabsf(SpringVel(indId)) * 0.12f);
            float ix = wmin.x + (curp + 0.5f) * cellW;
            dl->AddRectFilledMultiColor(ImVec2(ix - Px(10.0f) - iwiden, y0),
                ImVec2(ix + Px(10.0f) + iwiden, y0 + Px(1.5f)),
                g_tk.accent, g_tk.accentHi, g_tk.accentHi, g_tk.accent);
            // Perf (batch): все 4 иконки, затем все 4 подписи (см. сайдбар).
            // Подписи сливаются в одну font-команду; пиксели те же.
            for (int i = 0; i < 4; ++i) {
                float cxp = wmin.x + (i + 0.5f) * cellW;
                bool sel = (i == g_activeTab);
                NavIcon(dl, ImVec2(cxp, y0 + navH * 0.40f), i,
                        sel ? g_tk.accent : g_tk.textFaint, Px(9.0f));
            }
            for (int i = 0; i < 4; ++i) {
                float cxp = wmin.x + (i + 0.5f) * cellW;
                bool sel = (i == g_activeTab);
                ImVec2 tsz = CalcTextSizeCached(hf, g_tk.fsMicro, kTabNames[i]);   // статич. ярлык
                dl->AddText(hf, g_tk.fsMicro,
                            ImVec2(cxp - tsz.x * 0.5f, y0 + navH - g_tk.fsMicro - Px(g_tk.sp2)),
                            sel ? g_tk.textHi : g_tk.textDim, kTabNames[i]);
            }
        }

        // ── OPTIONS: единственный скроллируемый регион меню ─────────────────
        {
            float inPad = Px(g_tk.sp2);
            float chW = optB.x - optA.x - inPad * 2.0f; if (chW < 50.f) chW = 50.f;
            float chH = optB.y - optA.y - inPad * 2.0f; if (chH < 50.f) chH = 50.f;
            ImGui::SetCursorScreenPos(ImVec2(optA.x + inPad, optA.y + inPad));
            ImGui::PushStyleColor(ImGuiCol_ChildBg, ImVec4(0, 0, 0, 0));
            ImGui::PushStyleVar(ImGuiStyleVar_ScrollbarSize, Px(5.0f));
            ImGui::PushStyleColor(ImGuiCol_ScrollbarBg, ImVec4(0, 0, 0, 0));
            ImGui::PushStyleColor(ImGuiCol_ScrollbarGrab, ImGui::ColorConvertU32ToFloat4(g_tk.strokeBase));
            ImGui::PushStyleColor(ImGuiCol_ScrollbarGrabHovered, ImGui::ColorConvertU32ToFloat4(g_tk.accent));
            ImGui::BeginChild(ID_CONTENT, ImVec2(chW, chH),
                              false, ImGuiWindowFlags_NoBackground);
            dlOpt = ImGui::GetWindowDrawList();
            vtxOpt0 = dlOpt->VtxBuffer.Size;

            // Переход страницы: fade + НАПРАВЛЕННЫЙ слайд 12dp (вниз по
            // навигации → контент заезжает снизу, вверх → сверху) + каскад
            // секций (PageStagger*). Общий бюджет ~220мс.
            ImGuiID pid = ImGui::GetCurrentWindow()->GetID(ID_PAGEFADE);
            ImGuiStorage* pst = ImGui::GetStateStorage();
            int lastPage = pst->GetInt(pid, -1);
            if (lastPage != g_activeTab || s_replayOpen) {
                g_pageMo.dir = (lastPage >= 0 && g_activeTab < lastPage) ? -1.0f : 1.0f;
                g_pageMo.t0  = ImGui::GetTime();
                pst->SetInt(pid, g_activeTab);
                pst->SetFloat(pid + 1, 0.0f);
                s_replayOpen = false;
            }
            float appear = Anim(pid + 1, 1.0f, g_tk.springSnappy);  // ~165мс
            g_pageMo.appear   = appear;
            g_pageMo.section  = 0;
            g_pageMo.dl       = dlOpt;
            g_pageMo.spanVtx0 = dlOpt->VtxBuffer.Size;
            g_pageMo.spanK    = 1.0f;   // до первой секции контент едет с контейнером
            ImGui::SetCursorPosY(ImGui::GetCursorPosY() +
                                 (1.0f - appear) * Px(12.0f) * g_pageMo.dir);

            // ── TOUCH-DRAG SCROLL: листаем содержимое пальцем, не только ползунком.
            // Пока палец держит — прямое смещение; отпустил — инерция с затуханием.
            // Полировка: rubber-band у кромок (до 48dp с прогрессирующим
            // сопротивлением, возврат пружиной springSoft), кламп скорости
            // флика, кадро-независимое трение, мягкий отскок инерции от края.
            float overNow = 0.0f;   // растяжение резинки этого кадра (px, + верх / − низ)
            {
                ImGuiWindow* cw = ImGui::GetCurrentWindow();
                ImGuiStorage* st = ImGui::GetStateStorage();
                ImGuiID dragId = cw->GetID(ID_DRAGY);
                ImGuiID velId  = cw->GetID(ID_DRAGV);
                ImGuiID actId  = cw->GetID(ID_DRAGA);
                ImGuiID overId = cw->GetID(ID_DRAGOVER);
                bool hovered = ImGui::IsWindowHovered(ImGuiHoveredFlags_ChildWindows |
                                                      ImGuiHoveredFlags_AllowWhenBlockedByActiveItem);
                float dt = io.DeltaTime > 0.0001f ? io.DeltaTime : 0.016f;
                if (dt > 0.05f) dt = 0.05f;        // hitch-кадр не телепортирует список
                bool active = st->GetInt(actId, 0) != 0;
                float over = st->GetFloat(overId, 0.0f);
                const float overCap = Px(48.0f);   // потолок растяжения
                const float overRes = Px(24.0f);   // знаменатель сопротивления
                const float velCap  = Px(1600.0f); // кламп скорости флика (px/s)

                if (io.MouseDown[0] && hovered && !ImGui::IsAnyItemActive()) {
                    if (!active) {
                        st->SetInt(actId, 1);
                        st->SetFloat(dragId, io.MousePos.y);
                        st->SetFloat(velId, 0.0f);
                    } else {
                        float prevY = st->GetFloat(dragId, io.MousePos.y);
                        float dy = io.MousePos.y - prevY;
                        if (fabsf(dy) > 0.01f) {
                            float sc    = ImGui::GetScrollY();
                            float scMax = ImGui::GetScrollMaxY();
                            if (over != 0.0f) {
                                // уже в резинке: дельта делится на 1 + |over|/24dp
                                float no = over + dy / (1.0f + fabsf(over) / overRes);
                                if ((no > 0.0f) != (over > 0.0f) || no == 0.0f) {
                                    ImGui::SetScrollY(sc - no);   // остаток — в скролл
                                    no = 0.0f;
                                }
                                over = no;
                                st->SetFloat(velId, 0.0f);        // из резинки не фликаем
                            } else {
                                float want = sc - dy;
                                if (want < 0.0f) {                // верхняя кромка
                                    ImGui::SetScrollY(0.0f);
                                    over += (0.0f - want) / (1.0f + fabsf(over) / overRes);
                                } else if (want > scMax) {        // нижняя кромка
                                    ImGui::SetScrollY(scMax);
                                    over -= (want - scMax) / (1.0f + fabsf(over) / overRes);
                                } else {
                                    ImGui::SetScrollY(want);
                                    float nv = dy / dt;
                                    if (nv >  velCap) nv =  velCap;
                                    if (nv < -velCap) nv = -velCap;
                                    st->SetFloat(velId, nv);
                                }
                            }
                            if (over >  overCap) over =  overCap;
                            if (over < -overCap) over = -overCap;
                        }
                        st->SetFloat(dragId, io.MousePos.y);
                    }
                } else {
                    if (active) st->SetInt(actId, 0);
                    if (over != 0.0f) {
                        // отпустили в растяжении: пружина возврата springSoft
                        over = Approach(over, 0.0f, g_tk.springSoft, dt);
                        if (fabsf(over) < 0.5f) over = 0.0f;
                    } else {
                        float v = st->GetFloat(velId, 0.0f);
                        if (fabsf(v) > 6.0f) {
                            float sc    = ImGui::GetScrollY();
                            float scMax = ImGui::GetScrollMaxY();
                            float ns = sc - v * dt;
                            if (ns < 0.0f || ns > scMax) {
                                // инерция врезалась в край: короткий кик в
                                // резинку (≤18dp) вместо жёсткого стопа
                                ImGui::SetScrollY(ns < 0.0f ? 0.0f : scMax);
                                float kick = v * 0.03f;
                                float kcap = Px(18.0f);
                                if (kick >  kcap) kick =  kcap;
                                if (kick < -kcap) kick = -kcap;
                                over = kick;
                                v = 0.0f;
                            } else {
                                ImGui::SetScrollY(ns);
                                v *= expf(-5.0f * dt);   // кадро-независимое трение
                                if (fabsf(v) < 6.0f) v = 0.0f;
                            }
                            st->SetFloat(velId, v);
                        }
                    }
                }
                st->SetFloat(overId, over);
                overNow = over;
            }
            // Растяжение показываем сдвигом контента; изменение высоты
            // компенсирует хвостовой Dummy — покоящаяся геометрия не меняется.
            if (overNow != 0.0f)
                ImGui::SetCursorPosY(ImGui::GetCursorPosY() + overNow);

            // Портрет: превью — full-width ряд над контентом вкладки ESP.
            if (portrait && g_activeTab == 0) oxDrawEspPreviewInline();

            switch (g_activeTab) {
                case 0: oxTabESP();      break;
                case 1: oxTabAim();      break;
                case 2: oxTabCamera();   break;
                default: oxTabSettings(); break;
            }
            PageStaggerFlush();   // закрыть хвостовой спан каскада

            // Кромочные фейды скролла: ленты ~24dp в цвете панели. Верхняя
            // видна только когда проскроллено вниз, нижняя — пока не конец.
            // Альфы анимируются (fast-in / slow-out).
            {
                ImGuiWindow* cw = ImGui::GetCurrentWindow();
                float scY = ImGui::GetScrollY(), scMax = ImGui::GetScrollMaxY();
                ImGuiID mid = cw->GetID(ID_EDGEFADE);
                float topA = AnimAsym(mid, scY > Px(2.0f) ? 1.0f : 0.0f,
                                      g_tk.mFast, g_tk.mBase);
                float botA = AnimAsym(mid + 1, (scMax - scY) > Px(2.0f) ? 1.0f : 0.0f,
                                      g_tk.mFast, g_tk.mBase);
                float mh = Px(24.0f);
                ImVec2 ra = cw->InnerRect.Min, rb = cw->InnerRect.Max;
                ImU32 clr = Fade(g_tk.bgBase, 0.0f);
                if (topA > 0.01f) {
                    ImU32 c = Fade(g_tk.bgBase, 0.88f * topA);
                    dlOpt->AddRectFilledMultiColor(ra, ImVec2(rb.x, ra.y + mh),
                                                   c, c, clr, clr);
                }
                if (botA > 0.01f) {
                    ImU32 c = Fade(g_tk.bgBase, 0.88f * botA);
                    dlOpt->AddRectFilledMultiColor(ImVec2(ra.x, rb.y - mh), rb,
                                                   clr, clr, c, c);
                }
            }
            // хвостовой Dummy компенсирует нижнее растяжение резинки
            ImGui::Dummy(ImVec2(0, Px(g_tk.sp4) + (overNow < 0.0f ? -overNow : 0.0f)));
            ImGui::EndChild();
            ImGui::PopStyleColor(4);
            ImGui::PopStyleVar();
        }

        ImGui::End();
        float postAlpha = ImGui::GetStyle().Alpha;  // Settings мог записать новую opacity
        ImGui::PopStyleVar(2);   // Alpha + WindowPadding
        if (postAlpha != preAlpha * openK)          // слайдер "UI opacity" двигали
            ImGui::GetStyle().Alpha = postAlpha;

        // Пост-фейд открытия: хром и виджеты рисуются сырыми IM_COL32 и не
        // слушают ImGuiStyleVar_Alpha, поэтому альфа домножается прямо в
        // вершинах кадра (окно + options-child, у каждого свой буфер).
        // options-child дополнительно умножается на фейд перехода страницы.
        FadeDrawListRange(dl, vtxMain0, openK);
        FadeDrawListRange(dlOpt, vtxOpt0, openK * g_pageMo.appear);
    }

    // ---- Click bar (левый верхний угол, поверх всего) ----
    oxDrawClickBar(ds);

    // ---- opt-in perf HUD (OX_UI_PERF_HUD=1) — не пользовательская опция ----
    // Крошечная строка в правом-верхнем углу с числами ПРОШЛОГО кадра
    // (vtx/idx/cmds/tex/quality). Foreground drawlist, вне любого окна.
    if (oxperf::ox_perfHudEnabled()) {
        const oxperf::FrameStats& fs = oxperf::g_lastStats;
        char hud[128];
        snprintf(hud, sizeof(hud), "v%d i%d c%d tex%d q%d %.1fms",
                 fs.vtx, fs.idx, fs.cmds, fs.texBinds, ox_uiQuality(),
                 oxperf::g_smoothFrameMs);
        ImDrawList* fg = ImGui::GetForegroundDrawList();
        ImFont* hf2 = ImGui::GetFont();
        float hsz = ImGui::GetFontSize() * 0.5f;
        ImVec2 tsz = hf2->CalcTextSizeA(hsz, FLT_MAX, 0, hud);
        float hx = ds.x - tsz.x - 14.0f, hy = 10.0f;
        fg->AddRectFilled(ImVec2(hx - 8, hy - 4), ImVec2(hx + tsz.x + 8, hy + tsz.y + 4),
                          IM_COL32(0, 0, 0, 170), 6.0f);
        fg->AddText(hf2, hsz, ImVec2(hx, hy), IM_COL32(120, 255, 160, 255), hud);
    }
}
